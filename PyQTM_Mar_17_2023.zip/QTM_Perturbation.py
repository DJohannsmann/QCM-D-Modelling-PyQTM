import numpy as np

def Assign_Vals_for_Perturbation(t_lays,rho_lays,J_lays,VertScaleR,AspRat,n,f_fund,Zq,Show_lay1,Show_lay2,Show_bulk):
    om = 2 * np.pi * n * f_fund
    if Show_lay1 == 'yes' : t_e = t_lays[0] 
    else :                  t_e = 0 
    rho_e = rho_lays[0] 
    if Show_lay2 == 'yes' : t_f = t_lays[1] 
    else:                   t_f = 0 
    rho_f = rho_lays[1]
    if Show_bulk == 'yes' : rho_b = rho_lays[2] 
    else:                   rho_b = 0 
    mq = Zq/(2*f_fund)
    J_e = J_lays[0]
    J_f = J_lays[1]
    J_b = J_lays[2]
    Z_e = np.sqrt(rho_e / J_e)
    Z_f = np.sqrt(rho_f / J_f)
    Z_b = np.sqrt(rho_b / J_b)
    k_b = om * (rho_b*J_b)**0.5
    Z_b *= 1 + (VertScaleR * k_b)**2 
    Z_b += 1j * om * rho_lays[2] * VertScaleR * 3./2. * np.pi**0.5 * AspRat 
    mue = rho_e * t_e/mq
    muf = rho_f * t_f/mq
    xil = Z_b/Zq
    zee = (Zq/Z_e)**2 - 1
    zef = (Zq/Z_f)**2 - 1
    nPi = n * np.pi
    return mue,muf,xil,zee,zef,nPi

def Perturbation_3(d,rho,J,vers,AspRat,n,f_fund,Zq,Show_lay1,Show_lay2,Show_bulk):
    mue,muf,xil,zee,zef,nPi = \
      Assign_Vals_for_Perturbation(d,rho,J,vers,AspRat,n,f_fund,Zq,Show_lay1,Show_lay2,Show_bulk)
    coeff0 = ((1j*xil)/nPi) + (1j*xil**3)/(3.*nPi) + 1./3.*mue**3*(-3. - nPi**2*zee) + \
        mue*(-1. - (1j*xil)/nPi + xil**2*zee) + \
        mue**2*(1. + xil*((1j/nPi) + 1j*nPi*zee))
    coeff1 = -1. - (1j*xil)/nPi + mue**2*(-3. - nPi**2*zee) + \
        mue*(2. + xil*((2.*1j)/nPi + 2.*1j*nPi*zee)) + xil**2*zef
    coeff2 = 1. + mue*(-3. - nPi**2*zee) - (1j*xil*(1. + nPi**2*zef))/nPi
    coeff3 = 1./3.*(-3. - nPi**2*zef)
    dfbyf = coeff0 + coeff1 * muf + coeff2 * muf**2 + coeff3 * muf**3
    Dfcbyn = f_fund*dfbyf
    return Dfcbyn

def Perturbation_5(d,rho,J,vers,AspRat,n,f_fund,Zq,Show_lay1,Show_lay2,Show_bulk):
    mue,muf,xil,zee,zef,nPi = \
      Assign_Vals_for_Perturbation(d,rho,J,vers,AspRat,n,f_fund,Zq,Show_lay1,Show_lay2,Show_bulk)
    coeff0 =((1j*xil)/nPi) + (1j*xil**3)/(3.*nPi) + (1j*xil**5)/(5.*nPi) + \
        1./15.*mue**5*(-15. - 50.*nPi**2*zee + nPi**4.*zee - 2.*nPi**4*zee**2) + \
        mue*(-1 - (1j*xil)/nPi + xil**2*zee + xil**4*zee + \
        xil**3*(-1j/(3.*nPi) + (1j*zee)/nPi)) + \
        mue**2*(1 - 4.*xil**2*zee + xil*((1j/nPi) + 1j*nPi*zee) + \
        xil**3*((1j/(3.*nPi)) - (3.*1j*zee)/nPi + 1j*nPi*zee - 1j*nPi*zee**2)) + \
        mue**3*(-1. - (nPi**2*zee)/3. + xil*(-1j/nPi - 4.*1j*nPi*zee) + \
        xil**2*(10.*zee - (2.*nPi**2*zee)/3. + (4.*nPi**2*zee**2)/3.)) + \
        mue**4*(1. + (4.*nPi**2*zee)/3. + \
        xil*((1j/nPi) + 10.*1j*nPi*zee - 1./3.*1j*nPi**3*zee + 2./3.*1j*nPi**3*zee**2))
    coeff1 = -1. - (1j*xil)/nPi + \
        1./3.*mue**4*(-15. - 50.*nPi**2*zee + nPi**4*zee - 2.*nPi**4*zee**2) + \
        mue**3*(4. + (16.*nPi**2*zee)/3. + \
        xil*(((4*1j)/nPi) + 40.*1j*nPi*zee - 4./3.*1j*nPi**3*zee + \
        8./3.*1j*nPi**3*zee**2)) + xil**2*zef + xil**4*zef \
        +(1j*xil**3*(-1. + 3.*zef))/(3.*nPi) + \
        mue*(2. + xil*(((2.*1j)/nPi) + 2.*1j*nPi*zee) + xil**2*(-6.*zee - 2.*zef) + \
        xil**3*(((2*1j)/(3*nPi)) - (4*1j*zee)/nPi + 2.*1j*nPi*zee - (2*1j*zef) / \
        nPi - 2.*1j*nPi*zee*zef)) + \
        mue**2*(-3. - nPi**2*zee + xil*(-(3.*1j)/nPi - 12.*1j*nPi*zee) + \
        xil**2*(27.*zee - 2.*nPi**2*zee + 3.*nPi**2*zee**2 + 3.*zef + \
        nPi**2*zee*zef))
    coeff2 = 1 - 2./3.*mue**3*(15. + 50.*nPi**2*zee - nPi**4*zee + 2.*nPi**4*zee**2) - \
        4*xil**2*zef + (1j*xil*(1. + nPi**2*zef))/nPi - \
        (1j*xil**3*(-1. + 9.*zef - 3.*nPi**2*zef + 3.*nPi**2*zef**2))/(3.*nPi) + \
        mue*(-3. - nPi**2*zee + xil*(-(3.*1j)/nPi - 9.*1j*nPi*zee - 3*1j*nPi*zef) + \
        xil**2*(18.*zee - 2.*nPi**2*zee + 12.*zef + 4.*nPi**2*zee*zef)) + \
        mue**2*(6. + 8.*nPi**2*zee + \
        xil*(((6.*1j)/nPi) + 54.*1j*nPi*zee - 2.*1j*nPi**3*zee + 3.*1j*nPi**3*zee**2 +\
        6.*1j*nPi*zef + 1j*nPi**3*zee*zef))
    coeff3 =  1./3.*(-3. - nPi**2*zef) + 2./3.*xil**2*zef*(15. - nPi**2 + 2.*nPi**2*zef) - \
        (1j*xil*(1. + 4.*nPi**2*zef))/nPi + \
        1./3.*mue**2*(-30. - 90.*nPi**2*zee + 2.*nPi**4*zee - 3.*nPi**4*zee**2 - \
        10.*nPi**2*zef - nPi**4*zee*zef) + \
        mue*(4. + 4.*nPi**2*zee + (4.*nPi**2*zef)/3. + \
        xil*(((4*1j)/nPi) + 24.*1j*nPi*zee - 4./3.*1j*nPi**3*zee + 16.*1j*nPi*zef +\
        8./3.*1j*nPi**3*zee*zef))
    coeff4 = 1./3.*(3. + 4.*nPi**2*zef) + \
        1./3.*mue*(-15. - 30.*nPi**2*zee + nPi**4*zee - 20.*nPi**2*zef -\
        2.*nPi**4*zee*zef) + \
        ( 1j*xil*(3. + 30.*nPi**2*zef - nPi**4*zef + 2.*nPi**4*zef**2))/(3.*nPi)
    coeff5 =1./15.*(-15. - 50.*nPi**2*zef + nPi**4*zef - 2.*nPi**4*zef**2)
    dfbyf = coeff0 + coeff1 * muf + coeff2 * muf**2 + coeff3 * muf**3 + coeff4 * muf**4 + coeff5 * muf**5
    Dfcbyn = f_fund*dfbyf
    return Dfcbyn

