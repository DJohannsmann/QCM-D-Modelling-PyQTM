import numpy as np
import QTM_Core as Cor
import os
import tkinter as tk

def Get_Labels_TT_header(): 
    global Graph_TT_Labels,header_Labels
    Graph_TT_Labels = dict(zip(Cor.keys,''))
    header_Labels   = dict(zip(Cor.keys,''))

    Graph_TT_Labels['t_lay1'] = '$t_{1}$ [nm]'
    Graph_TT_Labels['t_lay2'] = '$t_{2}$ [nm]'
    Graph_TT_Labels['rho_lay3'] = '$\rho_{1}$ [g/cm$^{3}]$'
    Graph_TT_Labels['rho_lay1'] = '$\rho_{2}$ [g/cm$^{3}]$'
    Graph_TT_Labels['rho_lay1'] = '$\rho_{bulk}$ [g/cm$^{3}]$'
    Graph_TT_Labels['VEPar1_PLexpt_lay1'] = '$\\beta^{\prime}_{1}$'
    Graph_TT_Labels['VEPar2_PLexpt_lay1'] = '$\\beta^{\prime\prime}_{1}$'
    Graph_TT_Labels['VEPar1_PLexpt_lay2'] = '$\\beta^{\prime}_{2}$'
    Graph_TT_Labels['VEPar2_PLexpt_lay2'] = '$\\beta^{\prime\prime}_{2}$'
    Graph_TT_Labels['VEPar1_PLexpt_lay3'] = '$\\beta^{\prime}_{bulk}$'
    Graph_TT_Labels['VEPar2_PLexpt_lay3'] = '$\\beta^{\prime\prime}_{bulk}$'
    Graph_TT_Labels['VertScaleR'] = '$h_{r}$ [nm]'
    Graph_TT_Labels['AspRat'] = 'aspect ratio'

    header_Labels['t_lay1'] = 'thickness_1[nm]'
    header_Labels['t_lay2'] = 'thickness_2[nm]'
    header_Labels['rho_lay3'] = 'rho_1[g/cm^3]'
    header_Labels['rho_lay1'] = 'rho_2[g/cm^3]'
    header_Labels['rho_lay3'] = 'rho_bulk[g/cm^3]'
    header_Labels['VertScaleR'] = 'roughn_vert_scale[nm]'
    header_Labels['AspRat'] = 'AspectRatio'
    header_Labels['VEPar1_PLexpt_lay1'] = 'beta\'_1'
    header_Labels['VEPar2_PLexpt_lay1'] = 'beta\'\'_1'
    header_Labels['VEPar1_PLexpt_lay2'] = 'beta\'_2'
    header_Labels['VEPar2_PLexpt_lay2'] = 'beta\'\'_2'
    header_Labels['VEPar1_PLexpt_lay3'] = 'beta\'_3'
    header_Labels['VEPar2_PLexpt_lay3'] = 'beta\'\'_3'
    if Cor.SamplePars['VEtype_lay1'] == 0 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$J^{\prime}_{1}$ [MPa$^{-1}$]'  
        Graph_TT_Labels['VEPar2_lay1'] = '$J^{\prime\prime}_{1}$ [MPa$^{-1}$]'
        header_Labels['VEPar1_lay1'] = 'J\'_1[MPa^-1]'  
        header_Labels['VEPar2_lay1'] = 'J\'\'_1[MPa^-1]'
    if Cor.SamplePars['VEtype_lay1'] == 1 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$G^{\prime}_{1}$ [MPa]'  
        Graph_TT_Labels['VEPar2_lay1'] = '$G^{\prime\prime}_{1}$ [MPa]'  
        header_Labels['VEPar1_lay1'] = 'G\'_1[MPa]'  
        header_Labels['VEPar2_lay1'] = 'G\'\'_1[MPa]'  
    if Cor.SamplePars['VEtype_lay1'] == 2 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$\eta^{\prime}_{1}$ [mPa s]'  
        Graph_TT_Labels['VEPar2_lay1'] = '$\eta^{\prime\prime}_{1}$ [mPa s]'  
        header_Labels['VEPar1_lay1'] = 'eta\'_1[mPa_s]'  
        header_Labels['VEPar2_lay1'] = 'eta\'\'_1[mPa_s]'  
    if Cor.SamplePars['VEtype_lay1'] == 3 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$G^{\prime}_{1}$ [MPa]'  
        Graph_TT_Labels['VEPar2_lay1'] = '$\eta^{\prime}_{1}$ [mPa s]' 
        header_Labels['VEPar1_lay1'] = 'G\'_1[MPa]'  
        header_Labels['VEPar2_lay1'] = 'eta\'_1[mPa_s]' 
    if Cor.SamplePars['VEtype_lay1'] == 4 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$|J_{1}|$ [MPa$^{-1}$]'  
        Graph_TT_Labels['VEPar2_lay1'] = 'tan $\delta_{1}$'  
        header_Labels['VEPar1_lay1'] = '|J_1|[MPa^-1]'  
        header_Labels['VEPar2_lay1'] = 'tan_delta_1'  
    if Cor.SamplePars['VEtype_lay1'] == 5 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$|G_{1}$| [MPa]' 
        Graph_TT_Labels['VEPar2_lay1'] = 'tan $\delta_{1}$'  
        header_Labels['VEPar1_lay1'] = '|G_1|[MPa]' 
        header_Labels['VEPar2_lay1'] = 'tan_delta_1'  
    if Cor.SamplePars['VEtype_lay1'] == 6 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$|\eta_{1}$| [mPa s]'
        Graph_TT_Labels['VEPar2_lay1'] = '(tan $\delta_{bulk}$)$^{-1}$'
        header_Labels['VEPar1_lay1'] = '|eta_1|_[mPa_s]'
        header_Labels['VEPar2_lay1'] = '(tan_delta_bulk)^-1'
    
    if Cor.SamplePars['VEtype_lay2'] == 0 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$J^{\prime}_{2}$ [MPa$^{-1}$]'  
        Graph_TT_Labels['VEPar2_lay2'] = '$J^{\prime\prime}_{2}$ [MPa$^{-1}$]'
        header_Labels['VEPar1_lay2'] = 'J\'_2[MPa^-1]'  
        header_Labels['VEPar2_lay2'] = 'J\'\'_2[MPa^-1]'
    if Cor.SamplePars['VEtype_lay2'] == 1 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$G^{\prime}_{2}$ [MPa]'  
        Graph_TT_Labels['VEPar2_lay2'] = '$G^{\prime\prime}_{2}$ [MPa]'  
        header_Labels['VEPar1_lay2'] = 'G\'_2 MPa]'  
        header_Labels['VEPar2_lay2'] = 'G\'\'_2[MPa]'  
    if Cor.SamplePars['VEtype_lay2'] == 2 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$\eta^{\prime}_{2}$ [mPa s]'  
        Graph_TT_Labels['VEPar2_lay2'] = '$\eta^{\prime\prime}_{2}$ [mPa s]'  
        header_Labels['VEPar1_lay2'] = 'eta\'_2[mPa_s]'  
        header_Labels['VEPar2_lay2'] = 'eta\'\'_2[mPa_s]'  
    if Cor.SamplePars['VEtype_lay2'] == 3 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$G^{\prime}_{2}$ [MPa]'  
        Graph_TT_Labels['VEPar2_lay2'] = '$\eta^{\prime}_{2}$ [mPa s]' 
        header_Labels['VEPar1_lay2'] = 'G\'_2[MPa]'  
        header_Labels['VEPar2_lay2'] = 'eta\'_2[mPa_s]' 
    if Cor.SamplePars['VEtype_lay2'] == 4 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$|J_{2}|$ [MPa$^{-1}$]'  
        Graph_TT_Labels['VEPar2_lay2'] = 'tan $\delta_{2}$'  
        header_Labels['VEPar1_lay2'] = '|J_2| [MPa^-1]'  
        header_Labels['VEPar2_lay2'] = 'tan_delta_2'  
    if Cor.SamplePars['VEtype_lay2'] == 5 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$|G_{2}$| [MPa]' 
        Graph_TT_Labels['VEPar2_lay2'] = 'tan $\delta_{2}$'  
        header_Labels['VEPar1_f '] = '|G_2|_[MPa]' 
        header_Labels['VEPar2_lay2'] = 'tan_delta_2'  
    if Cor.SamplePars['VEtype_lay2'] == 6 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$|\eta_{2}$| [mPa s]'
        Graph_TT_Labels['VEPar2_lay2'] = '(tan $\delta_{bulk}$)$^{-1}$'
        header_Labels['VEPar1_lay2'] = '|eta_2| [mPa_s]'
        header_Labels['VEPar2_lay2'] = '(tan_delta_bulk)^-1'

    if Cor.SamplePars['VEtype_lay3'] == 0 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$J^{\prime}_{bulk}$ [MPa$^{-1}$]'  
        Graph_TT_Labels['VEPar2_lay3'] = '$J^{\prime\prime}_{bulk}$ [MPa$^{-1}$]'
        header_Labels['VEPar1_lay3'] = 'J\'_bulk[MPa^-1]'  
        header_Labels['VEPar2_lay3'] = 'J\'\'_bulk[MPa^-1]'
    if Cor.SamplePars['VEtype_lay3'] == 1 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$G^{\prime}_{bulk}$ [MPa]'  
        Graph_TT_Labels['VEPar2_lay3'] = '$G^{\prime\prime}_{bulk}$ [MPa]'  
        header_Labels['VEPar1_lay3'] = 'G\'_bulk[MPa]'  
        header_Labels['VEPar2_lay3'] = 'G\'\'_bulk[MPa]'  
    if Cor.SamplePars['VEtype_lay3'] == 2 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$\eta^{\prime}_{bulk}$ [mPa s]'  
        Graph_TT_Labels['VEPar2_lay3'] = '$\eta^{\prime\prime}_{bulk}$ [mPa s]'  
        header_Labels['VEPar1_lay3'] = 'eta\'_bulk[mPa_s]'  
        header_Labels['VEPar2_lay3'] = 'eta\'\'_bulk_[mPa_s]'  
    if Cor.SamplePars['VEtype_lay3'] == 3 : 
        Graph_TT_Labels['VEPar1_lay3']  = '$G^{\prime}_{bulk}$ [MPa]'  
        Graph_TT_Labels['VEPar2_lay3'] = '$\eta^{\prime}_{bulk}$ [mPa s]' 
        header_Labels['VEPar1_lay3']  = 'G\'_bulk[MPa]'  
        header_Labels['VEPar2_lay3'] = 'eta\'_bulk[mPa_s]' 
    if Cor.SamplePars['VEtype_lay3'] == 4 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$|J_{bulk}|$ [MPa$^{-1}$]'  
        Graph_TT_Labels['VEPar2_lay3'] = 'tan $\delta_{bulk}$'  
        header_Labels['VEPar1_lay3'] = '|J_bulk|[MPa^-1]'  
        header_Labels['VEPar2_lay3'] = 'tan_delta_bulk'  
    if Cor.SamplePars['VEtype_lay3'] == 5 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$|G_{bulk}$| [MPa]' 
        Graph_TT_Labels['VEPar2_lay3'] = 'tan $\delta_{bulk}$'  
        header_Labels['VEPar1_lay3'] = '|G_bulk|[MPa]' 
        header_Labels['VEPar2_lay3'] = 'tan_delta_bulk'  
    if Cor.SamplePars['VEtype_lay3'] == 6 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$|\eta_{bulk}$| [mPa s]'
        Graph_TT_Labels['VEPar2_lay3'] = '(tan $\delta_{bulk}$)$^{-1}$'
        header_Labels['VEPar1_lay3'] = '|eta_bulk|[mPa_s]'
        header_Labels['VEPar2_lay3'] = '(tan_delta_bulk)^-1'

def Get_FParnames(): 
    global FParnames 
    FParnames = []
    for key in Cor.keys:
        if Cor.IncPars[key] == 1:
            name = header_Labels[key].replace('[','_')
            name = name.replace(']','')
            name = name.replace('\'','p')
            name = name.replace('|','')
            name = name.replace('(','')
            name = name.replace(')','')
            name = name.replace('^','')
            name = name.replace('-','_m')
            name = name.replace(' ','')
            FParnames.append(name)

def FPars_String():
    FPars_String = ''; iFPar = 0
    for key in Cor.keys:
        if Cor.IncPars[key] == 1:
            FPars_String += header_Labels[key] + ' '
            iFPar += 1
    return FPars_String 

def Recognize_Instrument():
    f = open(Cor.TT_filename,"r"); lines = f.readlines(); f.close()
    line = lines[0]
    Cor.TT_IO_Format = ''
    if 'df_' in line: 
        Cor.TT_IO_Format = 'from_QTZ' 

    if 'F_1:1' in line or 'F_1:3' in line or 'F_1:5' in line or 'F_1:7' in line or 'F_1:9' in line or 'F_1:11' in line or 'F_1:13' in line or \
       'F_2:1' in line or 'F_2:3' in line or 'F_2:5' in line or 'F_2:7' in line or 'F_2:9' in line or 'F_2:11' in line or 'F_2:13' in line or \
       'F_2:1' in line or 'F_3:3' in line or 'F_3:5' in line or 'F_3:7' in line or 'F_3:9' in line or 'F_3:11' in line or 'F_3:13' in line or \
       'F_2:1' in line or 'F_4:3' in line or 'F_4:5' in line or 'F_4:7' in line or 'F_4:9' in line or 'F_4:11' in line or 'F_4:13' in line:
        Cor.TT_IO_Format = 'from_QSoft'

    if 'f1_1' in line or 'f3_1' in line or 'f5_1' in line or 'f7_1' in line or 'f9_1' in line or 'f11_1' in line or 'f13_1' in line or \
       'f1_2' in line or 'f3_2' in line or 'f5_2' in line or 'f7_2' in line or 'f9_2' in line or 'f11_2' in line or 'f13_2' in line or \
       'f1_3' in line or 'f3_3' in line or 'f5_3' in line or 'f7_3' in line or 'f9_3' in line or 'f11_3' in line or 'f13_3' in line or \
       'f1_4' in line or 'f3_4' in line or 'f5_4' in line or 'f7_4' in line or 'f9_4' in line or 'f11_4' in line or 'f13_4' in line:
        Cor.TT_IO_Format = 'from_QSoft_new'
        Cor.i_channel = tk.simpledialog.askinteger('','channel (1,2,3,or 4)') - 1
    if 'Delta_F' in line: Cor.TT_IO_Format = 'from_AWSensors'
    if Cor.TT_IO_Format == '': tk.messagebox.showinfo('','format not recognized') 

def Analyze_header_line_QTZ(line):
    global Do_Import,i_cols
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms = ['df_1.','df_3.','df_5.','df_7.','df_9.','df_11.','df_13.']
    count = 0
    i_cols = np.zeros((Cor.novt),dtype=int)
    for iovt in range(Cor.novt):
        if SearchTerms[iovt] in line: 
            Do_Import[iovt] = 1
            i_cols[iovt] = 1 + 2 * count
            count += 1

def Analyze_header_line_QSoft(line):
    global Do_Import,i_cols
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms1 = ['F_1:1','F_1:3','F_1:5','F_1:7','F_1:9','F_1:11','F_1:13']
    SearchTerms2 = ['F_2:1','F_2:3','F_2:5','F_2:7','F_2:9','F_2:11','F_2:13']
    SearchTerms3 = ['F_3:1','F_3:3','F_3:5','F_3:7','F_3:9','F_3:11','F_3:13']
    SearchTerms4 = ['F_4:1','F_4:3','F_4:5','F_4:7','F_4:9','F_4:11','F_4:13']
    Do_Import = np.zeros(Cor.novt,dtype = int)
    count = 0
    i_cols = np.ones((Cor.novt),dtype = int)*np.nan
    for iovt in range(Cor.novt):
        if SearchTerms1[iovt] in line or SearchTerms2[iovt] in line or \
           SearchTerms3[iovt] in line or SearchTerms4[iovt] in line: 
            Do_Import[iovt] = 1
            i_cols[iovt] = 1 + 2 * count
            count += 1
    i_cols = i_cols.astype(int)        

def Analyze_header_line_QSoft_new(line):
    global Do_Import_new,i_cols_new,i_cols_time
    i_cols_new  = np.ones((4,Cor.novt),dtype = int)*np.nan
    i_cols_time = np.ones((4),dtype = int)*np.nan
    Do_Import_new = np.zeros((4,Cor.novt),dtype = int)
    n_tones = np.zeros((4),dtype = int)
    SearchTerms = np.array([['f1_1','f3_1','f5_1','f7_1','f9_1','f11_1','f13_1'],\
                            ['f1_2','f3_2','f5_2','f7_2','f9_2','f11_2','f13_2'],
                            ['f1_3','f3_3','f5_3','f7_3','f9_3','f11_3','f13_3'],
                            ['f1_4','f3_4','f5_4','f7_4','f9_4','f11_4','f13_4']])
    for ichan in range(4):
        for iovt in range(Cor.novt):
            if SearchTerms[ichan,iovt] in line: Do_Import_new[ichan,iovt] = 1
    n_tones = np.sum(Do_Import_new,axis = 1)
    count = 0 
    for ichan in range(4):
        if n_tones[ichan] > 0:
            i_cols_time[ichan] = count
            for iovt in range(Cor.novt):
                i_cols_new[ichan,iovt] = count + 1 + 2 * np.sum(Do_Import_new[ichan,:iovt])
            count += 2 * n_tones[ichan] + 1
    i_cols_new  = i_cols_new.astype(int)        
    i_cols_time = i_cols_time.astype(int)

def Analyze_header_line_AWSensors(line):
    global Do_Import,i_cols
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms = ['Delta_F/n_n=1_','Delta_F/n_n=3_',\
                   'Delta_F/n_n=5_','Delta_F/n_n=7_',\
                   'Delta_F/n_n=9_','Delta_F/n_n=11_','Delta_F/n_n=13_']
    count = 0
    i_cols = np.ones((Cor.novt),dtype = int)*np.nan
    for iovt in range(Cor.novt):
        if SearchTerms[iovt] in line: 
            Do_Import[iovt] = 1
            i_cols[iovt] = 1 + count
            count += 1
    i_cols = i_cols.astype(int)        

def Import_from_QTZ():
    global time_TT,Dfbyn_TT,DGbyn_TT
    f = open(Cor.TT_filename,"r"); lines = f.readlines(); f.close()
    for il in range(1,len(lines)): lines[il] = lines[il].replace(',','.')
    Analyze_header_line_QTZ(lines[0])    
    time_TT  = np.ones(len( lines)          )*np.nan
    Dfbyn_TT = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_TT = np.ones((len(lines),Cor.novt))*np.nan
    n_tones = np.sum(Do_Import)
    count = 0
    il = 0
    while il < len(lines)-1:
        time_for_avg  = np.ones( Cor.n_pre_avg          )*np.nan
        Dfbyn_for_avg = np.ones((Cor.n_pre_avg,Cor.novt))*np.nan
        DGbyn_for_avg = np.ones((Cor.n_pre_avg,Cor.novt))*np.nan
        Lines_long_enough = True
        for j in range(Cor.n_pre_avg):
            il = Cor.n_pre_avg*count+j+1
            if il < len(lines):
                cols = lines[Cor.n_pre_avg*count+j+1].split()
                if len(cols) < 2 * n_tones + 1: Lines_long_enough = False 
        if Lines_long_enough:
            if il < len(lines):
                for j in range(Cor.n_pre_avg):
                    cols = lines[Cor.n_pre_avg*count+j+1].split()
                    time_for_avg[j] = np.float(cols[0])
                    for iovt in range(Cor.novt):
                        if Do_Import[iovt]: 
                            Dfbyn_for_avg[j,iovt] = np.float(cols[i_cols[iovt]    ])/Cor.n_arr[iovt]
                            DGbyn_for_avg[j,iovt] = np.float(cols[i_cols[iovt] + 1])/Cor.n_arr[iovt]
        try:                     
            time_TT[ count] = np.nanmean(time_for_avg)
            Dfbyn_TT[count] = np.nanmean(Dfbyn_for_avg,axis=0)
            DGbyn_TT[count] = np.nanmean(DGbyn_for_avg,axis=0)
        except: pass    
        count += 1
    time_TT  = time_TT[:count]
    Dfbyn_TT = Dfbyn_TT[:count]
    DGbyn_TT = DGbyn_TT[:count]

def Import_from_QSoft():
    global time_TT,Dfbyn_TT,DGbyn_TT
    f = open(Cor.TT_filename,"r"); lines = f.readlines(); f.close()
    for il in range(1,len(lines)): lines[il] = lines[il].replace(',','.')
    Analyze_header_line_QSoft(lines[0])    
    time_TT  = np.ones( len(lines)          )*np.nan
    Dfbyn_TT = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_TT = np.ones((len(lines),Cor.novt))*np.nan
    n_tones = np.sum(Do_Import)
    count = 0 
    il = 0
    while il < len(lines) - 1:
        time_for_avg  = np.ones( Cor.n_pre_avg          )*np.nan
        Dfbyn_for_avg = np.ones((Cor.n_pre_avg,Cor.novt))*np.nan
        DGbyn_for_avg = np.ones((Cor.n_pre_avg,Cor.novt))*np.nan
        Lines_long_enough = True
        for j in range(Cor.n_pre_avg):
            il = Cor.n_pre_avg*count+j+1
            if il < len(lines) - 1:
                cols = lines[Cor.n_pre_avg*count+j+1].split()
                if len(cols) < 2 * n_tones + 1: Lines_long_enough = False 
        if Lines_long_enough: 
            for j in range(Cor.n_pre_avg):
                if il < len(lines) - 1:
                    cols = lines[Cor.n_pre_avg*count+j+1].split()
                    time_for_avg[j] = np.float(cols[0])
                    for iovt in range(Cor.novt):
                        if Do_Import[iovt]: 
                            Dfbyn_for_avg[j,iovt] = np.float(cols[i_cols[iovt]    ])                    
                            DGbyn_for_avg[j,iovt] = np.float(cols[i_cols[iovt] + 1]) * Cor.f_fund/2./1e6
        try:
            time_TT[ count] = np.nanmean(time_for_avg)
            Dfbyn_TT[count] = np.nanmean(Dfbyn_for_avg,axis=0)
            DGbyn_TT[count] = np.nanmean(DGbyn_for_avg,axis=0)
        except: pass    
        count += 1
    time_TT  = time_TT[ :count]
    Dfbyn_TT = Dfbyn_TT[:count]
    DGbyn_TT = DGbyn_TT[:count]

def Import_from_QSoft_new():
    global time_TT,Dfbyn_TT,DGbyn_TT
    f = open(Cor.TT_filename,"r"); lines = f.readlines(); f.close()
    for il in range(1,len(lines)): lines[il] = lines[il].replace(',','.')
    Analyze_header_line_QSoft_new(lines[0])    
    time_TT  = np.ones( len(lines)          )*np.nan
    Dfbyn_TT = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_TT = np.ones((len(lines),Cor.novt))*np.nan
    count = 0
    il = 0
    while il < len(lines) - 1:
        time_for_avg  = np.ones( Cor.n_pre_avg          )*np.nan
        Dfbyn_for_avg = np.ones((Cor.n_pre_avg,Cor.novt))*np.nan
        DGbyn_for_avg = np.ones((Cor.n_pre_avg,Cor.novt))*np.nan
            
        for j in range(Cor.n_pre_avg):
            il = Cor.n_pre_avg*count+j+1
            if il < len(lines) - 1:
                cols = lines[Cor.n_pre_avg*count+j+1].split()
                if i_cols_time[Cor.i_channel] <= len(cols)-1:
                    time_for_avg[j] = np.float(cols[i_cols_time[Cor.i_channel]])
                    for iovt in range(Cor.novt):
                        if Do_Import_new[Cor.i_channel,iovt]: 
                            Dfbyn_for_avg[j,iovt] = np.float(cols[i_cols_new[Cor.i_channel,iovt]    ])/Cor.n_arr[iovt]  
                            DGbyn_for_avg[j,iovt] = np.float(cols[i_cols_new[Cor.i_channel,iovt] + 1])*Cor.f_fund/2./1e6
        try: 
            time_TT[ count] = np.nanmean(time_for_avg)
            Dfbyn_TT[count] = np.nanmean(Dfbyn_for_avg,axis=0)
            DGbyn_TT[count] = np.nanmean(DGbyn_for_avg,axis=0)
        except: pass    
        count += 1
    time_TT  = time_TT[ :count]
    Dfbyn_TT = Dfbyn_TT[:count] - Dfbyn_TT[0]
    DGbyn_TT = DGbyn_TT[:count] - DGbyn_TT[0]

def Import_from_AWSensors():
    global time_TT,Dfbyn_TT,DGbyn_TT
    f = open(Cor.TT_filename,"r"); lines = f.readlines(); f.close()
    for il in range(1,len(lines)): lines[il] = lines[il].replace(',','.')
    Analyze_header_line_AWSensors(lines[0])    
    time_TT  = np.ones( len(lines)          )*np.nan
    Dfbyn_TT = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_TT = np.ones((len(lines),Cor.novt))*np.nan
    n_tones = np.sum(Do_Import)
    count = 0
    il = 0
    while il < len(lines) - 1:
        time_for_avg  = np.ones( Cor.n_pre_avg          )*np.nan
        Dfbyn_for_avg = np.ones((Cor.n_pre_avg,Cor.novt))*np.nan
        DGbyn_for_avg = np.ones((Cor.n_pre_avg,Cor.novt))*np.nan
        Lines_long_enough = True
        for j in range(Cor.n_pre_avg):
            il = Cor.n_pre_avg*count+j+1
            if il < len(lines):
                cols = lines[Cor.n_pre_avg*count+j+1].split()
                if len(cols) < 2 * n_tones + 1: Lines_long_enough = False 
        if Lines_long_enough: 
            for j in range(Cor.n_pre_avg):
                if il < len(lines):
                    cols = lines[Cor.n_pre_avg*count+j+1].split()
                    time_for_avg[j] = np.float(cols[0])
                    for iovt in range(Cor.novt):
                        if Do_Import[iovt]: 
                            Dfbyn_for_avg[j,iovt] = np.float(cols[i_cols[iovt]])                          
                            DGbyn_for_avg[j,iovt] = np.float(cols[i_cols[iovt] + n_tones]) * Cor.f_fund/2.
        try: 
            time_TT[ count] = np.nanmean(time_for_avg)
            Dfbyn_TT[count] = np.nanmean(Dfbyn_for_avg,axis=0)
            DGbyn_TT[count] = np.nanmean(DGbyn_for_avg,axis=0)
        except: pass    
        count += 1
    time_TT  = time_TT[ :count]
    Dfbyn_TT = Dfbyn_TT[:count]
    DGbyn_TT = DGbyn_TT[:count]
        
def Import_TT():
    global DfDGbyns,TT_FPars 
    if Cor.TT_IO_Format == 'Automatic'     : Recognize_Instrument()         
    if Cor.TT_IO_Format == 'from_QTZ'      : Import_from_QTZ()
    if Cor.TT_IO_Format == 'from_QSoft'    : Import_from_QSoft()
    if Cor.TT_IO_Format == 'from_QSoft_new': Import_from_QSoft_new()
    if Cor.TT_IO_Format == 'from_AWSensors': Import_from_AWSensors()
    DfDGbyns = np.ones((len(Dfbyn_TT),2+4*Cor.novt))*np.nan
    for it in range(len(Dfbyn_TT)):
        DfDGbyns[it,0]=it
        DfDGbyns[it,1]=time_TT[it]
        for iovt in range(Cor.novt):
            DfDGbyns[it,2+4*iovt  ] = Dfbyn_TT[it,iovt]
            DfDGbyns[it,2+4*iovt+1] = DGbyn_TT[it,iovt]
    if Cor.i_selec     > len(DfDGbyns-1): Cor.i_selec     = 0 
    if Cor.i_strt_fit > len(DfDGbyns-1): Cor.i_strt_fit = 0 
    if Cor.i_stop_fit  > len(DfDGbyns-1): Cor.i_stop_fit  = 0 
    if Cor.i_current   > len(DfDGbyns-1): Cor.i_current   = 0 
    Cor.i_strt_hide_TT = 0; Cor.i_stop_hide_TT = 0 
    Cor.i_strt_zoom_TT = 0; Cor.i_stop_zoom_TT = len(DfDGbyns);   
    Cor.i_strt_zoom_FP = 0; Cor.i_stop_zoom_FP = len(TT_FPars); 
    for iovt in range(Cor.novt):
        Cor.Dfbyns[iovt] = DfDGbyns[Cor.i_selec,2+4*iovt  ]
        Cor.DGbyns[iovt] = DfDGbyns[Cor.i_selec,2+4*iovt+1]
    Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns
    Cor.Fit_done = 'no' 
    if Cor.i_stop_fit > Cor.i_strt_fit + 2:  
        if len(DfDGbyns) > 2: get_rms_noise()
        else                : Cor.rms = np.nan
    else: get_rms_noise()     
    for it in range(len(DfDGbyns)):
        if DfDGbyns[it,1] == 0: DfDGbyns[it,:] = np.nan 
    if Cor.TT_Correct_Drift == 'yes': DfDGbyns = Correct_for_Drift(DfDGbyns)
    Make_headers()
    np.savetxt('~tmp.qtf'           ,DfDGbyns,header = header_DfDGbyns,delimiter='\t',newline = '\n')
    np.savetxt('~tmp_for_unhide.qtf',DfDGbyns,header = header_DfDGbyns,delimiter='\t',newline = '\n')
    
    try: TT_FPars[:,:] = np.nan
    except: pass
    if len(TT_FPars) < len(DfDGbyns):
        TT_FPars = np.ones((len(DfDGbyns),2+2*Cor.nFParsmax+1))*np.nan
    np.savetxt('~tmp.qtd',TT_FPars,header = header_FPars_qtd,delimiter='\t',newline = '\n')
    Cor.i_strt_hide_TT = 0; Cor.FP_i_strt_hide_TT = 0
    Cor.i_stop_hide_TT = 0; Cor.FP_i_stop_hide_TT = 0
    for iovt in range(Cor.novt): Cor.OvtInc[iovt] = 1
    Cor.Write_Config()

def Correct_for_Drift(DfDGbyns):
    DfDGbyns_DrifC = np.ones((len(Dfbyn_TT),2+4*Cor.novt))*np.nan
    DfDGbyns_DrifC[:,0] = DfDGbyns[:,0]
    DfDGbyns_DrifC[:,1] = DfDGbyns[:,1]
    for it in range(len(DfDGbyns)-1):
        count = 0
        for iovt in range(Cor.novt):
            if not np.isnan(DfDGbyns[it,2+4*iovt  ]) and not np.isnan(DfDGbyns[it+1,2+4*iovt  ]):  
                DfDGbyns_DrifC[it,2+4*iovt  ] = DfDGbyns[it,2+4*iovt  ]-count/len(Cor.ns_inc)/Cor.n_pre_avg*\
                     (DfDGbyns[it+1,2+4*iovt]-DfDGbyns[it,2+4*iovt])
            count += 1         
        count = 0
        for iovt in range(Cor.novt):
            if not np.isnan(DfDGbyns[it,2+4*iovt+1]) and not np.isnan(DfDGbyns[it+1,2+4*iovt+1]):  
                DfDGbyns_DrifC[it,2+4*iovt+1] = DfDGbyns[it,2+4*iovt+1]-count/len(Cor.ns_inc)/Cor.n_pre_avg*\
                     (DfDGbyns[it+1,2+4*iovt+1]-DfDGbyns[it,2+4*iovt+1])
            count += 1         
    DfDGbyns = DfDGbyns_DrifC
    return DfDGbyns

def get_rms_noise():
    Hadamard = np.ones((Cor.novt,len(DfDGbyns)))*np.nan
    if Cor.i_strt_fit == 0 and Cor.i_stop_fit == 0: 
        strt = 0; stop = len(DfDGbyns)
    else: 
        strt = Cor.i_strt_fit; stop = Cor.i_stop_fit
    if stop > strt + 2 and stop < len(DfDGbyns)-2:
        for iovt in range(Cor.novt):
            if Cor.OvtInc[iovt] == 1:
                for it in range(strt+1,stop-3):
                    Hadamard[iovt,it-1] = \
                        1./6. * ((DfDGbyns[it-1,2+4*iovt  ] - 2.* DfDGbyns[it,2+4*iovt  ] + DfDGbyns[it+1,2+4*iovt  ])**2 +\
                                 (DfDGbyns[it-1,2+4*iovt+1] - 2.* DfDGbyns[it,2+4*iovt+1] + DfDGbyns[it+1,2+4*iovt+1])**2)
        try : Cor.rms_noise = np.nanmean(Hadamard)**0.5
        except: Cor.rms_noise = np.nan
    else: Cor.rms_noise = np.nan        
        
def Make_headers():
    global header_FPars_qtr,header_FPars_qtd,header_DfDGbyns
    header_FPars_qtr = 'data_point \t time[a.u.] \t'
    header_FPars_qtd = 'data_point \t time[a.u.] \t'
    header_DfDGbyns  = 'data_point \t time[a.u.] \t'
    
    for key in Cor.keys: 
        if Cor.IncPars[key] == 1:
            header_FPars_qtr += header_Labels[key] + '\t' + header_Labels[key]+'_StdErr \t'
            header_FPars_qtd += header_Labels[key] + '\t' + header_Labels[key]+'_StdErr \t'
    for iFPar in range(Cor.nFPars,Cor.nFParsmax):
            header_FPars_qtd += 'NotFreePar \t NotFreePar_+_StdErr \t'
    header_FPars_qtr += 'chi^2 \t'
    header_FPars_qtd += 'chi^2 \t'
    for iovt in range(Cor.novt):
        header_DfDGbyns += 'Dfbyn_'    + str(Cor.n_arr[iovt]) + '\t' + 'DGbyn_'    + str(Cor.n_arr[iovt]) + '\t' + \
                           'Dfbyn_fit_'+ str(Cor.n_arr[iovt]) + '\t' + 'DGbyn_fit_'+ str(Cor.n_arr[iovt]) + '\t'
    
def Initialize(qtf_fn,qtd_fn):
    global DfDGbyns,TT_FPars
    if os.path.isfile(qtf_fn): DfDGbyns = np.loadtxt(qtf_fn,skiprows=1)
    else                     : DfDGbyns = np.ones((1,4*Cor.novt+3))*np.nan
    # if Cor.vs_time_datapoint == 'datapoint' : 
    #     for it in range(len(DfDGbyns)): DfDGbyns[it,1] = it

    TT_FPars = np.ones((len(DfDGbyns),2+2*Cor.nFParsmax+1))*np.nan
    if os.path.isfile(qtd_fn): 
        data = np.loadtxt(qtd_fn,skiprows=1)
        if data.ndim == 1: data = np.array([data])
        for it in range(len(data)):
            for j in range(len(data[0])):
                try   : TT_FPars[it,j] = data[it,j]
                except: pass
    else: TT_FPars = np.ones((len(DfDGbyns),2+2*Cor.nFParsmax+1))*np.nan
    if len(TT_FPars) < len(DfDGbyns):
        TT_FPars = np.ones((len(DfDGbyns),2+2*Cor.nFParsmax+1))*np.nan
    Make_headers()
    np.savetxt(qtd_fn,TT_FPars,header = header_FPars_qtd,delimiter='\t',newline = '\n')