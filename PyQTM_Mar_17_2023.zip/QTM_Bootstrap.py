import numpy as np
import tkinter as tk
from tkinter import ttk
import QTM_Core as Cor
import QTM_TT_IO as TT
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

def MakeFrame1(cntr):
    def Enter_n_Bootstrap(event):
        string = n_Bootstrap_SV.get(); string.strip()
        try: 
            Cor.n_Bootstrap = int(string); Cor.Write_Config()
        except: pass    
    
    def enter_i_BS_Par(event,WhichPar):
        if WhichPar == 'i_BS_Par1': 
            i_BS_Par1 = event.widget.get()
            for i,i_BS_Par in enumerate(i_BS_Par_Labels):
                if i_BS_Par1 == i_BS_Par: Cor.i_BS_Par1 = i
            Cor.Write_Config()
            if not FittedVals_arr is None : Plot_Correlation(Frame3)
        if WhichPar == 'i_BS_Par2': 
            i_BS_Par2 = event.widget.get()
            for i,i_BS_Par in enumerate(i_BS_Par_Labels):
                if i_BS_Par2 == i_BS_Par: Cor.i_BS_Par2 = i
            Cor.Write_Config()
            if not FittedVals_arr is None : Plot_Correlation(Frame3)

    i_BS_Par_Labels = []; i_BS_Par_keys = []
    for key in Cor.keys: 
        if Cor.IncPars[key] == 1:
            i_BS_Par_Labels.append(TT.header_Labels[key])
            i_BS_Par_keys.append(key)

    tk.Button(cntr,text ='Run',command=lambda: Run_Bootstrap()).grid(row=0,column=0)
    n_Bootstrap_SV = tk.StringVar(cntr,Cor.n_Bootstrap)
    n_Bootstrap_Entry = tk.Entry(cntr,width=6,textvariable=n_Bootstrap_SV)
    n_Bootstrap_Entry.grid(row=0,column=1)
    n_Bootstrap_Entry.bind('<Return>',lambda event: Enter_n_Bootstrap(event))
    
    i_BS_Par1_cb = ttk.Combobox(cntr,state='readonly',width=22,textvariable=i_BS_Par_Labels[Cor.i_BS_Par1],values = i_BS_Par_Labels) 
    i_BS_Par2_cb = ttk.Combobox(cntr,state='readonly',width=22,textvariable=i_BS_Par_Labels[Cor.i_BS_Par2],values = i_BS_Par_Labels) 
    i_BS_Par1_cb.current(Cor.i_BS_Par1)
    i_BS_Par2_cb.current(Cor.i_BS_Par2)
    i_BS_Par1_cb.grid(row=1,column=0,columnspan=2,sticky='W')
    i_BS_Par2_cb.grid(row=2,column=0,columnspan=2,sticky='W')
    i_BS_Par1_cb.bind('<<ComboboxSelected>>',lambda event: enter_i_BS_Par(event,'i_BS_Par1'))
    i_BS_Par2_cb.bind('<<ComboboxSelected>>',lambda event: enter_i_BS_Par(event,'i_BS_Par2'))

def Run_Bootstrap():
    global FittedVals_arr,BS_Means,BS_StdErrs
    Cor.Pars_to_Vals(); Cor.ns_inc_Dfcbyns_inc()
    FittedVals_arr = np.ones((Cor.nFPars,Cor.n_Bootstrap))*np.nan
    BS_Means   = np.ones(Cor.nFPars)*np.nan
    BS_StdErrs = np.ones(Cor.nFPars)*np.nan
    ns_inc_resampled      = np.ones(len(Cor.ns_inc))*np.nan
    Dfcbyns_inc_resampled = np.zeros(len(Cor.Dfcbyns_inc),dtype = np.complex128)
    for i in range(Cor.n_Bootstrap): 
        if i%100 == 0 : print(i,'/',Cor.n_Bootstrap)
        i_arr = np.random.choice(len(Cor.ns_inc),len(Cor.ns_inc),replace = True)
        for i2 in range(len(Cor.ns_inc)):
            ns_inc_resampled[i2]      = Cor.ns_inc[     i_arr[i2]] 
            Dfcbyns_inc_resampled[i2] = Cor.Dfcbyns_inc[i_arr[i2]]
        for j in range(len(Cor.ns_inc)):    
            Cor.ns_inc[j]      = ns_inc_resampled[j]
            Cor.Dfcbyns_inc[j] = Dfcbyns_inc_resampled[j]
        try : 
            FittedVals,StdErrs = Cor.Minimize_lmfit_chi2(Cor.GuessVals,Cor.MinVals,Cor.MaxVals)
            FittedVals_arr[:,i] = FittedVals
        except : pass
        Cor.ns_inc_Dfcbyns_inc()        
    for iFPar in range(Cor.nFPars):
        BS_Means[iFPar]   = np.nanmean(FittedVals_arr[iFPar])
        BS_StdErrs[iFPar] = np.nanstd( FittedVals_arr[iFPar])
    Plot_Bootstrap(Frame2) 
    Plot_Correlation(Frame3)        

def Plot_Bootstrap(cntr):
    for widget in cntr.winfo_children(): widget.destroy()    
    fig = Figure(figsize = (3.,5.5),dpi = 100)
    for iFPar in range(Cor.nFPars):
        axis = fig.add_subplot(Cor.nFPars,1,1+iFPar)
        axis.xaxis.label.set_fontsize(9)
        axis.yaxis.label.set_fontsize(9)
        axis.hist(FittedVals_arr[iFPar],bins=50)
        count = 0
        for key in Cor.keys:
            if Cor.IncPars[key] == 1: 
                if iFPar == count: axis.set_xlabel(TT.Graph_TT_Labels[key],fontsize=7)
                count += 1 
        axis.tick_params(labelsize = 8,direction='in')
        axis.set_title(str(np.round(BS_Means[iFPar],3)) + '\u00b1' + str(np.round(BS_StdErrs[iFPar],3)),fontsize = 8)
    fig.tight_layout(); fig.savefig('Bootstrap_Histograms.png',dpi=200)
    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); canvas.get_tk_widget().pack()

def Plot_Correlation(cntr):
    for widget in cntr.winfo_children(): widget.destroy()    
    fig = Figure(figsize = (2.5,2.5),dpi = 100)
    axis = fig.add_subplot(1,1,1)
    axis.xaxis.label.set_fontsize(9)
    axis.yaxis.label.set_fontsize(9)
    axis.plot(FittedVals_arr[Cor.i_BS_Par1],FittedVals_arr[Cor.i_BS_Par2],'x')
    count = 0
    for key in Cor.keys:
        if Cor.IncPars[key] == 1: 
            if Cor.i_BS_Par1 == count: axis.set_xlabel(TT.Graph_TT_Labels[key],fontsize=7)
            if Cor.i_BS_Par2 == count: axis.set_ylabel(TT.Graph_TT_Labels[key],fontsize=7)
            count += 1 
    axis.tick_params(labelsize = 8,direction='in')
    fig.tight_layout(); fig.savefig('Bootstrap_correlations.png',dpi=200)
    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); canvas.get_tk_widget().pack()

def Bootstrap_Start():
    global Frame1,Frame2,Frame3,BootstrapRoot
    BootstrapRoot = tk.Tk(); BootstrapRoot.title('Bootstrapping')
    Frame1 = tk.LabelFrame(BootstrapRoot); Frame1.grid(row=0,column=0,sticky = 'NW'); MakeFrame1(Frame1)
    Frame2 = tk.LabelFrame(BootstrapRoot); Frame2.grid(row=1,column=0,sticky = 'NW') 
    Frame3 = tk.LabelFrame(BootstrapRoot); Frame3.grid(row=1,column=1,sticky = 'NW')
    BootstrapRoot.iconbitmap("QTM.ico")
    BootstrapRoot.mainloop()
