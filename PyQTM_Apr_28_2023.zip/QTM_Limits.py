import numpy as np
import tkinter as tk
import QTM_Core as Cor

def Limits_Start():
    global LimitsRoot,LimitsFrame,LimitsMinPars_SVs,LimitsMaxPars_SVs
    def evaluate():
        for key in Cor.keys:
            if key !='VEtype_lay1' and key !='VEtype_lay2' and key !='VEtype_lay3': 
                string = LimitsMinPars_SVs[key].get(); string.strip()
                try: Cor.LimitsMinPars[key] = np.float64(string)
                except: print(key,string) 
                string = LimitsMaxPars_SVs[key].get(); string.strip()
                try: Cor.LimitsMaxPars[key] = np.float64(string)
                except: print(key,string) 
        MakeLimitsFrame(LimitsFrame)
        Cor.Write_Config()

    LimitsRoot  = tk.Tk(); LimitsRoot.title('Limits')
    LimitsFrame = tk.LabelFrame(LimitsRoot) 
    LimitsFrame.grid(row=0,column=0,sticky ='W')

    MakeLimitsFrame(LimitsFrame)
    evaluate = LimitsRoot.register(evaluate)
    LimitsRoot.bind_all("<Return>",evaluate)
    LimitsRoot.iconbitmap('QTM.ico')
    LimitsRoot.mainloop()

def MakeLimitsFrame(cntr):
    for widget in LimitsFrame.winfo_children(): widget.destroy()    
    global LimitsMinPars_SVs,LimitsMaxPars_SVs
    LimitsMinPars_SVs_List = [] 
    LimitsMaxPars_SVs_List = [] 
    for key in Cor.keys:
        LimitsMinPars_SVs_List.append(tk.StringVar(cntr,Cor.LimitsMinPars[key]))
        LimitsMaxPars_SVs_List.append(tk.StringVar(cntr,Cor.LimitsMaxPars[key]))
    LimitsMinPars_SVs = dict(zip(Cor.keys,LimitsMinPars_SVs_List))
    LimitsMaxPars_SVs = dict(zip(Cor.keys,LimitsMaxPars_SVs_List))
    f_width=11
    tk.Label(cntr,text='thickness [nm]'                         ,width=f_width).grid(row=0,column=1)
    tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]'                   ,width=f_width).grid(row=0,column=3)
    tk.Label(cntr,text=Cor.VE_Labels1[Cor.SamplePars['VEtype_lay1']],width=f_width).grid(row=0,column=4)
    tk.Label(cntr,text=Cor.VE_Labels2[Cor.SamplePars['VEtype_lay1']],width=f_width).grid(row=0,column=6)
    tk.Label(cntr,text=u'\u03B2\''                              ,width=f_width).grid(row=0,column=8)
    tk.Label(cntr,text=u'\u03B2\'\''                            ,width=f_width).grid(row=0,column=10)

    tk.Label(cntr,text='thickness [nm]'                         ,width=f_width).grid(row=3,column=1)
    tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]'                   ,width=f_width).grid(row=3,column=3)
    tk.Label(cntr,text=Cor.VE_Labels1[Cor.SamplePars['VEtype_lay2']],width=f_width).grid(row=3,column=4)
    tk.Label(cntr,text=Cor.VE_Labels2[Cor.SamplePars['VEtype_lay2']],width=f_width).grid(row=3,column=6)
    tk.Label(cntr,text=u'\u03B2\''                              ,width=f_width).grid(row=3,column=8)
    tk.Label(cntr,text=u'\u03B2\'\''                            ,width=f_width).grid(row=3,column=10)

    tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]'                   ,width=f_width).grid(row=6,column=3)
    tk.Label(cntr,text=Cor.VE_Labels1[Cor.SamplePars['VEtype_lay3']],width=f_width).grid(row=6,column=4)
    tk.Label(cntr,text=Cor.VE_Labels2[Cor.SamplePars['VEtype_lay3']],width=f_width).grid(row=6,column=6)
    tk.Label(cntr,text=u'\u03B2\''                              ,width=f_width).grid(row=6,column=8)
    tk.Label(cntr,text=u'\u03B2\'\''                            ,width=f_width).grid(row=6,column=10)

    tk.Label(cntr,text='1 Min'                      ).grid(row=1,column=0)
    tk.Label(cntr,text='1 Max'                      ).grid(row=2,column=0)
    tk.Label(cntr,text='2 Min'                      ).grid(row=4,column=0)
    tk.Label(cntr,text='2 Max'                      ).grid(row=5,column=0)
    tk.Label(cntr,text='bulk Min'                   ).grid(row=7,column=0)
    tk.Label(cntr,text='bulk Max'                   ).grid(row=8,column=0)
    tk.Label(cntr,text='Roughn [nm]',width=f_width+5).grid(row=0,column=11)
    tk.Label(cntr,text='Asp Rat',width=f_width+5    ).grid(row=3,column=11)

    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['t_lay1']            ,width=10).grid(row=1,column=1)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['rho_lay1']          ,width=10).grid(row=1,column=3)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VEPar1_lay1']       ,width=10).grid(row=1,column=4)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VEPar2_lay1']       ,width=10).grid(row=1,column=6)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VEPar1_PLexpt_lay1'],width=10).grid(row=1,column=8)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VEPar2_PLexpt_lay1'],width=10).grid(row=1,column=10)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['t_lay1']            ,width=10).grid(row=2,column=1)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['rho_lay1']          ,width=10).grid(row=2,column=3)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VEPar1_lay1']       ,width=10).grid(row=2,column=4)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VEPar2_lay1']       ,width=10).grid(row=2,column=6)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VEPar1_PLexpt_lay1'],width=10).grid(row=2,column=8)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VEPar2_PLexpt_lay1'],width=10).grid(row=2,column=10)

    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['t_lay2']            ,width=10).grid(row=4,column=1)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['rho_lay2']          ,width=10).grid(row=4,column=3)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VEPar1_lay2']       ,width=10).grid(row=4,column=4)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VEPar2_lay2']       ,width=10).grid(row=4,column=6)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VEPar1_PLexpt_lay2'],width=10).grid(row=4,column=8)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VEPar2_PLexpt_lay2'],width=10).grid(row=4,column=10)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['t_lay2']            ,width=10).grid(row=5,column=1)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['rho_lay2']          ,width=10).grid(row=5,column=3)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VEPar1_lay2']       ,width=10).grid(row=5,column=4)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VEPar2_lay2']       ,width=10).grid(row=5,column=6)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VEPar1_PLexpt_lay2'],width=10).grid(row=5,column=8)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VEPar2_PLexpt_lay2'],width=10).grid(row=5,column=10)
    
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['rho_lay3']          ,width=10).grid(row=7,column=3)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VEPar1_lay3']       ,width=10).grid(row=7,column=4)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VEPar2_lay3']       ,width=10).grid(row=7,column=6)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VEPar1_PLexpt_lay3'],width=10).grid(row=7,column=8)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VEPar2_PLexpt_lay3'],width=10).grid(row=7,column=10)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['VertScaleR']        ,width=10).grid(row=1,column=11)
    tk.Entry(cntr,textvariable=LimitsMinPars_SVs['AspRat']            ,width=10).grid(row=4,column=11)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['rho_lay3']          ,width=10).grid(row=8,column=3)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VEPar1_lay3']       ,width=10).grid(row=8,column=4)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VEPar2_lay3']       ,width=10).grid(row=8,column=6)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VEPar1_PLexpt_lay3'],width=10).grid(row=8,column=8)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VEPar2_PLexpt_lay3'],width=10).grid(row=8,column=10)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['VertScaleR']        ,width=10).grid(row=2,column=11)
    tk.Entry(cntr,textvariable=LimitsMaxPars_SVs['AspRat']            ,width=10).grid(row=5,column=11)
    
    tk.Button(cntr,text ='Defaults',command = Set_Defaults_Btn).grid(row=8,column=11,sticky='W')

def Set_Defaults_Btn():
    Set_Defaults(); MakeLimitsFrame(LimitsFrame)
    
def Set_Defaults():
    for key in ['t_lay1','t_lay2']:
        Cor.LimitsMinPars[key] = 0;    Cor.LimitsMaxPars[key] = 1e5
    for key in ['rho_lay1','rho_lay2','rho_lay3']:
        Cor.LimitsMinPars[key] = 1e-9; Cor.LimitsMaxPars[key] = 30
    for key in ['VEPar1_lay1','VEPar2_lay1','VEPar1_lay2','VEPar2_lay2','VEPar1_lay3','VEPar2_lay3']:
        Cor.LimitsMinPars[key] = 1e-7; Cor.LimitsMaxPars[key] = 1e7
    if Cor.SamplePars['VEtype_lay1'] == 0 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay1'] = -2;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay1'] = 0
        Cor.LimitsMinPars['VEPar2_PLexpt_lay1'] = -1;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay1'] = 1
    if Cor.SamplePars['VEtype_lay1'] == 1 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay1'] = 0;    Cor.LimitsMaxPars['VEPar1_PLexpt_lay1'] = 2
        Cor.LimitsMinPars['VEPar2_PLexpt_lay1'] = -1;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay1'] = 1
    if Cor.SamplePars['VEtype_lay1'] == 2 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay1'] = -2;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay1'] = 0
        Cor.LimitsMinPars['VEPar2_PLexpt_lay1'] = -1;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay1'] = 1
    if Cor.SamplePars['VEtype_lay1'] == 3 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay1'] = 0;    Cor.LimitsMaxPars['VEPar1_PLexpt_lay1'] = 2
        Cor.LimitsMinPars['VEPar2_PLexpt_lay1'] = -2;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay1'] = 0
    if Cor.SamplePars['VEtype_lay1'] == 4 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay1'] = -2;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay1'] = 0
        Cor.LimitsMinPars['VEPar2_PLexpt_lay1'] = -2;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay1'] = 2
    if Cor.SamplePars['VEtype_lay1'] == 5 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay1'] =  0;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay1'] = 2
        Cor.LimitsMinPars['VEPar2_PLexpt_lay1'] = -2;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay1'] = 2
    if Cor.SamplePars['VEtype_lay1'] == 6 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay1'] = -2;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay1'] = 0
        Cor.LimitsMinPars['VEPar2_PLexpt_lay1'] = -2;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay1'] = 2
    if Cor.SamplePars['VEtype_lay2'] == 0 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay2'] = -2;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay2'] = 0
        Cor.LimitsMinPars['VEPar2_PLexpt_lay2'] = -1;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay2'] = 1
    if Cor.SamplePars['VEtype_lay2'] == 1 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay2'] = 0;    Cor.LimitsMaxPars['VEPar1_PLexpt_lay2'] = 2
        Cor.LimitsMinPars['VEPar2_PLexpt_lay2'] = -1;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay2'] = 1
    if Cor.SamplePars['VEtype_lay2'] == 2 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay2'] = -2;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay2'] = 0
        Cor.LimitsMinPars['VEPar2_PLexpt_lay2'] = -1;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay2'] = 1
    if Cor.SamplePars['VEtype_lay2'] == 3 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay2'] = 0;    Cor.LimitsMaxPars['VEPar1_PLexpt_lay2'] = 2
        Cor.LimitsMinPars['VEPar2_PLexpt_lay2'] = -2;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay2'] = 0
    if Cor.SamplePars['VEtype_lay2'] == 4 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay2'] = -2;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay2'] = 0
        Cor.LimitsMinPars['VEPar2_PLexpt_lay2'] = -2;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay2'] = 2
    if Cor.SamplePars['VEtype_lay2'] == 5 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay2'] = 0;    Cor.LimitsMaxPars['VEPar1_PLexpt_lay2'] = 2
        Cor.LimitsMinPars['VEPar2_PLexpt_lay2'] = -2;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay2'] = 2
    if Cor.SamplePars['VEtype_lay2'] == 6 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay2'] = -2;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay2'] = 0
        Cor.LimitsMinPars['VEPar2_PLexpt_lay2'] = -2;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay2'] = 2
    if Cor.SamplePars['VEtype_lay3'] == 0 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay3'] = -2;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay3'] = 0
        Cor.LimitsMinPars['VEPar2_PLexpt_lay3'] = -1;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay3'] = 1
    if Cor.SamplePars['VEtype_lay3'] == 1 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay3'] = 0;    Cor.LimitsMaxPars['VEPar1_PLexpt_lay3'] = 2
        Cor.LimitsMinPars['VEPar2_PLexpt_lay3'] = -1;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay3'] = 1
    if Cor.SamplePars['VEtype_lay3'] == 2 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay3'] = -2;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay3'] = 0
        Cor.LimitsMinPars['VEPar2_PLexpt_lay3'] = -1;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay3'] = 1
    if Cor.SamplePars['VEtype_lay3'] == 3 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay3'] = 0;    Cor.LimitsMaxPars['VEPar1_PLexpt_lay3'] = 2
        Cor.LimitsMinPars['VEPar2_PLexpt_lay3'] = -2;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay3'] = 0
    if Cor.SamplePars['VEtype_lay3'] == 4 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay3'] = -2;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay3'] = 0
        Cor.LimitsMinPars['VEPar2_PLexpt_lay3'] = -2;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay3'] = 2
    if Cor.SamplePars['VEtype_lay3'] == 5 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay3'] = 0;    Cor.LimitsMaxPars['VEPar1_PLexpt_lay3'] = 2
        Cor.LimitsMinPars['VEPar2_PLexpt_lay3'] = -2;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay3'] = 2
    if Cor.SamplePars['VEtype_lay3'] == 6 :
        Cor.LimitsMinPars['VEPar1_PLexpt_lay3'] = -2;   Cor.LimitsMaxPars['VEPar1_PLexpt_lay3'] = 0
        Cor.LimitsMinPars['VEPar2_PLexpt_lay3'] = -2;   Cor.LimitsMaxPars['VEPar2_PLexpt_lay3'] = 2
    Cor.LimitsMinPars['VertScaleR'] = 0;    Cor.LimitsMaxPars['VertScaleR'] = 1e5
    Cor.LimitsMinPars['AspRat'    ] = 1e-3; Cor.LimitsMaxPars['AspRat'] = 1.
    Cor.Write_Config()