import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

z_max = 1500e-9; z_infl = 300e-9; width = 100e-9;
eta_Liq = 1e-3; rho = 1e3; Gp_surf  = 1e5; Gpp_surf = 1e4;
f0 = 5e6; om = 2 * np.pi * f0; Zq = 8.8e6;
ik0 = 1j * (1 + 1j)/252e-9

def G(z_rev): # "rev" because the z-scale is reversed
    z = z_max - z_rev
    Gp  = Gp_surf  * 1./2.*(1. - np.tanh((z-z_infl)/width))
    Gpp = Gpp_surf * 1./2.*(1. - np.tanh((z-z_infl)/width)) + om * eta_Liq
    return Gp + 1j * Gpp

def G_deriv_rev(z_rev): 
    z = z_max - z_rev
    Gpderiv_rev  =  Gp_surf  * 1./2.*(-1./np.cosh((z-z_infl)/width)/width)
    Gppderiv_rev =  Gpp_surf * 1./2.*(-1./np.cosh((z-z_infl)/width)/width)
    return -(Gpderiv_rev + 1j * Gppderiv_rev) # minus because the z-scale is reversed

def second_deriv_of_u(z_rev, u_uprime):  # u_uprime : velocity and its derivative
    u, uprime = u_uprime
    return [uprime, -rho * om**2 / G(z_rev) * u - G_deriv_rev(z_rev)/ G(z_rev) * uprime]

GridPoints = np.arange(0,z_max,10e-9)

ik0 = 1j * (1 + 1j)/252e-9
u_ini = [1 + 0*1j, -ik0] #initial values do not matter because solution is later normalized to 1 
sol = solve_ivp(second_deriv_of_u, [0, z_max], u_ini, t_eval = GridPoints)
u  = sol.y / sol.y[0,-1] # normalize, so that velocity at surface is 1
ZL = G(z_max)*u[1,-1] / (1j * om * u[0,-1])
dfc = f0 * 1j /(np.pi * Zq) * ZL
print('Df: {:.3f} Hz DG: {:.3f} Hz'.format(dfc.real,dfc.imag))

z_nm = (z_max - GridPoints) * 1e9

plt.subplot(211)
plt.plot(z_nm,G(GridPoints).real/1e6,'-',label = 'Re',)
plt.plot(z_nm,G(GridPoints).imag/1e6,'--',label = 'Im')
plt.title('Shear Modulus [MPa]',fontsize = 14);
plt.xlim(0,np.max(z_nm))
ax = plt.gca()
ax.axes.xaxis.set_visible(False)
plt.legend();


plt.subplot(212)
plt.plot(z_nm,u[0].real,'-',label = 'Re')
plt.plot(z_nm,u[0].imag,'--',label = 'Im')
plt.title('Velocity',fontsize = 14);
plt.xlabel('z  [nm]',fontsize = 14);
plt.xlim(0,np.max(z_nm))

#plt.legend();
plt.tight_layout();
plt.show();
