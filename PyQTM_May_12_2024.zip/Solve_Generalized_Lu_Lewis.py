import numpy as np
from scipy import optimize

def Calc_dfc_SLA(rho_f,Gprime_f,tandel_f,thickness_f):
    G_f = Gprime_f * (1 + 1j * tandel_f)
    Z_f = (rho_f * G_f)**0.5;
    c_f = (G_f/rho_f)**0.5;
    k_f = omegaref / c_f;
    ZL = 1j * Z_f * np.tan(k_f*thickness_f)
    dfc_SLA = f0 * 1j / (np.pi*Zq) * ZL;
    return dfc_SLA

def Calc_dfc_SIE(rho_f,Gprime_f,tandelf,thickness_f):
    G_f = Gprime_f * (1 + 1j * tandel_f)
    Z_f = (rho_f * G_f)**0.5;
    c_f = (G_f/rho_f)**0.5;

    def fun(x):
        dfcL = x[0] + 1j*x[1]
        k_f = (omegaref + 2*np.pi*dfcL.real) / c_f;
        ZL = 1j * Z_f * np.tan(k_f*thickness_f)
        rhs_m_lhs = -1j*Zq*np.tan(np.pi*dfcL/f0) - ZL
        return rhs_m_lhs.real,rhs_m_lhs.imag
   
    dfc_SLA = Calc_dfc_SLA(rho_f,Gprime_f,tandel_f,thickness_f)
    sol = optimize.root(fun, [dfc_SLA.real,dfc_SLA.imag])
    dfc_SIE = sol.x[0] + 1j* sol.x[1]
    return dfc_SIE

f0 = 5e6; n = 1; fref = n*f0; omegaref = 2*np.pi*fref; Zq = 8.8e6; 
rho_f = 1e3; thickness_f = 100e-9; Gprime_f = 1e7; tandel_f = 0.3;

dfc_SIE = Calc_dfc_SIE(rho_f,Gprime_f,tandel_f,thickness_f)
print('Df = ' + str(np.round(dfc_SIE.real,3)))
print('DG = ' + str(np.round(dfc_SIE.imag,9)))