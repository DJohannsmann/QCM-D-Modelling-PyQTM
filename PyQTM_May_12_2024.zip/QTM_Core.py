import numpy as np
from numba import jit
import lmfit
import configparser
import QTM_TT_IO as TT
import QTM_Limits as Limits
import QTM_Perturbation as Pert
from scipy.stats import linregress
import os
import matplotlib.pyplot as plt

def Get_Labels(): 
    global keys,VE_keys,IO_Labels,IncLabels,OvtInc_Labels,Dfbyn_Labels,DGbyn_Labels,VE_Labels1,VE_Labels2,\
        TT_IO_Format_strings,Model_strings,stat_weight_strings,TT_direcFitSeries_strings,TT_guess_from_strings,\
        Start_from_strings,DD_DGbyn_strings,vs_time_datapoint_strings,\
        Colors,Ovt_Labels,ready_state
    keys = ['t_lay1','t_lay2','rho_lay1','rho_lay2','rho_lay3',\
            'VEPar1_lay1','VEPar1_lay2','VEPar1_lay3','VEPar1_PLexpt_lay1','VEPar1_PLexpt_lay2','VEPar1_PLexpt_lay3',\
            'VEPar2_lay1','VEPar2_lay2','VEPar2_lay3','VEPar2_PLexpt_lay1','VEPar2_PLexpt_lay2','VEPar2_PLexpt_lay3',\
            'VertScaleR','AspRat','VEtype_lay1','VEtype_lay2','VEtype_lay3']
    Model_strings = ['Multilayer_Formalism','3rd-Order_Perturbation','5th-Order_Perturbation']
    stat_weight_strings = ['n^-1','n^-(0.5)','flat','n^(0.5)','n^1']
    TT_IO_Format_strings = ['from_QTZ','from_QSoft','from_QSoft_new','from_AWSensors','from_OpenQCM','from_QCM-I']
    TT_direcFitSeries_strings = ['start_to_stop','stop_to_start']
    TT_guess_from_strings = ['from_previous_fit','from_ParsPanel']
    Start_from_strings    = ['Start_from_Default','Start_from_Previous']
    DD_DGbyn_strings = ['DGbyn','DD']
    vs_time_datapoint_strings = ['time','datapoint']
    

    IO_Labels = [
    'Thickness Layer 1 [nm]',\
    'Thickness Layer 2 [nm]',\
    'Density Layer 1 [g/cm^3]',\
    'Density Layer 2 [g/cm^3]',\
    'Density Bulk [g/cm^3]',\
    'VE Par 1 Layer 1',\
    'VE Par 1 Layer 2',\
    'VE Par 1 Bulk',\
    'Power Law Expon. beta_p Layer 1',\
    'Power Law Expon. beta_p Layer 2',\
    'Power Law Expon. beta_p Bulk',\
    'VE Par 2 Layer 1',\
    'VE Par 2 Layer 2',\
    'VE Par 2 Bulk',\
    'Power Law Expon. beta_pp Layer 1',\
    'Power Law Expon. beta_pp Layer 2',\
    'Power Law Expon. beta_pp Bulk',\
    'Vertical scale of roughness [nm]',\
    'Aspect ratio',\
    'Choice of VE Pars, Layer 1',\
    'Choice of VE Pars, Layer 2',\
    'Choice of VE Pars, Bulk']
 
    IncLabels = ['fit_t_lay1','fit_t_lay2','fit_rho_lay1','fit_rho_lay2','fit_rho_lay3',\
                 'fit_VEPar1_lay1','fit_VEPar1_lay2','fit_VEPar1_lay3',\
                 'fit_VEPar1_PLexpt_lay1','fit_VEPar1_PLexpt_lay2','fit_VEPar1_PLexpt_lay3',\
                 'fit_VEPar2_lay1','fit_VEPar2_lay2','fit_VEPar2_lay3',\
                 'fit_VEPar2_PLexpt_lay1','fit_VEPar2_PLexpt_lay2','fit_VEPar2_PLexpt_lay3',\
                 'fit_VertScaleR_C','fit_AspRat_C',\
                 'fit_VEtype_lay1','fit_VEtype_lay2','fit_VEtype_lay3']  
    OvtInc_Labels =  ['OvtInc1','OvtInc2','OvtInc3','OvtInc4','OvtInc5','OvtInc6','OvtInc7']
    Dfbyn_Labels =   ['Dfbyn1','Dfbyn2','Dfbyn3','Dfbyn4','Dfbyn5','Dfbyn6','Dfbyn7']
    DGbyn_Labels =   ['DGbyn1','DGbyn2','DGbyn3','DGbyn4','DGbyn5','DGbyn6','DGbyn7']
    VE_Labels1 = ['J\' [MPa\u207B\u00B9]','G\' [MPa]','\u03B7\' [mPa s]',
                  'G\' [MPa]','|J| [MPa\u207B\u00B9]','|G| [MPa]','|\u03B7| [mPa s]']
    VE_Labels2 = ['J\'\' [MPa\u207B\u00B9]','G\'\' [MPa]','\u03B7\'\' [mPa s]',\
                  '\u03B7\' [mPa s]','tan(\u03B4)','tan(\u03B4)','tan(\u03B4)\u207B\u00B9']

    IO_Labels = dict(zip(keys,IO_Labels))
    IncLabels = dict(zip(keys,IncLabels))
    Colors = ['k','r','lime','b','fuchsia','gray','purple']
    Ovt_Labels = ['5 MHz','15 MHz','25 MHz','35 MHz','45 MHz','55 MHz','65 MHz']
    ready_state = 'Select'

def Write_QTM_cfg(): 
    configMain['Main']={}
    configMain['Main']['Start_from'] = Start_from
    for i in range(n_previous): 
        Previous_Filenames.append('')
        configMain['Main']['Previous_Filenames_'+str(i)] = Previous_Filenames[i].replace('%','%%')
    CurrWD = os.getcwd()  
    with open(CurrWD+'/QTM.ini','w+') as configfile: configMain.write(configfile)

def Read_QTM_cfg():
    global configMain,Previous_Filenames,Start_from,n_previous
    n_previous = 10
    Previous_Filenames = []
    for i in range(n_previous): Previous_Filenames.append('')
    configMain = configparser.ConfigParser()
    CurrWD = os.getcwd()
    if os.path.isfile(CurrWD+'/QTM.ini') : 
        configMain.read(CurrWD+'/QTM.ini')
        Start_from   = configMain.get('Main','Start_from',fallback='Start_from_Default')
        for i in range(n_previous):
            Previous_Filenames[i] = configMain.get('Main','Previous_Filenames_'+str(i),fallback='')
    
def Write_Config(): 
    TT.Get_Labels_TT_header()
    config['Main']={}
    config['Sample']    = {}
    config['SampleStdErrs']    = {}
    config['Reference'] = {}
    config['LimitsMin'] = {}
    config['LimitsMax'] = {}
    config['IncInFit']  = {}
    config['DfDGbyn']   = {}
    config['FParameters'] = {}
    config['FParameters_w_StdErrs'] = {}
    config['Main']['Model']             = Model
    config['Main']['stat_weight']       = stat_weight
    config['Main']['DD_DGbyn']          = DD_DGbyn
    config['Main']['ParsGood']          = ParsGood
    config['Main']['Show_lay1']         = Show_lay1
    config['Main']['Show_lay2']         = Show_lay2
    config['Main']['Show_bulk']         = Show_bulk
    config['Main']['Do_Conv']           = Do_Conv
    config['Main']['Do_SaveQuery']      = Do_SaveQuery
    config['Main']['filename']          = filename.replace('%','%%')
    config['Main']['folder']            = folder.replace('%','%%')
    config['Main']['TT_filename']       = TT_filename.replace('%','%%')
    config['Main']['TT_IO_Format']      = TT_IO_Format
    config['Main']['TT_guess_from']     = TT_guess_from
    config['Main']['Fit_Called_from']   = Fit_Called_from
    config['Main']['TT_Correct_Drift']  = TT_Correct_Drift
    config['Main']['InfoString']        = InfoString
    config['Main']['vs_time_datapoint'] = vs_time_datapoint
    config['Main']['CurrWD']            = os.getcwd()
    config['Main']['f_fund']            = str(f_fund)
    config['Main']['Z_q']               = str(Zq)
    config['Main']['f_cen']             = str(f_cen)
    config['Main']['ErrDfbyn']          = str(ErrDfbyn)
    config['Main']['rms_noise_Dfbyn']   = str(rms_noise_Dfbyn)
    config['Main']['RelWeight_DfDG']    = str(RelWeight_DfDG)
    config['Main']['n_pre_avg']         = str(n_pre_avg)
    config['Main']['i_strt_fit']        = str(i_strt_fit)
    config['Main']['i_stop_fit']        = str(i_stop_fit)
    config['Main']['i_selec']           = str(i_selec)
    config['Main']['i_selec_FzI']       = str(i_selec_FzI)
    config['Main']['i_channel']         = str(i_channel)
    config['Main']['Update_Inval']      = str(Update_Inval)
    config['Main']['chi2LS_min']        = str(chi2LS_min) 
    config['Main']['chi2LS_max']        = str(chi2LS_max) 
    config['Main']['chi2LS_Fac']        = str(chi2LS_Fac) 
    config['Main']['chi2LS_n']          = str(chi2LS_n) 
    config['Main']['chi2LS_i_Par_Varied']=str(chi2LS_i_Par_Varied)
    config['Main']['n_Bootstrap'    ]   = str(n_Bootstrap)
    config['Main']['n_RndNoise'     ]   = str(n_RndNoise)
    config['Main']['i_BS_Par1'      ]   = str(i_BS_Par1)
    config['Main']['i_BS_Par2'      ]   = str(i_BS_Par2)
    config['Main']['i_RN_Par1'      ]   = str(i_RN_Par1)
    config['Main']['i_RN_Par2'      ]   = str(i_RN_Par2)
    
    config['Main']['i_strt_hide_TT']    = str(i_strt_hide_TT)
    config['Main']['i_stop_hide_TT']    = str(i_stop_hide_TT)
    config['Main']['i_strt_avrg']       = str(i_strt_avrg)
    config['Main']['i_stop_avrg' ]      = str(i_stop_avrg)
    config['Main']['i_strt_zoom_TT']    = str(i_strt_zoom_TT)
    config['Main']['i_stop_zoom_TT']    = str(i_stop_zoom_TT)
    config['Main']['i_strt_hide_FP']    = str(i_strt_hide_FP)
    config['Main']['i_stop_hide_FP']    = str(i_stop_hide_FP)
    config['Main']['i_strt_zoom_FP']    = str(i_strt_zoom_FP)
    config['Main']['i_stop_zoom_FP']    = str(i_stop_zoom_FP)
    config['Main']['i_PlotErrBars']     = str(i_PlotErrBars)
    config['Main']['VEPar_Conv']        = str(VEPar_Conv)

    config['Main']['WindowHeight']      = str(WindowHeight)
    config['Main']['WindowWidth']       = str(WindowWidth)
    config['Main']['WindowTop']         = str(WindowTop)
    config['Main']['WindowLeft']        = str(WindowLeft)
    

    for key in keys:
        config['Sample'   ][IO_Labels[key]] = str(SamplePars[   key])
        if  config.has_section('SampleStdErrs'): 
            config['SampleStdErrs'][IO_Labels[key]] = str(SampleStdErrs[key])
        config['Reference'][IO_Labels[key]] = str(RefPars[      key])
        config['LimitsMin'][IO_Labels[key]] = str(LimitsMinPars[key])
        config['LimitsMax'][IO_Labels[key]] = str(LimitsMaxPars[key])
        config['IncInFit' ][IncLabels[key]] = str(IncPars[      key])
    # "Pars' always refers to a dictionary with keys t_lay1, rho_lay1, t_2, ...
    for iovt in range(novt):    
        config['DfDGbyn'][OvtInc_Labels[iovt]] = str(int(OvtInc[iovt]))
        config['DfDGbyn'][Dfbyn_Labels[ iovt]] = str(    Dfbyns[iovt] )
        config['DfDGbyn'][DGbyn_Labels[ iovt]] = str(    DGbyns[iovt] )
    if ParsGood == 'yes':
        for key in keys:
            if IncPars[key] == 1:
                if not key in ['VEtype_lay1','VEtype_lay2','VEtype_lay3']: 
                    config['FParameters'][TT.header_Labels[key]+'_StdErr'] ="{:.5e}".format(SampleStdErrs[key])
                    config['FParameters'][TT.header_Labels[key]] ="{:.5e}".format(SamplePars[key])
                    config['FParameters'][TT.header_Labels[key]+'_StdErr'] ="{:.5e}".format(SampleStdErrs[key])
                    config['FParameters_w_StdErrs'][TT.header_Labels[key]] = \
                      "{:.5e}".format(np.round(SamplePars[key],5)) + '-/+' + \
                          "{:.5e}".format(np.round(SampleStdErrs[key],5))
    if ParsGood == 'no': 
        config.remove_section('FParameters')
        config.remove_section('FParameters_w_StdErrs')
    os.makedirs(os.getcwd() + '/tmp', exist_ok=True)
    with open(os.getcwd()+'/tmp/Master.qtm','w') as configfile: config.write(configfile)

def Read_Config():
    global SamplePars,SamplePars_old,SamplePars2,SampleStdErrs,RefPars,LimitsMinPars,LimitsMaxPars,IncPars,\
        OvtInc,Dfbyns,DGbyns,Dfcbyns,\
        Model,stat_weight,RelWeight_DfDG,ParsGood,nFPars,\
        Show_lay1,Show_lay2,Show_bulk,\
        DD_DGbyn,InfoString,\
        f_fund,Zq,f_cen,ErrDfbyn,Update_Inval,rms_noise_Dfbyn,Abort_Enabled,Abort,\
        filename,folder,vs_time_datapoint,TT_direcFitSeries,TT_filename,TT_IO_Format,TT_guess_from,TT_Correct_Drift,\
        n_pre_avg,i_channel,i_ready,i_selec,i_selec_FzI,i_strt_fit,i_stop_fit,i_current,i_new_zero,i_selec,\
        i_strt_hide_TT,i_stop_hide_TT,i_strt_hide_FP,i_stop_hide_FP,\
        i_strt_zoom_TT,i_stop_zoom_TT,i_strt_zoom_FP,i_stop_zoom_FP,i_PlotErrBars,\
        i_strt_avrg,i_stop_avrg,i_col_x,\
        chi2LS_min,chi2LS_max,chi2LS_Fac,chi2LS_n,chi2LS_i_Par_Varied,\
        n_Bootstrap,n_RndNoise,i_BS_Par1,i_BS_Par2,i_RN_Par1,i_RN_Par2,\
        novt,nlay,nFParsmax,n_arr,Do_SaveQuery,TimeLabel,\
        WindowHeight,WindowWidth,WindowTop,WindowLeft,CurrWD,VEPar_Conv,Do_Conv,Fit_Called_from,\
        config
    Abort_Enabled = False; Abort = False; novt = 7; nlay = 3; nFParsmax = 6 
    n_arr = np.array([1,3,5,7,9,11,13])
    config = configparser.ConfigParser()
    CurrWD = os.getcwd()

    if os.path.isfile(os.getcwd()+'/tmp/Master.qtm'): config.read(os.getcwd()+'/tmp/Master.qtm')
    else                                       : config.read('Defaults.qtm')
    IO_vals = []
    for i in range(len(keys)):
        IO_vals = np.append(IO_vals,0)
        SamplePars     = dict(zip(keys,IO_vals))
        # SampleParsConv = dict(zip(keys,IO_vals))
        SamplePars_old = dict(zip(keys,IO_vals))
        SampleStdErrs  = dict(zip(keys,IO_vals))
        RefPars        = dict(zip(keys,IO_vals))
        LimitsMinPars  = dict(zip(keys,IO_vals))
        LimitsMaxPars  = dict(zip(keys,IO_vals))
        IncPars        = dict(zip(keys,IO_vals))
    for key in keys:
        if not key in ['VEtype_lay1','VEtype_lay2','VEtype_lay3']:
            SamplePars[key]    = np.float64(config.get('Sample'   ,IO_Labels[key],fallback=0))
            # SampleParsConv[key]= np.float64(config.get('Sample'   ,IO_Labels[key],fallback=0))
            SampleStdErrs[key] = np.float64(config.get('SampleStdErrs',IO_Labels[key],fallback=0))
            RefPars[key]       = np.float64(config.get('Reference',IO_Labels[key],fallback=0))
            LimitsMinPars[key] = np.float64(config.get('LimitsMin',IO_Labels[key],fallback=0))
            LimitsMaxPars[key] = np.float64(config.get('LimitsMax',IO_Labels[key],fallback=0))
            IncPars[key]       =        int(config.get('IncInFit' ,IncLabels[key],fallback=0))
    for key in ['VEtype_lay1','VEtype_lay2','VEtype_lay3']:
        IncPars[key] = 0;
        SamplePars[key] = config.get('Sample'   ,IO_Labels[key],fallback=1)
        RefPars[key]    = config.get('Reference',IO_Labels[key],fallback=1)

        if SamplePars[key] == 'Jp_Jpp': SamplePars[key] = 0 
        if SamplePars[key] == 'Gp_Gpp': SamplePars[key] = 1 
        if SamplePars[key] == 'etap_etapp' : SamplePars[key] = 2
        if SamplePars[key] == 'Gp_etap': SamplePars[key] = 3 
        if SamplePars[key] == 'Jabs_tandel': SamplePars[key] = 4 
        if SamplePars[key] == 'Gabs_tandel': SamplePars[key] = 5 
        if SamplePars[key] == 'etaabs_tandelinv' : SamplePars[key] = 6
        
        if RefPars[key] == 'Jp_Jpp': RefPars[key] = 0 
        if RefPars[key] == 'Gp_Gpp': RefPars[key] = 1 
        if RefPars[key] == 'etap_etapp' : RefPars[key] = 2
        if RefPars[key] == 'Gp_etap': RefPars[key] = 3 
        if RefPars[key] == 'Jabs_tandel': RefPars[key] = 4 
        if RefPars[key] == 'Gabs_tandel': RefPars[key] = 5 
        if RefPars[key] == 'etaabs_tandelinv' : RefPars[key] = 6

        if RefPars[key] == "'Jp_Jpp'": RefPars[key] = 0 
        if RefPars[key] == "'Gp_Gpp'": RefPars[key] = 1 
        if RefPars[key] == "'etap_etapp'" : RefPars[key] = 2
        if RefPars[key] == "'Gp_etap'": RefPars[key] = 3 
        if RefPars[key] == "'Jabs_tandel'": RefPars[key] = 4 
        if RefPars[key] == "'Gabs_tandel'": RefPars[key] = 5 
        if RefPars[key] == "'etaabs_tandelinv'" : RefPars[key] = 6

        if SamplePars[key] == '0': SamplePars[key] = 0 
        if SamplePars[key] == '1': SamplePars[key] = 1 
        if SamplePars[key] == '2': SamplePars[key] = 2
        if SamplePars[key] == '3': SamplePars[key] = 3 
        if SamplePars[key] == '4': SamplePars[key] = 4 
        if SamplePars[key] == '5': SamplePars[key] = 5 
        if SamplePars[key] == '6': SamplePars[key] = 6
        
        if RefPars[key] == '0': RefPars[key] = 0 
        if RefPars[key] == '1': RefPars[key] = 1 
        if RefPars[key] == '2': RefPars[key] = 2
        if RefPars[key] == '3': RefPars[key] = 3 
        if RefPars[key] == '4': RefPars[key] = 4 
        if RefPars[key] == '5': RefPars[key] = 5 
        if RefPars[key] == '6': RefPars[key] = 6

        SamplePars[key] = int(SamplePars[key])
        RefPars[key] = int(RefPars[key])
        LimitsMinPars[key] = int(LimitsMinPars[key])
        LimitsMaxPars[key] = int(LimitsMaxPars[key])
        if SamplePars[key] > 6: SamplePars[key] = 6
        if RefPars[key] > 6   : RefPars[key]    = 6

    OvtInc = np.ones(novt,dtype = int)*np.nan
    Dfbyns = np.zeros(novt)
    DGbyns = np.zeros(novt)
    for i in range(novt):    
        OvtInc[i]     = int(np.float64(config.get('DfDGbyn',OvtInc_Labels[i],fallback=1)))
        Dfbyns[i]     =     np.float64(config.get('DfDGbyn',Dfbyn_Labels[i] ,fallback=0))
        DGbyns[i]     =     np.float64(config.get('DfDGbyn',DGbyn_Labels[i] ,fallback=0))
    Dfcbyns = Dfbyns + 1j * DGbyns 

    Model                   = config.get('Main','Model'                   ,fallback='Multilayer_Formalism')
    stat_weight             = config.get('Main','stat_weight'             ,fallback='flat')
    DD_DGbyn                = config.get('Main','DD_DGbyn'                ,fallback='DGbyn')
    ParsGood                = config.get('Main','ParsGood'                ,fallback='no')
    Show_lay1               = config.get('Main','Show_lay1'               ,fallback='yes')
    Show_lay2               = config.get('Main','Show_lay2'               ,fallback='no')
    Show_bulk               = config.get('Main','Show_bulk'               ,fallback='yes')
    Do_Conv                 = config.get('Main','Do_Conv'                 ,fallback='no')
    Do_SaveQuery            = config.get('Main','Do_SaveQuery'            ,fallback='no')
    filename                = config.get('Main','filename'                ,fallback='') 
    folder                  = config.get('Main','folder'                  ,fallback='') 
    TT_filename             = config.get('Main','TT_filename'             ,fallback='') 
    TT_direcFitSeries       = config.get('Main','TT_direcFitSeries'       ,fallback='start_to_stop') 
    TT_IO_Format            = config.get('Main','TT_IO_Format'            ,fallback='from_QTZ')
    TT_guess_from           = config.get('Main','TT_guess_from'           ,fallback='from_previous_fit')
    Fit_Called_from         = config.get('Main','Fit_Called_from'         ,fallback='FitPoint')
    TT_Correct_Drift        = config.get('Main','TT_Correct_Drift'        ,fallback='no')
    InfoString              = config.get('Main','InfoString'              ,fallback='') 
    vs_time_datapoint       = config.get('Main','vs_time_datapoint'       ,fallback='time')
    TimeLabel               = config.get('Main','TimeLabel'               ,fallback='[a.u.]')
    # CurrWD                  = config.get('Main','CurrWD'                  ,fallback='C://')
    # SavePath                = config.get('Main','SavePath'                ,fallback='C://')

    f_fund            = np.float64(config.get('Main','f_fund'             ,fallback=5e6))
    Zq                = np.float64(config.get('Main','Z_q'                ,fallback=8.8e6)) 
    f_cen             = np.float64(config.get('Main','f_cen'              ,fallback=30e6))
    ErrDfbyn          = np.float64(config.get('Main','ErrDfbyn'           ,fallback=0.1))
    rms_noise_Dfbyn   = np.float64(config.get('Main','rms_noise_Dfbyn'    ,fallback=np.nan))
    RelWeight_DfDG    = np.float64(config.get('Main','RelWeight_DfDG'     ,fallback=1))
    chi2LS_min        = np.float64(config.get('Main','chi2LS_min'         ,fallback=0))
    chi2LS_max        = np.float64(config.get('Main','chi2LS_max'         ,fallback=100))
    chi2LS_Fac        = np.float64(config.get('Main','chi2LS_Fac'         ,fallback=5))
    chi2LS_n          = int(config.get('Main','chi2LS_n'                  ,fallback=100))
    chi2LS_i_Par_Varied=int(config.get('Main','chi2LS_i_Par_Varied'       ,fallback=0))
    n_Bootstrap       = int(config.get('Main','n_Bootstrap'               ,fallback=100))
    n_RndNoise        = int(config.get('Main','n_RndNoise'                ,fallback=100))
    i_BS_Par1         = int(config.get('Main','i_BS_Par1'                 ,fallback=0))
    i_BS_Par2         = int(config.get('Main','i_BS_Par2'                 ,fallback=1))
    i_RN_Par1         = int(config.get('Main','i_RN_Par1'                 ,fallback=0))
    i_RN_Par2         = int(config.get('Main','i_RN_Par2'                 ,fallback=1))
    n_pre_avg         = int(config.get('Main','n_pre_avg'                 ,fallback=1))
    i_strt_fit        = int(config.get('Main','i_strt_fit'                ,fallback=0))
    i_stop_fit        = int(config.get('Main','i_stop_fit'                ,fallback=0))
    i_strt_hide_TT    = int(config.get('Main','i_strt_hide_TT'            ,fallback=0))
    i_stop_hide_TT    = int(config.get('Main','i_stop_hide_TT'            ,fallback=0))
    i_strt_avrg       = int(config.get('Main','i_strt_avrg'               ,fallback=0))
    i_stop_avrg       = int(config.get('Main','i_stop_avrg'               ,fallback=0))
    i_strt_zoom_TT    = int(config.get('Main','i_strt_zoom_TT'            ,fallback=0))
    i_stop_zoom_TT    = int(config.get('Main','i_stop_zoom_TT'            ,fallback=0))
    i_strt_hide_FP    = int(config.get('Main','i_strt_hide_FP'            ,fallback=0))
    i_stop_hide_FP    = int(config.get('Main','i_stop_hide_FP'            ,fallback=0))
    i_strt_zoom_FP    = int(config.get('Main','i_strt_zoom_FP'            ,fallback=0))
    i_stop_zoom_FP    = int(config.get('Main','i_stop_zoom_FP'            ,fallback=0))
    i_selec           = int(config.get('Main','i_selec'                   ,fallback=0))
    i_selec_FzI       = int(config.get('Main','i_selec_FzI'               ,fallback=0))
    i_current         = int(config.get('Main','i_current'                 ,fallback=0))
    i_channel         = int(config.get('Main','i_channel'                 ,fallback=1))
    i_PlotErrBars     = int(config.get('Main','i_PlotErrBars'             ,fallback=1))
    Update_Inval      = int(config.get('Main','Update_Inval'              ,fallback=20))
    VEPar_Conv        = int(config.get('Main','VEPar_Conv'                ,fallback=0))

    WindowHeight      = int(config.get('Main','WindowHeight'              ,fallback=780))
    WindowWidth       = int(config.get('Main','WindowWidth'               ,fallback=1290))
    WindowTop         = int(config.get('Main','WindowTop'                 ,fallback=15))
    WindowLeft        = int(config.get('Main','WindowLeft'                ,fallback=15))

    nFPars = 0 
    for key in keys: nFPars += IncPars[key]

    if vs_time_datapoint == 'time': i_col_x = 1
    else :                          i_col_x = 0 
    i_ready = 0; i_new_zero = 0; 
    if LimitsMinPars['rho_lay1'] < 1e-9: Limits.Set_Defaults()
    Adjust_Pars_to_Limits()
    Check_Show_IncInFit()
    Write_Config()
    SamplePars2 = SamplePars.copy()
        
def Check_Show_IncInFit():
    if Show_lay1 == 'no':
        IncPars['t_lay1'] = 0
        IncPars['VEPar1_lay1'] = 0
        IncPars['VEPar2_lay1'] = 0
        IncPars['VEPar1_PLexpt_lay1'] = 0
        IncPars['VEPar2_PLexpt_lay1'] = 0
    if Show_lay2 == 'no':
        IncPars['t_lay2'] = 0
        IncPars['VEPar1_lay2'] = 0
        IncPars['VEPar2_lay2'] = 0
        IncPars['VEPar1_PLexpt_lay2'] = 0
        IncPars['VEPar2_PLexpt_lay2'] = 0
    if Show_bulk == 'no':
        IncPars['VEPar1_lay2'] = 0
        IncPars['VEPar2_lay2'] = 0
        IncPars['VEPar1_PLexpt_lay2'] = 0
        IncPars['VEPar2_PLexpt_lay2'] = 0
        IncPars['VertScaleR'] = 0
        IncPars['AspRat'] = 0
    
def Initialize_Val_arrays():
    global GuessValsFromPrevious,GuessValsFromParsPanel
    GuessValsFromPrevious  = np.ones(nFParsmax)*np.nan 
    GuessValsFromParsPanel = np.ones(nFParsmax)*np.nan  

def Adjust_Pars_to_Limits():
    Adjusted_to_Limits = False
    for key in keys:
        if not (key in ['VEtype_lay1','VEtype_lay2','VEtype_lay3']):
            if  SamplePars[key] > LimitsMaxPars[key]: 
                SamplePars[key] = LimitsMaxPars[key]; Adjusted_to_Limits = True
            if  SamplePars[key] < LimitsMinPars[key]: 
                SamplePars[key] = LimitsMinPars[key]; Adjusted_to_Limits = True
            if  RefPars[key]    > LimitsMaxPars[key]: 
                RefPars[key]    = LimitsMaxPars[key]; Adjusted_to_Limits = True
            if  RefPars[key]    < LimitsMinPars[key]: 
                RefPars[key]    = LimitsMinPars[key]; Adjusted_to_Limits = True
    if Adjusted_to_Limits: Write_Config()        

def get_layer_arrays(Pars):
    t_lays            = np.array([Pars['t_lay1'] *1e-9      ,Pars['t_lay2']*1e-9       ,0])
    rho_lays          = np.array([Pars['rho_lay1']*1e3      ,Pars['rho_lay2']*1e3      ,Pars['rho_lay3']*1e3])
    VEPar1_cen_lays   = np.array([Pars['VEPar1_lay1']       ,Pars['VEPar1_lay2']       ,Pars['VEPar1_lay3']]) 
    VEPar2_cen_lays   = np.array([Pars['VEPar2_lay1']       ,Pars['VEPar2_lay2']       ,Pars['VEPar2_lay3']])
    VEPar1_PLexpt_lays= np.array([Pars['VEPar1_PLexpt_lay1'],Pars['VEPar1_PLexpt_lay2'],Pars['VEPar1_PLexpt_lay3']])
    VEPar2_PLexpt_lays= np.array([Pars['VEPar2_PLexpt_lay1'],Pars['VEPar2_PLexpt_lay2'],Pars['VEPar2_PLexpt_lay3']])
    VEtype_lays       = np.array([Pars['VEtype_lay1']       ,Pars['VEtype_lay2']       ,Pars['VEtype_lay3']])
    VertScaleR  = Pars['VertScaleR']*1e-9
    AspRat      = Pars['AspRat']
    return t_lays,rho_lays,VEPar1_cen_lays,VEPar2_cen_lays,\
        VEPar1_PLexpt_lays,VEPar2_PLexpt_lays,VertScaleR,AspRat,VEtype_lays

def ns_inc_Dfcbyns_inc():
    global ns_inc,Dfcbyns_inc
    Dfcbyns = Dfbyns + 1j * DGbyns
    ns_inc = []; Dfcbyns_inc = []
    for iovt in range(novt):
        if OvtInc[iovt] == 1:
            ns_inc      = np.append(ns_inc     ,n_arr[  iovt] )
            Dfcbyns_inc = np.append(Dfcbyns_inc,[Dfcbyns[iovt]])

def VEPars_Old2New(VEPar1_cen_old,VEPar2_cen_old,VEPar1_PLexpt_old,VEPar2_PLexpt_old,VEtype_old,VEtype_new):
    Js_ovt = np.ones(novt,dtype=np.complex128)*np.nan
    oms = 2.*np.pi*f_fund*n_arr
    n_Jref = f_cen / f_fund

    for iovt,n in enumerate(n_arr):
        Js_ovt[iovt] = Calc_J_SI(VEPar1_cen_old,VEPar2_cen_old,\
                              VEPar1_PLexpt_old,VEPar2_PLexpt_old,VEtype_old,n,f_cen,f_fund)
            
    if VEtype_new == 0 :
        VEPars_re =  Js_ovt.real/1e-6
        VEPars_im = -Js_ovt.imag/1e-6
    if VEtype_new == 1 :
        Gs_ovt = 1/Js_ovt
        VEPars_re = Gs_ovt.real/1e6
        VEPars_im = Gs_ovt.imag/1e6
    if VEtype_new == 2 :
        Gs_ovt = 1/Js_ovt
        etas_ovt = Gs_ovt/(1j * oms)
        VEPars_re =  etas_ovt.real/1e-3
        VEPars_im = -etas_ovt.imag/1e-3
    if VEtype_new == 3 :
        Gs_ovt = 1/Js_ovt
        etas_ovt = Gs_ovt/(1j * oms)
        VEPars_re = Gs_ovt.real/1e6
        VEPars_im = etas_ovt.real/1e-3
    if VEtype_new == 4 :
        Jabs_ovt = np.abs(Js_ovt)
        tandel_ovt = -Js_ovt.imag/Js_ovt.real
        VEPars_re = Jabs_ovt/1e-6
        VEPars_im = tandel_ovt
    if VEtype_new == 5 :
        Gabs_ovt = np.abs(1/Js_ovt)
        tandel_ovt = -Js_ovt.imag/Js_ovt.real
        VEPars_re = Gabs_ovt/1e6
        VEPars_im = tandel_ovt
    if VEtype_new == 6 :
        Gs_ovt = 1/Js_ovt
        etas_ovt = Gs_ovt/(1j * oms)
        etaabs_ovt = np.abs(etas_ovt)/1e-3
        tandelinv_ovt = -etas_ovt.imag/etas_ovt.real
        VEPars_re = etaabs_ovt
        VEPars_im = tandelinv_ovt
    # new values for VEPars at center frequency and power-law exponents 
    if np.min(np.abs(VEPars_re)) > 0:
        result_re = linregress(np.log(n_arr/n_Jref),np.log(np.abs(VEPars_re)))
        VEPar1_cen_new = np.exp(result_re.intercept)
        VEPar1_PLexpt_new = result_re.slope 
    else: 
        VEPar1_cen_new = 1e-7
        VEPar1_PLexpt_new = 0 
    if np.min(np.abs(VEPars_im)) > 0:
        result_im = linregress(np.log(n_arr/n_Jref),np.log(np.abs(VEPars_im)))
        VEPar2_cen_new = np.exp(result_im.intercept)
        VEPar2_PLexpt_new = result_im.slope 
    else:   
        VEPar2_cen_new = 1e-7
        VEPar2_PLexpt_new = 0 
    return VEPar1_cen_new,VEPar2_cen_new,VEPar1_PLexpt_new,VEPar2_PLexpt_new

def Calc_J_SI_all_layers(VEPar1_cen_lays,VEPar2_cen_lays,VEPar1_PLexpt_lays,VEPar2_PLexpt_lays,VEtype_lays,n):
    J_lays = np.ones(nlay,dtype = np.complex128)*1e-7
    Show_laysL = [Show_lay1,Show_lay2,Show_bulk]
    for il in range(nlay):
        if Show_laysL[il] == 'yes':
            VEPar1_cen = VEPar1_cen_lays[il]
            VEPar2_cen = VEPar2_cen_lays[il]
            VEPar1_PLexpt = VEPar1_PLexpt_lays[il]
            VEPar2_PLexpt = VEPar2_PLexpt_lays[il]
            VEtype = VEtype_lays[il]
            J_lays[il] = Calc_J_SI(VEPar1_cen,VEPar2_cen,VEPar1_PLexpt,VEPar2_PLexpt,VEtype,n,f_cen,f_fund)
    return J_lays

def Calc_J_SI(VEPar1_cen,VEPar2_cen,VEPar1_PLexpt,VEPar2_PLexpt,VEtype,n,f_cen,f_fund):
    # the multilayer formalism quantifies viscoelasticity with J
    VEtype = int(VEtype)
    n_norm = n * f_fund / f_cen
    om = 2. * np.pi * n * f_fund
    VE_fac_1 = n_norm**VEPar1_PLexpt
    VE_fac_2 = n_norm**VEPar2_PLexpt
    if VEtype == 0 :
        VEPar1 = VEPar1_cen * VE_fac_1 
        VEPar2 = VEPar2_cen * VE_fac_2 
        Jloc = VEPar1 - 1j * VEPar2
    if VEtype == 1 :
        VEPar1 = VEPar1_cen * VE_fac_1 
        VEPar2 = VEPar2_cen * VE_fac_2 
        Gp  = VEPar1
        Gpp = VEPar2
        Gsqr = Gp**2 + Gpp**2
        Jloc = Gp/Gsqr  - 1j * Gpp/Gsqr
    if VEtype == 2 :
        VEPar1 = VEPar1_cen * VE_fac_1 
        VEPar2 = VEPar2_cen * VE_fac_2 
        Gp  = om*VEPar2*1e-3/1e6
        Gpp = om*VEPar1*1e-3/1e6
        Gsqr = Gp**2 + Gpp**2
        Jloc = Gp/Gsqr  - 1j * Gpp/Gsqr
    if VEtype == 3 :
        VEPar1 = VEPar1_cen * VE_fac_1 
        VEPar2 = VEPar2_cen * VE_fac_2   
        Gp  =    VEPar1
        Gpp = om*VEPar2*1e-3/1e6
        Gsqr = Gp**2 + Gpp**2
        Jloc = Gp/Gsqr  - 1j * Gpp/Gsqr
    if VEtype == 4 :
        Jabs   = VEPar1_cen * VE_fac_1
        tandel = VEPar2_cen * VE_fac_2
        cosdel = 1./(1.+ tandel**2)**0.5
        sindel = tandel * cosdel
        Jp  = Jabs*cosdel
        Jpp = Jabs*sindel
        Jloc = Jp - 1j * Jpp
    if VEtype == 5 :
        Gabs   = VEPar1_cen * VE_fac_1
        tandel = VEPar2_cen * VE_fac_2
        cosdel = 1./(1.+ tandel**2)**0.5
        sindel = tandel * cosdel
        Gp  = Gabs*cosdel
        Gpp = Gabs*sindel
        Jloc = 1./(Gp + 1j * Gpp)
    if VEtype == 6 :
        etaabs    = VEPar1_cen * VE_fac_1
        tandelinv = VEPar2_cen * VE_fac_2
        cosdelinv = 1./(1.+ tandelinv**2)**0.5
        sindelinv = tandelinv * cosdelinv
        etap  = etaabs * cosdelinv
        etapp = etaabs * sindelinv
        Gp   = om*etapp*1e-3/1e6
        Gpp  = om*etap *1e-3/1e6
        Jloc = 1./(Gp + 1j * Gpp)
    # if VEtype == 8: # The following lines are meant to illustrate that other models of viscoelasticity might be chosen.  
    #               # This model has three fit paramers, only. The case VEtype == 8 never occurs in the current version
    #     Gabs   = VEPar1_cen
    #     tandel = VEPar2_cen
    #     Relax_rate_MHz = VEPar1_PLexpt
    #     cosdel = 1./(1.+ tandel**2)**0.5
    #     sindel = tandel * cosdel
    #     G_elas     = Gabs*cosdel
    #     G_Maxwell  = Gabs*sindel
    #     Relax_rate = Relax_rate_MHz * 1e6
    #     tau = 1./Relax_rate
    #     G = G_elas + G_Maxwell * (1j*om*tau)/(1+(1j*om*tau))
    #     Jloc = 1./G    
    J = Jloc * 1e-6
    return J


# Core of the fit routine, implements Eqs. 12-14 from the manual, can be extended to more layers
@jit(nopython = True)
# switch off acceleration with jit when altering the code
# jit 
# - reads global variables when the routine is called for the first time, 
#       but _does not change them_ later, when the main program changes them.
#       Variable to be changed must be passed to the function in the function call.
# - behaves in unpredictable ways then the data types are not quite right.
# - does not always issue warnings when something goes wrong

def MultilayerFormalism(t_lays,rho_lays,J_lays,VertScaleR,AspRat,n,f_fund,Zq,\
                        Show_lay1,Show_lay2,Show_bulk):
    Show_lays = [Show_lay1,Show_lay2]
    om = 2 * np.pi * n * f_fund
    Z = np.zeros(nlay,dtype = np.complex128)
    k = np.zeros(nlay,dtype = np.complex128)
    for il in range(nlay):
        k[il] = om * (rho_lays[il]*J_lays[il])**0.5
        Z[il] =      (rho_lays[il]/J_lays[il])**0.5 
        if il == 2:
            if Show_bulk == 'yes':
                delta = (1.-1j)/k[il]
                Z[il] = (Z[il].real*(1+(VertScaleR/delta)**2)) + \
                     1j*(Z[il].imag*(1-(VertScaleR/delta)**2+3*np.pi**0.5*AspRat*VertScaleR/delta)) 
                       # effective impedance includes roughness effects
            else: Z[il] = 0
    Zp1 = Z[nlay-1]
    amp = np.array([1.+0.*1j,0.+0.*1j])
    for il in range(nlay-1):
        i = nlay - il - 2
        if Show_lays[i] == 'yes' and t_lays[i] > 0:
            Zrat = Zp1/Z[i]
            Zp1 = Z[i]
            propInterface = 1./2.*np.array([[(1+Zrat)                 ,(1-Zrat)],\
                                            [(1-Zrat),(1+Zrat)]])
            propLayer     =       np.array([[np.exp(1j*k[i]*t_lays[i]),0.      ],\
                                            [0.      ,np.exp(-1j*k[i]*t_lays[i])]])
            amp = np.dot(propInterface,amp) 
            amp = np.dot(propLayer    ,amp)
    ZL = Zp1*(amp[0]-amp[1])/(amp[0]+amp[1])
    Dfcbyn = f_fund*1j /(np.pi*Zq)*ZL/n 
    return Dfcbyn 

def residuals_lmfit(Pars):
    Vals = np.ones(nFPars)*np.nan
    for iFPar in range(nFPars): Vals[iFPar] = Pars[TT.FParnames[iFPar]].value
    residuals = Calc_residuals(Vals)
    return residuals    

def Calc_residuals(Vals): 
    Dfcs_Model = Calc_Dfcbyns_from_FitVals(Vals)
    n_cen = f_cen/f_fund
    ns_inc_stacked = np.hstack((ns_inc,ns_inc))/n_cen
    residuals_Df = (Dfcs_Model.real - Dfcbyns_inc.real)
    residuals_DG = (Dfcs_Model.imag - Dfcbyns_inc.imag)*RelWeight_DfDG**0.5  
    residuals = np.hstack((residuals_Df,residuals_DG))
    if stat_weight == 'n^-1'    : residuals *= ns_inc_stacked**-0.5 
    if stat_weight == 'n^-(0.5)': residuals *= ns_inc_stacked**-0.25
    if stat_weight == 'flat'    : residuals *= 1
    if stat_weight == 'n^(0.5)' : residuals *= ns_inc_stacked**0.25
    if stat_weight == 'n^1'     : residuals *= ns_inc_stacked**0.5
    return residuals

def configure_Minimizer():
    TT.Get_FParnames()
    FitValsL = np.ones(nFPars)*np.nan
    StdErrsL = np.ones(nFPars)*np.nan
    p = lmfit.Parameters()
    for iFPar in range(nFPars):
        if GuessVals[iFPar] < MinVals[iFPar]: GuessVals[iFPar] = MinVals[iFPar] 
        if GuessVals[iFPar] > MaxVals[iFPar]: GuessVals[iFPar] = MaxVals[iFPar]
        p.add(name=TT.FParnames[iFPar],value=GuessVals[iFPar],min=MinVals[iFPar],max=MaxVals[iFPar])
    mini = lmfit.Minimizer(residuals_lmfit,p,nan_policy='omit')
    return FitValsL,StdErrsL,mini

def Minimize_lmfit_chi2(GuessVals,MinVals,MaxVals):
    FitValsL,StdErrsL,mini = configure_Minimizer()
    try: 
        result = mini.minimize(method='least_squares')
        for iFPar in range(nFPars):
            FitValsL[iFPar] = result.params[TT.FParnames[iFPar]].value
            StdErrsL[iFPar] = result.params[TT.FParnames[iFPar]].stderr
            FitFailed = 'no'
    except: 
        print('Fit failed')
        FitFailed = 'yes'
    return FitValsL,StdErrsL,FitFailed

def ConfLims_lmfit_2_Console():
# A more advanced analysis is described @ lmfit.github.io/lmfit-py/fitting.html#label-emcee
    Pars_to_Vals(); ns_inc_Dfcbyns_inc()
    FitValsL,StdErrsL,mini = configure_Minimizer()
    result = mini.minimize()
    for iFPar in range(nFPars):
        FitValsL[iFPar] = result.params[TT.FParnames[iFPar]].value
        StdErrsL[iFPar] = result.params[TT.FParnames[iFPar]].stderr
    out1 = mini.minimize(method='Nelder')
    out2 = mini.minimize(method='least_squares', params=out1.params)
    lmfit.report_fit(out2.params, min_correl=0.5)
    try : 
        ci = lmfit.conf_interval(mini, out2, sigmas=[1, 2])
        lmfit.printfuncs.report_ci(ci)
        
        plt.figsize=(4,4)
        x = ns_inc*f_fund/1e6; yreal = Dfcbyns_inc.real; yimag = Dfcbyns_inc.imag
        residuals = residuals_lmfit(out2.params)
        yreal_fit = residuals[:int(len(residuals)/2)] + yreal
        yimag_fit = residuals[int(len(residuals)/2):] + yimag
        plt.plot(x,yreal,'x',color='r'); plt.plot(x,yreal_fit,color='b') 
        plt.plot(x,yimag,'x',color='r'); plt.plot(x,yimag_fit,color='b')
        plt.xlabel('f [MHz]'); plt.ylabel('\u0394f/n, \u0394\u0393/n [Hz]'); plt.show()
    
        for iFPar1 in range(nFPars):
            for iFPar2 in range(iFPar1):
                iFPar = 0
                for key in keys:
                    if IncPars[key] == 1:
                        if iFPar == iFPar1 : key1 = key
                        if iFPar == iFPar2 : key2 = key
                        iFPar += 1
                print(iFPar1,':',key1,iFPar2,':',key2)
                lowbnd1 = np.max([LimitsMinPars[key1],FitValsL[iFPar1] - 3*StdErrsL[iFPar1]])
                lowbnd2 = np.max([LimitsMinPars[key2],FitValsL[iFPar2] - 3*StdErrsL[iFPar2]])
                uppbnd1 = np.min([LimitsMaxPars[key1],FitValsL[iFPar1] + 3*StdErrsL[iFPar1]])
                uppbnd2 = np.min([LimitsMaxPars[key2],FitValsL[iFPar2] + 3*StdErrsL[iFPar2]])
                cx,cy,grid = lmfit.conf_interval2d(mini,out2,TT.FParnames[iFPar1],TT.FParnames[iFPar2],30,30,\
                    limits=((uppbnd1,lowbnd1),(uppbnd2,lowbnd2)))
                plt.contourf(cx,cy,grid,np.linspace(0,1,11)); plt.colorbar()
                plt.xlabel(TT.FParnames[iFPar1]); plt.ylabel(TT.FParnames[iFPar2]); plt.show()
    except : print('problem with confidence limits') 

def ConfLims_lmfit_2_Textline():
    Pars_to_Vals(); ns_inc_Dfcbyns_inc()
    FitValsL,StdErrsL,mini = configure_Minimizer()
    result = mini.minimize()
    for iFPar in range(nFPars):
        FitValsL[iFPar] = result.params[TT.FParnames[iFPar]].value
        StdErrsL[iFPar] = result.params[TT.FParnames[iFPar]].stderr
    out1 = mini.minimize(method='Nelder')
    out2 = mini.minimize(method='leastsq', params=out1.params)
    ConfLim_header = ''; Textline = ''
    # try :
    ci = lmfit.conf_interval(mini, out2, sigmas=[1, 2])
    lmfit.printfuncs.report_ci(ci)
    for iFPar in range(nFPars):
        ConfLim_header += TT.FParnames[iFPar] + '\t'
        for i in range(len(ci[TT.FParnames[iFPar]])): 
            ciFPar = ci[TT.FParnames[iFPar]]
            percent = np.round(ciFPar[i][0]*100,2)
            ConfLim_header += str(percent) + '%' + '\t'
    ConfLim_header += '\n'        
    for iFPar in range(nFPars):
        Textline += TT.FParnames[iFPar] + '\t'
        for i in range(len(ci[TT.FParnames[iFPar]])): 
            ciFPar = ci[TT.FParnames[iFPar]]
            val = np.round(ciFPar[i][1],5)
            Textline += str(val) + '\t'
    Textline += '\n'        
    # except : 
    #     print('problem with confidence intervals')
    return ConfLim_header,Textline        

def FitVals_to_SamplePars(FitValsL):
    iFPar = 0
    for key in keys:
        if IncPars[key] == 1:
            SamplePars[key] = FitValsL[iFPar] 
            iFPar += 1

def FitErrs_to_SampleErrs(StdErrsL):
    iFPar = 0
    for key in keys:
        if IncPars[key] == 1:
            SampleStdErrs[key] = StdErrsL[iFPar]
            iFPar += 1

def Pars_to_Vals():
    global GuessVals,PreviousVals,GuessValsSeries,MinVals,MaxVals,Graph_Labels
    # 'Vals' refers to arrays of length nFPars of parameters such as the fit parameters 
    # nFPars is 6 at most
    nFPars = 0 
    for key in keys: nFPars += IncPars[key]
    GuessVals       = np.ones(nFPars)*np.nan 
    MinVals = np.ones(nFPars); MaxVals = np.ones(nFPars)
    Graph_Labels = []
    iFPar = 0
    for key in keys:
        if IncPars[key] == 1: 
            if Fit_Called_from == 'FitPoint': 
                if not np.isnan(SamplePars[key]): GuessVals[iFPar] = SamplePars[key]
                else                            : GuessVals[iFPar] = LimitsMinPars[key]
                if key == 't_lay1' and SamplePars[key] < 1e-2: GuessVals[iFPar] = 1e-2
                if key == 't_lay2' and SamplePars[key] < 1e-2: GuessVals[iFPar] = 1e-2
            else : 
                if TT_guess_from  == 'from_previous_fit':
                    GuessVals[iFPar] = PreviousVals[iFPar]
                else : 
                    GuessVals[iFPar] = GuessValsSeries[iFPar]
            MinVals[iFPar] = LimitsMinPars[key] 
            MaxVals[iFPar] = LimitsMaxPars[key] 
            Graph_Labels = np.append(Graph_Labels,IO_Labels[key]) 
            iFPar += 1
 
def Pars_to_FitVals_for_Export():
    global FitVals_for_Export,StdErrs_for_Export
    nFPars = 0 
    for key in keys: nFPars += IncPars[key]
    FitVals_for_Export = np.ones(nFPars)*np.nan 
    StdErrs_for_Export = np.ones(nFPars)*np.nan 
    iFPar = 0
    for key in keys:
        if IncPars[key] == 1: 
            FitVals_for_Export[iFPar] = SamplePars[key]
            StdErrs_for_Export[iFPar] = SampleStdErrs[key]
            iFPar += 1

def Calc_DfcbynNoRef(Pars,n):
    t_lays,rho_lays,VEPar1_cen_lays,VEPar2_cen_lays,VEPar1_PLexpt_lays,VEPar2_PLexpt_lays,\
        VertScaleR,AspRat,VEtype_lays = get_layer_arrays(Pars)
    J_lays = Calc_J_SI_all_layers(VEPar1_cen_lays,VEPar2_cen_lays,
                                  VEPar1_PLexpt_lays,VEPar2_PLexpt_lays,VEtype_lays,n)
    if Model == 'Multilayer_Formalism'  : DfcbynNoRef = MultilayerFormalism(\
                 t_lays,rho_lays,J_lays,VertScaleR,AspRat,n,f_fund,Zq,Show_lay1,Show_lay2,Show_bulk)
    if Model == '3rd-Order_Perturbation': DfcbynNoRef = Pert.Perturbation_3(\
                 t_lays,rho_lays,J_lays,VertScaleR,AspRat,n,f_fund,Zq,Show_lay1,Show_lay2,Show_bulk)
    if Model == '5th-Order_Perturbation': DfcbynNoRef = Pert.Perturbation_5(\
                 t_lays,rho_lays,J_lays,VertScaleR,AspRat,n,f_fund,Zq,Show_lay1,Show_lay2,Show_bulk)
    # if Model == 'Thin_Film_Jpp1 small'  : DfcbynNoRef = Thin_Film_Jpp1Small(\
    #              t_lays,rho_lays,J_lays,VertScaleR,AspRat,n,f_fund,Zq)
    return DfcbynNoRef

def Calc_Dfcbyns_from_FitVals(FitVals):
    Dfcbyns_fit     = np.zeros(len(ns_inc),dtype=np.complex128)
    Dfcbyns_fit_ref = np.zeros(len(ns_inc),dtype=np.complex128)
    if len(ns_inc) > 0: 
        FitVals_to_SamplePars(FitVals)
        for i,n in enumerate(ns_inc):
            Dfcbyns_fit[i]     = Calc_DfcbynNoRef(SamplePars,n)
            Dfcbyns_fit_ref[i] = Calc_DfcbynNoRef(RefPars   ,n)
            Dfcbyns_fit[i]    -= Dfcbyns_fit_ref[i]  
    return Dfcbyns_fit

def Calc_chi2():
    global chi2
    ns_inc_Dfcbyns_inc()
    if len(ns_inc) == 0: chi2 = np.nan; return 
    Pars_to_Vals(); residuals = Calc_residuals(GuessVals) 
    chi2 = np.sum(residuals**2)
    chi2 /= ErrDfbyn**2   
    nfree = 2 * np.sum(OvtInc) - nFPars
    if nfree > 0: chi2 /= nfree 
    else        : chi2 = np.nan

def Fit():
    global Dfcbyns_fit,FittedVals,StdErrs,Dfcbyns_fit_n_arr,FitFailed
    Dfcbyns_fit_n_arr = np.zeros(novt,dtype = np.complex128)
    Pars_to_Vals(); ns_inc_Dfcbyns_inc()
    FittedVals,StdErrs,FitFailed = Minimize_lmfit_chi2(GuessVals,MinVals,MaxVals)
    iFPar = 0
    for key in keys:
        if IncPars[key] == 1:
            SamplePars[   key] = FittedVals[iFPar]
            SampleStdErrs[key] = StdErrs[iFPar]
            iFPar += 1
        else: SampleStdErrs[key] = np.nan
    Dfcbyns_fit = Calc_Dfcbyns_from_FitVals(FittedVals)
    count = 0
    for iovt in range(novt):
        if OvtInc[iovt]: 
            Dfcbyns_fit_n_arr[iovt] = Dfcbyns_fit[count]
            count += 1
        else: Dfcbyns_fit_n_arr[iovt] = np.nan + 1j*np.nan   

def Simulate():
    global n_sims,Dfcbyns_sim,DataContainNans
    nsim = int((13-1)*10)
    n_sims = np.linspace(1,13,nsim)
    Dfcbyns_sim     = np.zeros(nsim,dtype = np.complex128)
    Dfcbyns_sim_ref = np.zeros(nsim,dtype = np.complex128)
    DataContainNans = 'no'
    for i,n_sim in enumerate(n_sims):
        Dfcbyns_sim[i]     = Calc_DfcbynNoRef(SamplePars,n_sim)
        Dfcbyns_sim_ref[i] = Calc_DfcbynNoRef(RefPars   ,n_sim)
        Dfcbyns_sim[i]    -= Dfcbyns_sim_ref[i]
        if np.isnan(Dfcbyns_sim[i]) : DataContainNans = 'yes'
    Calc_chi2()

def Determine_Layers_IncInFits():
    Layers_Included = np.zeros((3),dtype = int)
    for key in keys:
        if 'lay1' in key and IncPars[key] == 1 : 
            Layers_Included[0] = 1; i_layer = 1 
        if 'lay2' in key and IncPars[key] == 1 : 
            Layers_Included[1] = 1; i_layer = 2
        if 'lay3' in key and IncPars[key] == 1 : 
            Layers_Included[2] = 1; i_layer = 3
    if not key in ['VertScaleR','AspRat'] and np.sum(Layers_Included) == 1:
        SingleLayer = True
    else :
        SingleLayer = False; i_layer = 0
    return SingleLayer,i_layer