import numpy as np
import tkinter as tk
from tkinter import ttk
import QTM_Core as Cor
import QTM_TT_IO as TT
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import os

def MakeFrame1(cntr):
    def Enter_n_RndNoise(event):
        string = n_RndNoise_SV.get(); string.strip()
        try: 
            Cor.n_RndNoise = int(string); Cor.Write_Config()
        except: pass    
    
    def enter_i_RN_Par(event,WhichPar):
        if WhichPar == 'i_RN_Par1': 
            i_RN_Par1 = event.widget.get()
            for i,i_RN_Par in enumerate(i_RN_Par_Labels):
                if i_RN_Par1 == i_RN_Par: Cor.i_RN_Par1 = i
            Cor.Write_Config()
            if not FittedVals_arr is None : Plot_Correlation(Frame3)
        if WhichPar == 'i_RN_Par2': 
            i_RN_Par2 = event.widget.get()
            for i,i_RN_Par in enumerate(i_RN_Par_Labels):
                if i_RN_Par2 == i_RN_Par: Cor.i_RN_Par2 = i
            Cor.Write_Config()
            if not FittedVals_arr is None : Plot_Correlation(Frame3)

    i_RN_Par_Labels = []; i_RN_Par_keys = []
    for key in Cor.keys: 
        if Cor.IncPars[key] == 1:
            i_RN_Par_Labels.append(TT.header_Labels[key])
            i_RN_Par_keys.append(key)

    tk.Button(cntr,text ='Run',command=lambda: Run_RndNoise()).grid(row=0,column=0)
    tk.Label(cntr,text='Samples').grid(row=0,column=2,sticky='W')

    n_RndNoise_SV = tk.StringVar(cntr,Cor.n_RndNoise)
    n_RndNoise_Entry = tk.Entry(cntr,width=12,textvariable=n_RndNoise_SV)
    n_RndNoise_Entry.grid(row=1,column=2)
    n_RndNoise_Entry.bind('<Return>',lambda event: Enter_n_RndNoise(event))
    
    i_RN_Par1_cb = ttk.Combobox(cntr,state='readonly',width=46,textvariable=i_RN_Par_Labels[Cor.i_RN_Par1],values = i_RN_Par_Labels) 
    i_RN_Par2_cb = ttk.Combobox(cntr,state='readonly',width=46,textvariable=i_RN_Par_Labels[Cor.i_RN_Par2],values = i_RN_Par_Labels) 
    i_RN_Par1_cb.current(Cor.i_RN_Par1)
    i_RN_Par2_cb.current(Cor.i_RN_Par2)
    i_RN_Par1_cb.grid(row=1,column=0,columnspan=2,sticky='W')
    i_RN_Par2_cb.grid(row=2,column=0,columnspan=2,sticky='W')
    i_RN_Par1_cb.bind('<<ComboboxSelected>>',lambda event: enter_i_RN_Par(event,'i_RN_Par1'))
    i_RN_Par2_cb.bind('<<ComboboxSelected>>',lambda event: enter_i_RN_Par(event,'i_RN_Par2'))

def Run_RndNoise():
    global FittedVals_arr,RN_Means,RN_StdErrs
    
    RndNoiseRoot.config(cursor='watch')
    Dfbyns_nonoise = np.zeros(Cor.novt)
    DGbyns_nonoise = np.zeros(Cor.novt)
    for iovt in range(Cor.novt):    
        Dfbyns_nonoise[iovt] = Cor.Dfbyns[iovt]
        DGbyns_nonoise[iovt] = Cor.DGbyns[iovt]
    FittedVals_arr = np.ones((Cor.nFPars,Cor.n_RndNoise))*np.nan
    RN_Means   = np.ones(Cor.nFPars)*np.nan
    RN_StdErrs = np.ones(Cor.nFPars)*np.nan
    icount = 0; i_count_total = 0
    while icount < Cor.n_RndNoise - 1 and i_count_total <= 2 * Cor.n_RndNoise: 
        if icount%100 == 0 : print(icount,'/',Cor.n_RndNoise)
        for i2 in range(len(Cor.ns_inc)):
            Cor.Dfbyns[i2] = Dfbyns_nonoise[i2] + np.random.normal(0,Cor.ErrDfbyn)
            Cor.DGbyns[i2] = DGbyns_nonoise[i2] + np.random.normal(0,Cor.ErrDfbyn)
            Cor.Dfcbyns_inc[i2] = Cor.Dfbyns[i2] + 1j * Cor.DGbyns[i2]
        try : 
            FittedVals,StdErrs,FitFailed = Cor.Minimize_lmfit_chi2(Cor.GuessVals,Cor.MinVals,Cor.MaxVals)
            FittedVals_arr[:,icount] = FittedVals
            notNans = True
            for FittedVal in FittedVals : 
                if np.isnan(FittedVal) : notNans = False
            if notNans : icount += 1
            else       : print('Nans encountered')
        except : print('fit failed')
        i_count_total += 1  
    if i_count_total > 2 * Cor.n_RndNoise - 2: 
        print('All failed'); 
        tk.messagebox.showinfo('','All failed'); 
        return
    for iFPar in range(Cor.nFPars):
        RN_Means[iFPar]   = np.nanmean(FittedVals_arr[iFPar])
        RN_StdErrs[iFPar] = np.nanstd( FittedVals_arr[iFPar])
    Plot_RndNoise(Frame2) 
    Plot_Correlation(Frame3)        
    for iovt in range(Cor.novt):    
        Cor.Dfbyns[iovt] = Dfbyns_nonoise[iovt]
        Cor.DGbyns[iovt] = DGbyns_nonoise[iovt]
    RndNoiseRoot.config(cursor='')

def Plot_RndNoise(cntr):
    for widget in cntr.winfo_children(): widget.destroy()    
    fig = Figure(figsize = (3.,5.5),dpi = 100)
    for iFPar in range(Cor.nFPars):
        axis = fig.add_subplot(Cor.nFPars,1,1+iFPar)
        axis.xaxis.label.set_fontsize(9)
        axis.yaxis.label.set_fontsize(9)
        axis.hist(FittedVals_arr[iFPar],bins=50)
        count = 0
        for key in Cor.keys:
            if Cor.IncPars[key] == 1: 
                if iFPar == count: axis.set_xlabel(TT.Graph_TT_Labels[key],fontsize=7)
                count += 1 
        axis.tick_params(labelsize = 8,direction='in')
        axis.set_title(str(np.round(RN_Means[iFPar],3)) + '\u00b1' + str(np.round(RN_StdErrs[iFPar],3)),fontsize = 8)

    suptitletext = ''
    if len(Cor.InfoString) > 0: suptitletext += Cor.InfoString
    if Cor.TT_IO_Format == 'from_QSoft_new': 
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:45] + ' chan ' + str(Cor.i_channel+1)
    else:  
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:55]
    fig.suptitle(suptitletext,fontsize = 8)

    fig.tight_layout(); fig.savefig(os.getcwd()+'/tmp/RndNoise_Histograms.png',dpi=200)
    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); canvas.get_tk_widget().pack()

def Plot_Correlation(cntr):
    for widget in cntr.winfo_children(): widget.destroy()    
    fig = Figure(figsize = (2.5,2.5),dpi = 100)
    axis = fig.add_subplot(1,1,1)
    axis.xaxis.label.set_fontsize(9)
    axis.yaxis.label.set_fontsize(9)
    axis.plot(FittedVals_arr[Cor.i_RN_Par1],FittedVals_arr[Cor.i_RN_Par2],'x')
    count = 0
    for key in Cor.keys:
        if Cor.IncPars[key] == 1: 
            if Cor.i_RN_Par1 == count: axis.set_xlabel(TT.Graph_TT_Labels[key],fontsize=7)
            if Cor.i_RN_Par2 == count: axis.set_ylabel(TT.Graph_TT_Labels[key],fontsize=7)
            count += 1 
    axis.tick_params(labelsize = 8,direction='in')
    
    suptitletext = ''
    if len(Cor.InfoString) > 0: suptitletext += Cor.InfoString
    if Cor.TT_IO_Format == 'from_QSoft_new': 
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:45] + ' chan ' + str(Cor.i_channel+1)
    else:  
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:55]
    fig.suptitle(suptitletext,fontsize = 8)
    
    fig.tight_layout(); fig.savefig(os.getcwd()+'/tmp/RndNoise_Correlations.png',dpi=200)
    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); canvas.get_tk_widget().pack()

def RndNoise_Start():
    if Cor.nFPars < Cor.i_RN_Par1 + 1 or Cor.nFPars < Cor.i_RN_Par2 + 1 :
        print('Cor.i_RN_Par1',Cor.i_RN_Par1)
        print('Cor.i_RN_Par2',Cor.i_RN_Par2)
        print('Cor.nFPars',Cor.nFPars)
        tk.messagebox.showinfo('','not enough active fit parameters'); return
    global Frame1,Frame2,Frame3,RndNoiseRoot
    RndNoiseRoot = tk.Tk(); RndNoiseRoot.title('Random Noise Added to Data')
    Frame1 = tk.LabelFrame(RndNoiseRoot); Frame1.grid(row=0,column=0,sticky = 'NW'); MakeFrame1(Frame1)
    Frame2 = tk.LabelFrame(RndNoiseRoot); Frame2.grid(row=1,column=0,sticky = 'NW') 
    Frame3 = tk.LabelFrame(RndNoiseRoot); Frame3.grid(row=1,column=1,sticky = 'NW')
    RndNoiseRoot.iconbitmap("QTM.ico")
    RndNoiseRoot.mainloop()
