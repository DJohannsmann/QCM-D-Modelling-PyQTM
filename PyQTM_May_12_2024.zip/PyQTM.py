import numpy as np
import tkinter as tk
from tkinter import Toplevel
import QTM_Core as Cor
import QTM_Limits as Limits
import QTM_TT_IO as TT
import QTM_chi2_Landscape as chi2_Landscape
import QTM_Bootstrap as Bootstrap
import QTM_RndNoise as RndNoise
import QTM_FuzzyInterface as FuzzyInterface

from matplotlib.backends.backend_tkagg import(FigureCanvasTkAgg)
from matplotlib.figure import Figure
from tkinter import filedialog as fd

import shutil
import os
import datetime
import pandas as pd

def Undo():
    if os.path.isfile(Cor.CurrWD+'/tmp/Backup.qt2'): 
        shutil.copyfile(Cor.CurrWD+'/tmp/Backup.qt2',Cor.CurrWD+'/tmp/Master.qtm')
        Cor.Read_Config(); TT.Initialize()
        Update_User_Interface()

def Clear_Fits():
    for j in range(len(TT.TT_FPars[0])):     TT.TT_FPars[    :,j] = np.nan
    for j in range(len(TT.TT_FParsConv[0])): TT.TT_FParsConv[:,j] = np.nan
    for j in range(len(TT.DfDGbyns)):     
        for iovt in range(Cor.novt):  
            TT.DfDGbyns[j,2+4*iovt+2]= np.nan
            TT.DfDGbyns[j,2+4*iovt+3]= np.nan
    TT.Make_headers()
    np.savetxt(Cor.CurrWD+'/tmp/FitPars.qt2'               ,TT.TT_FPars    ,header=TT.header_FPars_TimeSer    ,delimiter='\t',newline='\n')
    np.savetxt(Cor.CurrWD+'/tmp/FitParsConv.qt2'           ,TT.TT_FParsConv,header=TT.header_FParsConv_TimeSer,delimiter='\t',newline='\n')
    np.savetxt(Cor.CurrWD+'/tmp/FitPars_for_unhide.qt2'    ,TT.TT_FPars    ,header=TT.header_FPars_TimeSer    ,delimiter='\t')
    np.savetxt(Cor.CurrWD+'/tmp/FitParsConv_for_unhide.qt2',TT.TT_FParsConv,header=TT.header_FParsConv_TimeSer,delimiter='\t')
    PlotFPars(   PlotFParsFrame)
    PlotDfDGbyns(PlotDfDGbynsFrame)
    TT.Make_headers()            

def Calc_nFPars():
    Cor.nFPars = 0
    for key in Cor.keys: 
        if Cor.IncPars[key] == 1: Cor.nFPars += 1

def Fit():
    shutil.copyfile(Cor.CurrWD+'/tmp/Master.qtm',Cor.CurrWD+'/tmp/Backup.qt2')
    Check_for_NaNs_in_Dfcs()
    Calc_nFPars()
    if 2*np.sum(Cor.OvtInc) < Cor.nFPars: 
        tk.messagebox.showinfo('','number of fit parameters > 2 * number of active overtones'); return
    if Cor.nFPars == 0: 
        tk.messagebox.showinfo('','no active fit parameters'); return
    Cor.Fit(); Cor.FitVals_to_SamplePars(Cor.FittedVals)
    Cor.ParsGood = 'yes'
    Cor.Do_SaveQuery = 'yes'
    Cor.Write_Config()
    PlotSingle(PlotSingleFrame)
    MakeSampleParsFrame(SampleParsFrame)
    TT.Make_headers()
    f = open(Cor.CurrWD+'/tmp/LogFile.qt2','a')
    now = datetime.datetime.now()
    f.write(now.strftime("%Y-%m-%d %H:%M:%S") + '\n')
    f.write(Cor.TT_filename + ' Data_Point '+ str(Cor.i_selec) + '\n')
    f.write(TT.header_FPars_LogFile + '\n' )
    outputline = str(Cor.i_selec) + '\t' + str(TT.DfDGbyns[Cor.i_selec,1]) + '\t'
    for iFPar in range(Cor.nFPars):
        outputline += "{:.5e}".format(Cor.FittedVals[iFPar]) + '\t' +"{:.5e}".format(Cor.StdErrs[iFPar]) + '\t'
    outputline += "{:.5e}".format(Cor.chi2) + '\n'
    f.write(outputline)
    f.close()
    MakeFitFrame(FitFrame)

def Fit_Series():
    def Save_Display_FPars():
        TT.Make_headers()
        np.savetxt(Cor.CurrWD+'/tmp/Shifts.qt2'                ,TT.DfDGbyns    ,header=TT.header_DfDGbyns         ,delimiter='\t',newline='\n')
        np.savetxt(Cor.CurrWD+'/tmp/FitPars.qt2'               ,TT.TT_FPars    ,header=TT.header_FPars_TimeSer    ,delimiter='\t',newline='\n')
        np.savetxt(Cor.CurrWD+'/tmp/FitParsConv.qt2'           ,TT.TT_FParsConv,header=TT.header_FParsConv_TimeSer,delimiter='\t',newline='\n')
        np.savetxt(Cor.CurrWD+'/tmp/FitPars_for_unhide.qt2'    ,TT.TT_FPars    ,header=TT.header_FPars_TimeSer    ,delimiter='\t',newline='\n')
        np.savetxt(Cor.CurrWD+'/tmp/FitParsConv_for_unhide.qt2',TT.TT_FParsConv,header=TT.header_FParsConv_TimeSer,delimiter='\t',newline='\n')

    if Cor.Abort_Enabled: Cor.Abort = True; return
    Cor.Abort = False; Cor.Abort_Enabled = True; Fit_Series_Btn['text'] = 'Abort'; Root.update(); Calc_nFPars()
    if Cor.nFPars == 0: tk.messagebox.showinfo('','no active fit parameters')
    else:
        Cor.Pars_to_Vals()
        for iFPar in range(len(Cor.GuessVals)): 
            Cor.GuessValsFromPrevious[iFPar] = Cor.GuessVals[iFPar]
        if Cor.TT_guess_from == 'from_ParsPanel':
            for iFPar in range(len(Cor.GuessVals)): 
                Cor.GuessValsFromParsPanel[iFPar] = Cor.GuessVals[iFPar]
        if Cor.TT_direcFitSeries == 'start_to_stop':
            TT_strt = Cor.i_strt_fit; TT_stop = Cor.i_stop_fit;  TT_step = 1
        else:
            TT_strt = Cor.i_stop_fit;  TT_stop = Cor.i_strt_fit; TT_step = -1
        for it in range(TT_strt,TT_stop,TT_step):
            if Cor.Abort:
                Save_Display_FPars()
                Cor.Abort_Enabled = False; Cor.Abort = False
                Fit_Series_Btn['text'] = 'Fit Series'; Root.update()
                return
            Cor.i_current = it
            Cor.ParsGood = 'yes'
            for iovt in range(Cor.novt): 
                Cor.Dfbyns[iovt] = TT.DfDGbyns[it,2+4*iovt  ]
                Cor.DGbyns[iovt] = TT.DfDGbyns[it,2+4*iovt+1]
            Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns
            Not_NaNs = True
            for iovt in range(Cor.novt):
                if Cor.OvtInc[iovt] and np.isnan(Cor.Dfcbyns[iovt]): Not_NaNs = False
            if Not_NaNs:     
                Cor.Fit()
                Converted_Vals = TT.Convert_Single()
                Cor.Dfcbyns_fit = Cor.Calc_Dfcbyns_from_FitVals(Cor.FittedVals)
                if Cor.TT_guess_from == 'from_previous_fit': 
                    Cor.GuessValsFromPrevious = Cor.FittedVals
            TT.TT_FPars[    it,0] = it
            TT.TT_FPars[    it,1] = TT.DfDGbyns[it,1]
            TT.TT_FParsConv[it,0] = it
            TT.TT_FParsConv[it,1] = TT.DfDGbyns[it,1]
            if not Cor.DataContainNans == 'yes':
                for iFPar in range(Cor.nFPars): 
                    TT.TT_FPars[    it,2+2*iFPar  ] = Cor.FittedVals[iFPar]
                    TT.TT_FPars[    it,2+2*iFPar+1] = Cor.StdErrs[   iFPar]
                for iFPar in range(5): 
                    TT.TT_FParsConv[it,2+  iFPar  ] = Converted_Vals[iFPar]
            else:
                for iFPar in range(Cor.nFPars): 
                    TT.TT_FPars[    it,2+2*iFPar  ] = np.nan
                    TT.TT_FPars[    it,2+2*iFPar+1] = np.nan
                for iFPar in range(5): 
                    TT.TT_FParsConv[it,2+  iFPar  ] = np.nan
            for iovt in range(Cor.novt):
                TT.DfDGbyns[it,2+4*iovt+2] = Cor.Dfcbyns_fit_n_arr[iovt].real
                TT.DfDGbyns[it,2+4*iovt+3] = Cor.Dfcbyns_fit_n_arr[iovt].imag
            Cor.Calc_chi2(); TT.TT_FPars[it,-1] = Cor.chi2; TT.TT_FParsConv[it,-1] = Cor.chi2
            if Not_NaNs:     
                if (it-Cor.i_strt_fit)%Cor.Update_Inval == Cor.Update_Inval-1: 
                    Cor.FitVals_to_SamplePars(Cor.FittedVals)
                    Cor.Write_Config()
                    Cor.i_selec = it
                    MakeSampleParsFrame(SampleParsFrame)
                    MakeDfcbynsFrame(DfcbynsFrame)
                    PlotSingle(PlotSingleFrame)
                    PlotDfDGbyns(PlotDfDGbynsFrame)
                    PlotFPars(PlotFParsFrame)
                    Root.update()

    Save_Display_FPars()
    MakeSampleParsFrame(SampleParsFrame)
    PlotDfDGbyns(PlotDfDGbynsFrame)   
    PlotFPars(PlotFParsFrame)
    Fit_Series_Btn['text'] = 'Fit Series'; Cor.Abort_Enabled = False; Cor.ParsGood = 'yes'; Cor.Do_SaveQuery = 'yes'
    np.savetxt(Cor.CurrWD+'/tmp/Shifts_for_unhide.qt2'     ,TT.DfDGbyns    ,header=TT.header_DfDGbyns         ,delimiter='\t')
    np.savetxt(Cor.CurrWD+'/tmp/FitPars_for_unhide.qt2'    ,TT.TT_FPars    ,header=TT.header_FPars_TimeSer    ,delimiter='\t')
    np.savetxt(Cor.CurrWD+'/tmp/FitParsConv_for_unhide.qt2',TT.TT_FParsConv,header=TT.header_FParsConv_TimeSer,delimiter='\t')

    f = open(Cor.CurrWD+'/tmp/LogFile.qt2','a')
    now = datetime.datetime.now()
    f.write(now.strftime("%Y-%m-%d %H:%M:%S") + '\n')
    f.write(Cor.TT_filename + ' Range Fit \n')
    f.write(TT.header_FPars_LogFile + '\n' )
    outputline = str(Cor.i_strt_fit) + '\t' + str(TT.DfDGbyns[Cor.i_strt_fit,1]) + '\t'
    for iFPar in range(Cor.nFPars):
        outputline += "{:.5e}".format(TT.TT_FPars[Cor.i_strt_fit,2+2*iFPar]) + '\t' +"{:.5e}".format(TT.TT_FPars[Cor.i_strt_fit,2+2*iFPar+1]) + '\t'
    outputline += "{:.5e}".format(Cor.chi2) + '\n'
    f.write(outputline)
    
    f.write(now.strftime("%Y-%m-%d %H:%M:%S") + '\n')
    f.write(Cor.TT_filename + ' Range Fit \n')
    f.write(TT.header_FPars_LogFile + '\n' )
    outputline = str(Cor.i_stop_fit) + '\t' + str(TT.DfDGbyns[Cor.i_stop_fit,1]) + '\t'
    for iFPar in range(Cor.nFPars):
        outputline += "{:.5e}".format(TT.TT_FPars[Cor.i_stop_fit,2+2*iFPar]) + '\t' +"{:.5e}".format(TT.TT_FPars[Cor.i_stop_fit,2+2*iFPar+1]) + '\t'
    outputline += "{:.5e}".format(Cor.chi2) + '\n'
    f.write(outputline)
    f.close()

def ConfLims_lmfit_2_Console(): 
      if tk.messagebox.askquestion('','May take some time \n (dedending on the number of fit parameters) \n Proceed?') == 'yes': 
          Cor.ConfLims_lmfit_2_Console()

def Check_for_NaNs_in_Dfcs():
    OvtInc_Changed = False
    OvtInc_old = np.copy(Cor.OvtInc)
    for iovt in range(Cor.novt): 
        if np.isnan(Cor.Dfbyns[iovt]) or np.isnan(Cor.DGbyns[iovt]):
            Cor.OvtInc[iovt] = 0
            if OvtInc_old[iovt] != Cor.OvtInc[iovt]: OvtInc_Changed = True
    if OvtInc_Changed: 
        Cor.Write_Config()
        MakeDfcbynsFrame(DfcbynsFrame)

def All_NaNs_in_Dfcs():
    All_NaNs = True
    for iovt in range(Cor.novt): 
        if not np.isnan(TT.DfDGbyns[Cor.i_selec,2+4*iovt  ]) or \
           not np.isnan(TT.DfDGbyns[Cor.i_selec,2+4*iovt+1]): All_NaNs = False
    return All_NaNs    

def All_NaNs_in_array(array):
    All_NaNs = True
    for i in range(len(array)): 
        if not np.isnan(array[i]): All_NaNs = False
    return All_NaNs    

def PlotSingle(cntr):
    Cor.ns_inc_Dfcbyns_inc(); Cor.Simulate() 
    for widget in cntr.winfo_children(): widget.destroy()
    fig = Figure(figsize = (SinglePlotWidth,SinglePlotHeight),dpi=mydpi) 
    axis = fig.add_subplot(211)
    if np.sum(Cor.OvtInc) > 0: 
        axis.plot(Cor.ns_inc*Cor.f_fund/1e6,Cor.Dfcbyns_inc.real,'x',color='r',label='\u0394f/n [Hz]',\
                  markersize = 6)
    axis.plot(    Cor.n_sims*Cor.f_fund/1e6,Cor.Dfcbyns_sim.real,'-',color='r',\
              markersize = 6)
    axis.tick_params(labelsize=7,direction='in')
    axis.axes.xaxis.set_ticklabels([])
    axis.set_ylabel('\u0394f/n [Hz]',fontsize=8)
    axis = fig.add_subplot(212)
    if Cor.DD_DGbyn == 'DD':
        if np.sum(Cor.OvtInc) > 0: 
            axis.plot(Cor.ns_inc*Cor.f_fund/1e6,Cor.Dfcbyns_inc.imag/Cor.f_fund*2./1e-6,'x',color='b',\
                      markersize = 6)
        axis.plot(    Cor.n_sims*Cor.f_fund/1e6,Cor.Dfcbyns_sim.imag/Cor.f_fund*2./1e-6,'-',color='b',\
                  markersize = 6)
    if Cor.DD_DGbyn == 'DGbyn': 
        if np.sum(Cor.OvtInc) > 0: 
            axis.plot(Cor.ns_inc*Cor.f_fund/1e6,Cor.Dfcbyns_inc.imag,'x',color='b',\
                      markersize = 6)
        axis.plot(    Cor.n_sims*Cor.f_fund/1e6,Cor.Dfcbyns_sim.imag,'-',color='b',\
                  markersize = 6)
    axis.tick_params(labelsize=7,direction='in')
    axis.set_xlabel('f [MHz]',fontsize=8)
    if Cor.DD_DGbyn == 'DD'   : axis.set_ylabel('\u0394D [10\u207B\u2076]',fontsize=8)
    if Cor.DD_DGbyn == 'DGbyn': axis.set_ylabel('\u0394\u0393/n [Hz]',fontsize=8)
    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw() 
    canvas.get_tk_widget().grid(row=0,column=0,columnspan=2,sticky='NW')
    DfDGbyn_sim = [Cor.n_sims*Cor.f_fund/1e6]
    DfDGbyn_sim = np.append(DfDGbyn_sim,[Cor.Dfcbyns_sim.real],axis=0)
    if Cor.DD_DGbyn == 'DGbyn':
        header =  'f[MHz] \t Dfbyn[Hz] \t DGbyn[Hz]'
        DfDGbyn_sim = np.append(DfDGbyn_sim,[Cor.Dfcbyns_sim.imag],axis=0)
    if Cor.DD_DGbyn == 'DD':
        header = 'f[MHz] \t Dfbyn[Hz] \t DD[10^-6]'
        DfDGbyn_sim = np.append(DfDGbyn_sim,[Cor.Dfcbyns_sim.imag/Cor.f_fund*2./1e-6],axis=0)
    np.savetxt(Cor.CurrWD+'/tmp/Simulated_Dfcbyn.qt2',np.transpose(DfDGbyn_sim),header=header,delimiter='\t')    
    if np.sum(Cor.OvtInc) > 0:
        DfDGbyn_Exp = [Cor.ns_inc*Cor.f_fund/1e6]
        DfDGbyn_Exp = np.append(DfDGbyn_Exp,[Cor.Dfcbyns_inc.real],axis=0)
        if Cor.DD_DGbyn == 'DGbyn':
            header='f[MHz] \t Dfbyn[Hz] \t DGbyn[Hz]'
            DfDGbyn_Exp = np.append(DfDGbyn_Exp,[Cor.Dfcbyns_inc.imag],axis=0)
        if Cor.DD_DGbyn == 'DD':
            header = 'f[MHz] \t Dfbyn[Hz] \t DD[10^-6]'
            DfDGbyn_Exp = np.append(DfDGbyn_Exp,[Cor.Dfcbyns_inc.imag/Cor.f_fund*2./1e-6],axis=0)
        np.savetxt(Cor.CurrWD+'/tmp/Experimental_Dfcbyn.qt2',np.transpose(DfDGbyn_Exp),header = header,delimiter='\t')    
    suptitletext = ''
    if len(Cor.InfoString) > 0: 
        suptitletext += Cor.InfoString
    if len(TT.DfDGbyns) > 1: 
        suptitletext += '  time: ' + str(np.round(TT.DfDGbyns[Cor.i_selec,Cor.i_col_x],1))
    if Cor.TT_IO_Format == 'from_QSoft_new': 
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:45] + ' chan ' + str(Cor.i_channel+1)
    else:  
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:55]
    suptitletext +=  '\n' + os.path.basename(Cor.filename)[:55]

    if Cor.DataContainNans == 'yes':
        suptitletext += '\n' + 'numerical overflow in simulation'
    fig.suptitle(suptitletext,fontsize = 8)

    fig.tight_layout(); fig.savefig(Cor.CurrWD+'/tmp/Single.png',dpi=mydpi)

def PlotDfDGbyns(cntr):
    global FitRange_Btn,Hide_1_Btn,Zoom_Btn,Avrg_Btn

    def Hide_1_TT():     Cor.ready_state = 'Hide_1_TT';     Root.config(cursor='hand2'); Hide_1_Btn['bg'] = 'lightgrey'
    def Hide_Range_TT(): Cor.ready_state = 'Hide_Range_TT'; Root.config(cursor='hand2'); Hide_Range_Btn['bg'] = 'lightgrey'
    def Zoom_TT():       Cor.ready_state = 'Zoom_TT';       Root.config(cursor='hand2'); Zoom_Btn['bg'] = 'lightgrey'
    def Avrg():          Cor.ready_state = 'Average';       Root.config(cursor='hand2'); Avrg_Btn['bg'] = 'lightgrey'
    def UnZoom_TT(): Cor.i_strt_zoom_TT = 0; Cor.i_stop_zoom_TT = len(TT.DfDGbyns); PlotDfDGbyns(PlotDfDGbynsFrame)
        
    def UnHide_TT():
        Cor.i_strt_hide_TT = 0
        Cor.i_stop_hide_TT = 0
        TT.DfDGbyns = np.loadtxt(Cor.CurrWD+'/tmp/Shifts_for_unhide.qt2',skiprows=1)
        PlotDfDGbyns(PlotDfDGbynsFrame)
        MakeTT_IOFrame(TT_IOFrame)
        Cor.Write_Config()
        
        
    def onclick_TT(event):
        if Cor.ready_state == 'Select' and event.xdata != None:
            Cor.i_selec = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x])))
            Cor.i_strt_avrg = 0
            Cor.i_stop_avrg = 0
            for iovt in range(Cor.novt):
                Cor.Dfbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt  ]
                Cor.DGbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt+1]
            Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns
            it = Cor.i_selec
            if not np.isnan(TT.TT_FPars[it,0]):
                Cor.ParsGood = 'yes'
                try: 
                    for iFPar in range(Cor.nFPars):
                        Cor.FittedVals[iFPar] = TT.TT_FPars[it,2+2*iFPar  ] 
                        Cor.StdErrs[iFPar]    = TT.TT_FPars[it,2+2*iFPar+1]
                    for iovt in range(Cor.novt):
                        Cor.Dfcbyns_fit_n_arr[iovt] = complex(TT.DfDGbyns[it,2+4*iovt+2], TT.DfDGbyns[it,2+4*iovt+3])
                    Cor.Calc_chi2(); TT.TT_FPars[it,-1] = Cor.chi2
                    Cor.Dfcbyns_fit = Cor.Calc_Dfcbyns_from_FitVals(Cor.FittedVals)
                    Cor.FitVals_to_SamplePars(Cor.FittedVals)
                    Cor.FitErrs_to_SampleErrs(Cor.StdErrs)
                except: 
                    if Cor.nFPars > 0: Fit()
                    else: Cor.ParsGood = 'no'
            else:  
                if Cor.nFPars > 0: Fit()
                else: Cor.ParsGood = 'no'

            MakeSampleParsFrame(SampleParsFrame)
            Cor.Write_Config()
            PlotSingle(PlotSingleFrame)
            PlotDfDGbyns(PlotDfDGbynsFrame)
            MakeDfcbynsFrame(DfcbynsFrame)

        if Cor.ready_state == 'FitRange': 
            Cor.i_strt_fit= int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x]))) 
            Cor.i_current = Cor.i_strt_fit
        if Cor.ready_state == 'Hide_Range_TT': 
            Cor.i_strt_hide_TT = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x]))) 
        if Cor.ready_state == 'Zoom_TT':       
            Cor.i_strt_zoom_TT = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x])))
        if Cor.ready_state == 'Average':       
            Cor.i_strt_avrg    = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x])))

        if Cor.ready_state == 'Hide_1_TT':
            Root.config(cursor='arrow'); Cor.ready_state = 'Select'; Cor.Write_Config()
            i_Hide_1 = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x])))
            TT.DfDGbyns[i_Hide_1,:] = np.nan
            TT.Make_headers()            
            np.savetxt(Cor.CurrWD+'/tmp/Shifts.qt2',TT.DfDGbyns,header=TT.header_DfDGbyns,delimiter='\t',newline='\n')
            PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)  
            MakeTT_IOFrame(TT_IOFrame)
            Hide_1_Btn['bg'] = 'SystemButtonFace'

    def onrelease_TT(event):
        try: 
            if Cor.ready_state == 'FitRange':
                Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
                Cor.i_stop_fit = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x])))
                if Cor.i_stop_fit < Cor.i_strt_fit: 
                    istop_fit_temp = Cor.i_stop_fit
                    Cor.i_stop_fit = Cor.i_strt_fit
                    Cor.i_strt_fit = istop_fit_temp
                    Cor.i_current  = Cor.i_strt_fit
                Cor.Write_Config()
                MakeTT_IOFrame(TT_IOFrame)
                PlotDfDGbyns(PlotDfDGbynsFrame)
                FitRange_Btn['bg'] = 'SystemButtonFace'
        
            if Cor.ready_state == 'Hide_Range_TT':
                Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
                Cor.i_stop_hide_TT = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x]))) 
                if Cor.i_strt_hide_TT >= Cor.i_stop_hide_TT:
                    strt_buffer = Cor.i_stop_hide_TT
                    Cor.i_stop_hide_TT = Cor.i_strt_hide_TT
                    Cor.i_strt_hide_TT = strt_buffer
                for it in range(Cor.i_strt_hide_TT,Cor.i_stop_hide_TT+1):
                    TT.DfDGbyns[it,0] = np.nan
                    for j in range(2,2+4*Cor.novt): TT.DfDGbyns[it,j] = np.nan
                TT.Make_headers()            
                np.savetxt(Cor.CurrWD+'/tmp/Shifts.qt2',TT.DfDGbyns,header=TT.header_DfDGbyns,delimiter='\t',newline='\n')
                if All_NaNs_in_Dfcs(): 
                    Cor.i_selec = 0
                    while All_NaNs_in_Dfcs() and Cor.i_selec < len(TT.DfDGbyns) - 1:
                        Cor.i_selec += 1
                for iovt in range(Cor.novt):
                    Cor.Dfbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt  ]
                    Cor.DGbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt+1]
                Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns 
                Cor.Write_Config()
                PlotSingle(PlotSingleFrame)
                PlotDfDGbyns(PlotDfDGbynsFrame)
                MakeDfcbynsFrame(DfcbynsFrame)
                MakeTT_IOFrame(TT_IOFrame)
                Hide_Range_Btn['bg'] = 'SystemButtonFace'
            if Cor.ready_state == 'Zoom_TT':
                Root.config(cursor='arrow'); Cor.ready_state = 'Select'
                Cor.i_stop_zoom_TT = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x]))) 
                if Cor.i_strt_zoom_TT >= Cor.i_stop_zoom_TT:
                    strt_buffer = Cor.i_stop_zoom_TT
                    Cor.i_stop_zoom_TT = Cor.i_strt_zoom_TT
                    Cor.i_strt_zoom_TT = strt_buffer
                Cor.Write_Config()
                PlotDfDGbyns(PlotDfDGbynsFrame)
                Zoom_Btn['bg'] = 'SystemButtonFace'
            if Cor.ready_state == 'Average':
                Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
                Cor.i_stop_avrg = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x]))) 
                if Cor.i_strt_avrg >= Cor.i_stop_avrg:
                    strt_buffer = Cor.i_stop_avrg
                    Cor.i_stop_avrg = Cor.i_strt_avrg
                    Cor.i_strt_avrg = strt_buffer
                for iovt in range(Cor.novt):
                    Cor.Dfbyns[iovt] = np.nanmean(TT.DfDGbyns[Cor.i_strt_avrg:Cor.i_stop_avrg,2+4*iovt  ])
                    Cor.DGbyns[iovt] = np.nanmean(TT.DfDGbyns[Cor.i_strt_avrg:Cor.i_stop_avrg,2+4*iovt+1])
                Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns 
                Cor.Write_Config()
                PlotSingle(PlotSingleFrame)
                MakeDfcbynsFrame(DfcbynsFrame)
                MakeTT_IOFrame(TT_IOFrame)
                Cor.i_strt_avrg = 0; Cor.i_stop_avrg = 0
                Avrg_Btn['bg'] = 'SystemButtonFace'
        except: 
            pass
            # print(Exception)
            # tk.messagebox.showinfo('','area exceeds range with data')


    Cor.i_strt_zoom_TT = np.min([Cor.i_strt_zoom_TT,len(TT.DfDGbyns)-1])
    Cor.i_stop_zoom_TT = np.min([Cor.i_stop_zoom_TT,len(TT.DfDGbyns)-1])
    Cor.Write_Config()
    if not np.isnan(TT.DfDGbyns[Cor.i_strt_zoom_TT,Cor.i_col_x]) and not np.isnan(TT.DfDGbyns[Cor.i_stop_zoom_TT,Cor.i_col_x]):
        itmin = np.nanargmin(TT.DfDGbyns[:,0])
        itmax = np.nanargmax(TT.DfDGbyns[:,0])
        tmin  = np.nanmax([TT.DfDGbyns[Cor.i_strt_zoom_TT,Cor.i_col_x],TT.DfDGbyns[itmin,Cor.i_col_x]])        
        tmax  = np.nanmin([TT.DfDGbyns[Cor.i_stop_zoom_TT,Cor.i_col_x],TT.DfDGbyns[itmax,Cor.i_col_x]])

    Check_for_NaNs_in_Dfcs()
    for widget in cntr.winfo_children(): widget.destroy()
    fig = Figure(figsize = (DfDGPlotWidth,DfDGPlotHeight),dpi=mydpi)
    axis = fig.add_subplot(211)
    if np.ndim(TT.DfDGbyns) == 1: TT.DfDGbyns = np.array([TT.DfDGbyns]) 
    for iovt in range(Cor.novt):
        if Cor.OvtInc[iovt] == 1:
            axis.plot(TT.DfDGbyns[:,Cor.i_col_x],TT.DfDGbyns[:,2+4*iovt  ],'.',color=Cor.Colors[iovt],label = Cor.Ovt_Labels[iovt],
                      markersize = 2.)
            axis.plot(TT.DfDGbyns[:,Cor.i_col_x],TT.DfDGbyns[:,2+4*iovt+2],'-',color=Cor.Colors[iovt])
            if not All_NaNs_in_array(TT.DfDGbyns[:,2+4*iovt]):
                if np.nanmax(TT.DfDGbyns[:,2+4*iovt]) > np.nanmin(TT.DfDGbyns[:,2+4*iovt]) and \
                   Cor.i_selec < len(TT.DfDGbyns) and Cor.i_strt_fit < len(TT.DfDGbyns) and Cor.i_stop_fit < len(TT.DfDGbyns) \
                       and Cor.i_current < len(TT.DfDGbyns): 
                    axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_selec,Cor.i_col_x],\
                              np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt]),np.nanmax(TT.DfDGbyns[:,2+4*iovt]),5),'-',color='lightsteelblue')
                    axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_strt_fit,Cor.i_col_x],\
                              np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt]),np.nanmax(TT.DfDGbyns[:,2+4*iovt]),5),'-',color='grey')
                    axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_stop_fit,Cor.i_col_x],\
                              np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt]),np.nanmax(TT.DfDGbyns[:,2+4*iovt]),5),'-',color='olive')
                    axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_current,Cor.i_col_x],\
                              np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt]),np.nanmax(TT.DfDGbyns[:,2+4*iovt]),5),'-',color='fuchsia')
            if not np.isnan(TT.DfDGbyns[Cor.i_strt_zoom_TT,Cor.i_col_x]) and not np.isnan(TT.DfDGbyns[Cor.i_stop_zoom_TT,Cor.i_col_x]):
                if tmax > tmin:
                    leftlim  = tmin - 0.05*(tmax-tmin)
                    rightlim = tmax + 0.05*(tmax-tmin)
                    axis.set_xlim(left = leftlim,right=rightlim)
    axis.set_ylabel('$\Delta f/n$ [Hz]',fontsize=9)
    axis.axes.xaxis.set_ticklabels([])
    axis.tick_params(direction='in',labelsize =8)
    if np.sum(Cor.OvtInc) > 0: axis.legend(fontsize=7)
    
    suptitletext = ''
    if len(Cor.InfoString) > 0: 
        suptitletext += Cor.InfoString
    if Cor.TT_IO_Format == 'from_QSoft_new': 
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:45] + ' chan ' + str(Cor.i_channel+1)
    else:  
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:55]
    suptitletext +=  '\n' + os.path.basename(Cor.filename)[:55]
        
    fig.suptitle(suptitletext,fontsize = 8)
  
    axis = fig.add_subplot(212)
    for iovt in range(Cor.novt):
        if Cor.OvtInc[iovt] == 1:
            if Cor.DD_DGbyn == 'DD':
                axis.plot(TT.DfDGbyns[:,Cor.i_col_x],TT.DfDGbyns[:,2+4*iovt+1]/Cor.f_fund*2./1e-6,'.',color=Cor.Colors[iovt],\
                          label = Cor.Ovt_Labels[iovt],markersize = 2.)
                axis.plot(TT.DfDGbyns[:,Cor.i_col_x],TT.DfDGbyns[:,2+4*iovt+3]/Cor.f_fund*2./1e-6,'-',color=Cor.Colors[iovt])
                if not All_NaNs_in_array(TT.DfDGbyns[:,2+4*iovt+1]):
                    if np.nanmax(TT.DfDGbyns[:,2+4*iovt]) > np.nanmin(TT.DfDGbyns[:,2+4*iovt]) and \
                       Cor.i_selec < len(TT.DfDGbyns) and Cor.i_strt_fit < len(TT.DfDGbyns) and Cor.i_stop_fit < len(TT.DfDGbyns): 
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_selec,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5)/Cor.f_fund*2./1e-6,'-',color='lightsteelblue')
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_strt_fit,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5)/Cor.f_fund*2./1e-6,'-',color='grey')
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_stop_fit,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5)/Cor.f_fund*2./1e-6,'-',color='olive')
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_current,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5)/Cor.f_fund*2./1e-6,'-',color='fuchsia')
            if Cor.DD_DGbyn == 'DGbyn':
                axis.plot(TT.DfDGbyns[:,Cor.i_col_x],TT.DfDGbyns[:,2+4*iovt+1],'.',color=Cor.Colors[iovt],\
                          label = Cor.Ovt_Labels[iovt],markersize = 2.)
                axis.plot(TT.DfDGbyns[:,Cor.i_col_x],TT.DfDGbyns[:,2+4*iovt+3],'-',color=Cor.Colors[iovt])
                if not All_NaNs_in_array(TT.DfDGbyns[:,2+4*iovt+1]):
                    if np.nanmax(TT.DfDGbyns[:,2+4*iovt]) > np.nanmin(TT.DfDGbyns[:,2+4*iovt]) and \
                       Cor.i_selec < len(TT.DfDGbyns) and Cor.i_strt_fit < len(TT.DfDGbyns) and Cor.i_stop_fit < len(TT.DfDGbyns): 
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_selec,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5),'-',color='lightsteelblue')
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_strt_fit,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5),'-',color='grey')
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_stop_fit,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5),'-',color='olive')
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_current,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5),'-',color='fuchsia')
            if not np.isnan(TT.DfDGbyns[Cor.i_strt_zoom_TT,Cor.i_col_x]) and not np.isnan(TT.DfDGbyns[Cor.i_stop_zoom_TT,Cor.i_col_x]):
                if tmax > tmin:
                    leftlim  = tmin - 0.05*(tmax-tmin)
                    rightlim = tmax + 0.05*(tmax-tmin)
                    axis.set_xlim(left = leftlim,right=rightlim)
    if Cor.vs_time_datapoint == 'time'     : axis.set_xlabel('time ' + Cor.TimeLabel,fontsize=9)
    if Cor.vs_time_datapoint == 'datapoint': axis.set_xlabel('number',fontsize=9)
    if Cor.DD_DGbyn == 'DD'   : axis.set_ylabel('\u0394D [10\u207B\u2076]',fontsize=9)
    if Cor.DD_DGbyn == 'DGbyn': axis.set_ylabel('$\Delta\Gamma/n$ [Hz]'   ,fontsize=9)
    axis.tick_params(direction='in',labelsize=8)
    fig.tight_layout(); fig.savefig(Cor.CurrWD+'/tmp/All_DfDGbyns.png',dpi=200)

    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); 
    canvas.get_tk_widget().grid(row=0,column=0,columnspan=7,sticky='NW')
    fig.canvas.mpl_connect('button_press_event'  ,onclick_TT)
    fig.canvas.mpl_connect('button_release_event',onrelease_TT)
    
    Hide_1_Btn = tk.Button(cntr,text ='Hide point',command=Hide_1_TT)
    Hide_1_Btn.grid(row=1,column=1,sticky='NS')
    # 'SystemButtonFace' = Hide_1_Btn.cget("background")
    Hide_Range_Btn = tk.Button(cntr,text ='Hide Range',command=Hide_Range_TT)
    Hide_Range_Btn.grid(row=1,column=2,sticky='NS')
    tk.Button(cntr,text ='Unhide',command=UnHide_TT).grid(row=1,column=3,sticky='NS')
    Avrg_Btn = tk.Button(cntr,text ='Average',command=Avrg)
    Avrg_Btn.grid(row=1,column=4,sticky='NS')
    Zoom_Btn = tk.Button(cntr,text ='Zoom',command=Zoom_TT)
    Zoom_Btn.grid(row=1,column=5,sticky='NS')
    UnZoom_Btn = tk.Button(cntr,text ='Unzoom',command=UnZoom_TT)
    UnZoom_Btn.grid(row=1,column=6,sticky='NS')


def PlotFPars(cntr):
    global FPs_Hide_1_Btn,FPs_Hide_Range_Btn,FPs_Zoom_Btn
    def Hide_1_FP():     Cor.ready_state = 'Hide_1_FP';     Root.config(cursor='hand2'); FPs_Hide_1_Btn['bg'] = 'lightgrey'
    def Hide_Range_FP(): Cor.ready_state = 'Hide_Range_FP'; Root.config(cursor='hand2'); FPs_Hide_Range_Btn['bg'] = 'lightgrey'
    def Zoom_FP():       Cor.ready_state = 'Zoom_FP';       Root.config(cursor='hand2'); FPs_Zoom_Btn['bg'] = 'lightgrey'
    def UnZoom_FP(): Cor.i_strt_zoom_FP = 0; Cor.i_stop_zoom_FP = len(TT.TT_FPars); PlotFPars(PlotFParsFrame)


    def Unhide_FP():
        Cor.i_strt_hide_FP = 0
        Cor.i_stop_hide_FP = 0
        data = np.loadtxt(Cor.CurrWD+'/tmp/FitPars_for_unhide.qt2    ',skiprows=1)
        if data.ndim == 1: data = np.array([data])
        for it in range(len(data)):
            for j in range(len(data[0])):
                try: TT.TT_FPars[it,j] = data[it,j]
                except: pass
        data = np.loadtxt(Cor.CurrWD+'/tmp/FitParsConv_for_unhide.qt2',skiprows=1)
        if data.ndim == 1: data = np.array([data])
        for it in range(len(data)):
            for j in range(len(data[0])):
                try: TT.TT_FParsConv[it,j] = data[it,j]
                except: pass
        PlotFPars(PlotFParsFrame)

    def onclick_FP(event):
        if Cor.ready_state == 'Hide_Range_FP': Cor.i_strt_hide_FP = int(np.nanargmin(np.abs(event.xdata-TT.TT_FPars[:,Cor.i_col_x]))) 
        if Cor.ready_state == 'Zoom_FP': Cor.i_strt_zoom_FP = int(np.nanargmin(np.abs(event.xdata-TT.TT_FPars[:,Cor.i_col_x]))) 
        if Cor.ready_state == 'Hide_1_FP':
            Root.config(cursor='arrow'); Cor.ready_state = 'Select'; Cor.Write_Config()
            i_Hide_1_FP = int(np.nanargmin(np.abs(event.xdata-TT.TT_FPars[:,Cor.i_col_x])))
            TT.TT_FPars[    i_Hide_1_FP,:] = np.nan
            TT.TT_FParsConv[i_Hide_1_FP,:] = np.nan
            np.savetxt(Cor.CurrWD+'/tmp/FitPars.qt2'    ,TT.TT_FPars    ,header=TT.header_FPars_TimeSer    ,delimiter='\t',newline='\n')
            np.savetxt(Cor.CurrWD+'/tmp/FitParsConv.qt2',TT.TT_FParsConv,header=TT.header_FParsConv_TimeSer,delimiter='\t',newline='\n')
            PlotFPars(PlotFParsFrame) 
            FPs_Hide_1_Btn['bg'] = 'SystemButtonFace'

    def onrelease_FP(event):
        
        try: 
            if Cor.ready_state == 'Hide_Range_FP':
                Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
                TT.Make_headers()            
                Cor.i_stop_hide_FP = int(np.nanargmin(np.abs(event.xdata-TT.TT_FPars[:,Cor.i_col_x]))) 
                if Cor.i_strt_hide_FP <= Cor.i_stop_hide_FP:   
                    for it in range(Cor.i_strt_hide_FP,Cor.i_stop_hide_FP+1):
                        for j in range(2,2+2*Cor.nFParsmax+1): 
                            TT.TT_FPars[    it,j] = np.nan
                        for j in range(2,2+5+1): 
                            TT.TT_FParsConv[it,j] = np.nan
                        TT.TT_FPars[    it,-1] = np.nan
                        TT.TT_FParsConv[it,-1] = np.nan
                if Cor.i_strt_hide_FP >= Cor.i_stop_hide_FP:    
                    for it in range(Cor.i_stop_hide_FP,Cor.i_strt_hide_FP+1):
                        for j in range(2,2+2*Cor.nFParsmax+1): 
                            TT.TT_FPars[    it,j] = np.nan
                        for j in range(2,2+5+1): 
                            TT.TT_FParsConv[it,j] = np.nan
                        TT.TT_FPars[    it,-1] = np.nan
                        TT.TT_FParsConv[it,-1] = np.nan
                np.savetxt(Cor.CurrWD+'/tmp/FitPars.qt2'    ,TT.TT_FPars,    header=TT.header_FPars_TimeSer    ,delimiter='\t',newline='\n')
                np.savetxt(Cor.CurrWD+'/tmp/FitParsConv.qt2',TT.TT_FParsConv,header=TT.header_FParsConv_TimeSer,delimiter='\t',newline='\n')
                PlotFPars(PlotFParsFrame) 
                FPs_Hide_Range_Btn['bg'] = 'SystemButtonFace'
            
            if Cor.ready_state == 'Zoom_FP':
                Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
                Cor.i_stop_zoom_FP = int(np.nanargmin(np.abs(event.xdata-TT.TT_FPars[:,Cor.i_col_x]))) 
                if Cor.i_strt_zoom_FP >= Cor.i_stop_zoom_FP:
                    strt_buffer = Cor.i_stop_zoom_FP
                    Cor.i_stop_zoom_FP = Cor.i_strt_zoom_FP
                    Cor.i_strt_zoom_FP = strt_buffer
                PlotFPars(PlotFParsFrame) 
                FPs_Zoom_Btn['bg'] = 'SystemButtonFace'
        except: 
            pass
            # tk.messagebox.showinfo('','area exceeds range with data')
    
    SingleLayer,i_layer = Cor.Determine_Layers_IncInFits()
    IncParsConv,sumIncParsConv = TT.Calc_IncParsConv()
    Cor.i_strt_zoom_FP = np.min([Cor.i_strt_zoom_FP,len(TT.TT_FPars)-1])
    Cor.i_stop_zoom_FP = np.min([Cor.i_stop_zoom_FP,len(TT.TT_FPars)-1])
    Cor.Write_Config()
    if Cor.Do_Conv == 'no': 
        TT_FParsPlot = np.ones((len(TT.TT_FPars),len(TT.TT_FPars[0])))*np.nan
        for it in range(len(TT.TT_FPars)):
            TT_FParsPlot[it] = TT.TT_FPars[it]
    if Cor.Do_Conv == 'yes': 
        TT_FParsPlot = np.ones((len(TT.TT_FPars),2+5+1))*np.nan
        for it in range(len(TT.TT_FPars)):
            TT_FParsPlot[it] = TT.TT_FParsConv[it]
    if not np.isnan(TT_FParsPlot[Cor.i_strt_zoom_FP,Cor.i_col_x]) and \
       not np.isnan(TT_FParsPlot[Cor.i_stop_zoom_FP,Cor.i_col_x]):
        itmin = np.nanargmin(TT_FParsPlot[:,0])
        itmax = np.nanargmax(TT_FParsPlot[:,0])
        tmin  = np.nanmax([TT_FParsPlot[Cor.i_strt_zoom_FP,Cor.i_col_x],TT_FParsPlot[itmin,Cor.i_col_x]])        
        tmax  = np.nanmin([TT_FParsPlot[Cor.i_stop_zoom_FP,Cor.i_col_x],TT_FParsPlot[itmax,Cor.i_col_x]])
    TT.Get_Labels_TT_header()
    TT.Get_Labels_TTConv_header()
    for widget in cntr.winfo_children(): widget.destroy()
    fig = Figure(figsize = (FParPlotWidth,FParPlotHeight),dpi=mydpi)
    if Cor.Do_Conv == 'no'  : nPlots = Cor.nFPars + 1
    if Cor.Do_Conv == 'yes' : nPlots = sumIncParsConv + 1
    iFPar = 0  
    for key in Cor.keys:
        if (Cor.Do_Conv == 'no'  and Cor.IncPars[key] == 1) or \
           (Cor.Do_Conv == 'yes' and IncParsConv[key] == 1):
            axis = fig.add_subplot(nPlots,1,1+iFPar)
            if Cor.Do_Conv == 'no'  :
                StdErrs = np.ones(len(TT_FParsPlot))*np.nan
                for i in range(0,len(StdErrs),Cor.Update_Inval): StdErrs[i] = TT_FParsPlot[i,2+2*iFPar+1]
                if Cor.i_PlotErrBars == 1:
                    axis.errorbar(TT_FParsPlot[:,Cor.i_col_x],TT_FParsPlot[:,2+2*iFPar],StdErrs,color='r')
                else:
                    axis.plot(    TT_FParsPlot[:,Cor.i_col_x],TT_FParsPlot[:,2+2*iFPar],color='r')
            if Cor.Do_Conv == 'yes'  :
                axis.plot(TT_FParsPlot[:,Cor.i_col_x],TT_FParsPlot[:,2+iFPar],color='r')
            if not np.isnan(TT_FParsPlot[Cor.i_strt_zoom_FP,Cor.i_col_x]) and \
               not np.isnan(TT_FParsPlot[Cor.i_stop_zoom_FP,Cor.i_col_x]):
                if tmax > tmin:
                    leftlim  = tmin - 0.05*(tmax-tmin)
                    rightlim = tmax + 0.05*(tmax-tmin)
                    axis.set_xlim(left = leftlim,right=rightlim)
            axis.tick_params(labelsize=7,direction='in')
            axis.axes.xaxis.set_ticklabels([])
            if Cor.Do_Conv == 'no'  : 
                axis.set_ylabel(TT.Graph_TT_Labels[key],fontsize=9)
            if Cor.Do_Conv == 'yes' : 
                axis.set_ylabel(TT.Graph_TTConv_Labels[key],fontsize=9)
            iFPar += 1
    axis = fig.add_subplot(nPlots,1,1+iFPar)
    axis.plot(TT_FParsPlot[:,Cor.i_col_x],TT_FParsPlot[:,-1],'x-',color='r')
    if not np.isnan(TT_FParsPlot[Cor.i_strt_zoom_FP,Cor.i_col_x]) and \
       not np.isnan(TT_FParsPlot[Cor.i_stop_zoom_FP,Cor.i_col_x]):
        if tmax > tmin:
            leftlim  = tmin - 0.05*(tmax-tmin)
            rightlim = tmax + 0.05*(tmax-tmin)
            axis.set_xlim(left = leftlim,right=rightlim)

    axis.tick_params(labelsize=7,direction='in')
    if Cor.vs_time_datapoint == 'time'     : axis.set_xlabel('time ' + Cor.TimeLabel,fontsize=9)
    if Cor.vs_time_datapoint == 'datapoint': axis.set_xlabel('number',fontsize=9)
    axis.set_ylabel('$\chi^{2}$' ,fontsize=9)
    
    suptitletext = ''
    if len(Cor.InfoString) > 0: suptitletext += Cor.InfoString
    if Cor.TT_IO_Format == 'from_QSoft_new': 
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:45] + ' chan ' + str(Cor.i_channel+1)
    else:  
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:55]
    suptitletext +=  '\n' + os.path.basename(Cor.filename)[:55]
    if Cor.Do_Conv == 'yes' : suptitletext +=  '\n' + 'Converted'
    fig.suptitle(suptitletext,fontsize = 8)
    
    fig.tight_layout(); fig.savefig(Cor.CurrWD+'/tmp/All_FPars.png',dpi=200)

    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); 
    canvas.get_tk_widget().grid(row=0,column=0,columnspan=6,sticky='NW')
    fig.canvas.mpl_connect('button_press_event'  ,onclick_FP)
    fig.canvas.mpl_connect('button_release_event',onrelease_FP)

    
    FPs_Hide_1_Btn = tk.Button(cntr,text ='Hide Point',command=Hide_1_FP)
    FPs_Hide_1_Btn.grid(row=1,column=0,sticky='NS')
    # 'SystemButtonFace' = FPs_Hide_1_Btn.cget('background')
    # print(''SystemButtonFace'','SystemButtonFace')
    FPs_Hide_Range_Btn = tk.Button(cntr,text ='Hide Range',command=Hide_Range_FP)
    FPs_Hide_Range_Btn.grid(row=1,column=1, sticky='NS')
    tk.Button(cntr,text='Unhide',command=Unhide_FP).grid(row=1,column=2,sticky='NS')

    FPs_Zoom_Btn = tk.Button(cntr,text ='Zoom',command=Zoom_FP)
    FPs_Zoom_Btn.grid(row=1,column=3, sticky='NS')
    FPs_UnZoom_Btn = tk.Button(cntr,text ='Unzoom',command=UnZoom_FP)
    FPs_UnZoom_Btn.grid(row=1,column=4,sticky='NS')


def openLimits(): Limits.Limits_Start()
def openchi2_Landscape(): chi2_Landscape.chi2_Landscape_Start()
def openBootstrap(): Bootstrap.Bootstrap_Start()
def openRndNoise(): RndNoise.RndNoise_Start()
def openFuzzyInterface(): 
    if Cor.nFPars == 0: 
        tk.messagebox.showinfo('','no active fit parameters'); return
    FuzzyInterface.FuzzyInterface_Start()

def AboutMessage(): 
    tk.messagebox.showinfo('','PyQTM was written by Diethelm Johannsmann, Philipp Sievers, Ilya Reviakine and Judith Petri' + \
        '\n' + 'https://www.pc.tu-clausthal.de \n' + 'Feedback is appreciated')

def Update_Previous_Filenames():
    Root.title('PyQTM:    ' + os.path.basename(Cor.filename) + '   /   ' + os.path.basename(Cor.TT_filename))
    for j in range(Cor.n_previous-1,0,-1):Cor.Previous_Filenames[j] = Cor.Previous_Filenames[j-1]
    Cor.Previous_Filenames[0] = Cor.folder + '/' + Cor.filename
    Cor.Write_QTM_cfg(); Make_Menu()
    
def MakeSampleParsFrame(cntr):
    global VEPar_Choices
    for widget in cntr.winfo_children(): widget.destroy()
    f_fund_SV      = tk.StringVar(cntr,np.round(Cor.f_fund/1e6,2))
    Zq_SV          = tk.StringVar(cntr,np.round(Cor.Zq    /1e6,2))
    f_cen_SV       = tk.StringVar(cntr,np.round(Cor.f_cen /1e6,2))
    if Cor.ParsGood == 'yes': fg = 'black'
    else                    : fg = 'grey'
    
    VEPar_Choices = ['J\',J\'\'','G\',G\'\'','\u03B7\',\u03B7\'\'','G\',\u03B7\'',\
                     '|J|,tan(\u03B4)','|G|,tan(\u03B4)','|\u03B7|,tan(\u03B4)\u207B\u00B9']
    if Cor.Show_lay1 == 'yes': i_Show_lay1_IV = tk.IntVar(cntr,1)
    if Cor.Show_lay1 == 'no' : i_Show_lay1_IV = tk.IntVar(cntr,0)
    if Cor.Show_lay2 == 'yes': i_Show_lay2_IV = tk.IntVar(cntr,1)
    if Cor.Show_lay2 == 'no' : i_Show_lay2_IV = tk.IntVar(cntr,0)
    if Cor.Show_bulk == 'yes': i_Show_bulk_IV = tk.IntVar(cntr,1)
    if Cor.Show_bulk == 'no' : i_Show_bulk_IV = tk.IntVar(cntr,0)

    def Enter_Stuff_Pars(event,key):
        for key in Cor.keys:
            if key != 'VEtype_lay1' and key != 'VEtype_lay2' and key != 'VEtype_lay3': 
                string = SamplePars_SVs[key].get(); string.strip()
                if '\u00b1' in string: 
                    index = string.find('\u00b1'); string = string[:index]
                try: Cor.SamplePars[key] = np.float64(string)
                except: print(key,string)
        Cor.Adjust_Pars_to_Limits()
        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes'; Cor.Write_Config()
        MakeSampleParsFrame(SampleParsFrame)
        PlotSingle(PlotSingleFrame)
    
    def incdec(val,pm):
        if pm=='+':
            if val>0: val*=1.5
            if abs(val) <= 1e-7: val+=1.
            if val<0: val/=1.5
        elif pm=='-':
            if val>0: val/=1.5
            if abs(val) <= 1e-7: val-=1.
            if val<0: val*=1.5
        else: 
            try: val = np.float64(pm)
            except: pass
        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes'; Cor.Write_Config()
        return val  

    def SamplePars_to_Clpbd_old():
        c_names=['Parameter','Value','StandardError']
        Parsdf = pd.DataFrame({},columns = c_names)
        for ikey,key in enumerate(Cor.keys):
            if not 'VEtype_' in key :
                if ('_lay1' in key and Cor.Show_lay1 == 'yes') or \
                   ('_lay2' in key and Cor.Show_lay2 == 'yes') or \
                   ('_lay3' in key and Cor.Show_bulk == 'yes') or \
                   ('VertScaleR' in key and Cor.SamplePars['VertScaleR'] > 0) or \
                   ('AspRat' in key and Cor.SamplePars['VertScaleR'] > 0):
                        Parsdf.at[ikey,'Parameter']  = TT.header_Labels[key]
                        Parsdf.at[ikey,'Value'] = Cor.SamplePars[key]
                        if Cor.IncPars[key] == 1 and Cor.ParsGood == 'yes':
                            Parsdf.at[ikey,'StandardError'] = Cor.SampleStdErrs[key]
        Parsdf.to_clipboard(excel=True,sep=None,index=False,\
                            header='Parameter \t Value \t StandardError')

    def SamplePars_to_Clpbd():
            c_names=['Parameter','Value','StandardError']
            Parsdf = pd.DataFrame({},columns = c_names)
            for ikey,key in enumerate(Cor.keys):
                if not 'VEtype_' in key :
                    if ('_lay1' in key and Cor.Show_lay1 == 'yes'):
                            Parsdf.at[ikey,'Parameter']  = TT.header_Labels[key]
                            Parsdf.at[ikey,'Value'] = Cor.SamplePars[key]
                            if Cor.IncPars[key] == 1 and Cor.ParsGood == 'yes':
                                Parsdf.at[ikey,'StandardError'] = Cor.SampleStdErrs[key]
            for ikey,key in enumerate(Cor.keys):
                if not 'VEtype_' in key :
                    if ('_lay2' in key and Cor.Show_lay2 == 'yes'):
                        Parsdf.at[ikey,'Parameter']  = TT.header_Labels[key]
                        Parsdf.at[ikey,'Value'] = Cor.SamplePars[key]
                        if Cor.IncPars[key] == 1 and Cor.ParsGood == 'yes':
                            Parsdf.at[ikey,'StandardError'] = Cor.SampleStdErrs[key]
            for ikey,key in enumerate(Cor.keys):
                if not 'VEtype_' in key :
                    if ('_lay3' in key and Cor.Show_bulk == 'yes'):
                        Parsdf.at[ikey,'Parameter']  = TT.header_Labels[key]
                        Parsdf.at[ikey,'Value'] = Cor.SamplePars[key]
                        if Cor.IncPars[key] == 1 and Cor.ParsGood == 'yes':
                            Parsdf.at[ikey,'StandardError'] = Cor.SampleStdErrs[key]
            for ikey,key in enumerate(Cor.keys):
                if not 'VEtype_' in key :
                    if ('VertScaleR' in key and Cor.SamplePars['VertScaleR'] > 0) or \
                        ('AspRat' in key and Cor.SamplePars['VertScaleR'] > 0):
                        Parsdf.at[ikey,'Parameter']  = TT.header_Labels[key]
                        Parsdf.at[ikey,'Value'] = Cor.SamplePars[key]
                        if Cor.IncPars[key] == 1 and Cor.ParsGood == 'yes':
                            Parsdf.at[ikey,'StandardError'] = Cor.SampleStdErrs[key]
            Parsdf.to_clipboard(excel=True,sep=None,index=False,\
                                header='Parameter \t Value \t StandardError')

    def Make_Reference():
        for key in Cor.keys: Cor.RefPars[key] = Cor.SamplePars[key]
        Cor.Write_Config() 
        Update_User_Interface() 
        PlotSingle(PlotSingleFrame)
        OpenRef()
         
    def incdec_t_lay1(): 
        Cor.SamplePars['t_lay1'] = incdec(Cor.SamplePars['t_lay1'],SamplePars_SVs['t_lay1'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); MakeFitFrame(FitFrame); PlotSingle(PlotSingleFrame)
    def incdec_rho_lay1(): 
        Cor.SamplePars['rho_lay1'] = incdec(Cor.SamplePars['rho_lay1'],SamplePars_SVs['rho_lay1'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar1_lay1(): 
        Cor.SamplePars['VEPar1_lay1'] = incdec(Cor.SamplePars['VEPar1_lay1'],SamplePars_SVs['VEPar1_lay1'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame) 
    def incdec_VEPar2_lay1(): 
        Cor.SamplePars['VEPar2_lay1'] = incdec(Cor.SamplePars['VEPar2_lay1'],SamplePars_SVs['VEPar2_lay1'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar1_PLexpt_lay1(): 
        Cor.SamplePars['VEPar1_PLexpt_lay1'] = incdec(Cor.SamplePars['VEPar1_PLexpt_lay1'],SamplePars_SVs['VEPar1_PLexpt_lay1'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar2_PLexpt_lay1(): 
        Cor.SamplePars['VEPar2_PLexpt_lay1'] = incdec(Cor.SamplePars['VEPar2_PLexpt_lay1'],SamplePars_SVs['VEPar2_PLexpt_lay1'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_t_lay2(): 
        Cor.SamplePars['t_lay2'] = incdec(Cor.SamplePars['t_lay2'],SamplePars_SVs['t_lay2'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); MakeFitFrame(FitFrame); PlotSingle(PlotSingleFrame)
    def incdec_rho_lay2(): 
        Cor.SamplePars['rho_lay2'] = incdec(Cor.SamplePars['rho_lay2'],SamplePars_SVs['rho_lay2'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar1_lay2(): 
        Cor.SamplePars['VEPar1_lay2'] = incdec(Cor.SamplePars['VEPar1_lay2'],SamplePars_SVs['VEPar1_lay2'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar2_lay2(): 
        Cor.SamplePars['VEPar2_lay2'] = incdec(Cor.SamplePars['VEPar2_lay2'],SamplePars_SVs['VEPar2_lay2'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar1_PLexpt_lay2(): 
        Cor.SamplePars['VEPar1_PLexpt_lay2'] = incdec(Cor.SamplePars['VEPar1_PLexpt_lay2'],SamplePars_SVs['VEPar1_PLexpt_lay2'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar2_PLexpt_lay2(): 
        Cor.SamplePars['VEPar2_PLexpt_lay2'] = incdec(Cor.SamplePars['VEPar2_PLexpt_lay2'],SamplePars_SVs['VEPar2_PLexpt_lay2'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_rho_lay3(): 
        Cor.SamplePars['rho_lay3'] = incdec(Cor.SamplePars['rho_lay3'],SamplePars_SVs['rho_lay3'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar1_lay3(): 
        Cor.SamplePars['VEPar1_lay3'] = incdec(Cor.SamplePars['VEPar1_lay3'],SamplePars_SVs['VEPar1_lay3'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar2_lay3(): 
        Cor.SamplePars['VEPar2_lay3'] = incdec(Cor.SamplePars['VEPar2_lay3'],SamplePars_SVs['VEPar2_lay3'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar1_PLexpt_lay3(): 
        Cor.SamplePars['VEPar1_PLexpt_lay3'] = incdec(Cor.SamplePars['VEPar1_PLexpt_lay3'],SamplePars_SVs['VEPar1_PLexpt_lay3'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar2_PLexpt_lay3(): 
        Cor.SamplePars['VEPar2_PLexpt_lay3'] = incdec(Cor.SamplePars['VEPar2_PLexpt_lay3'],SamplePars_SVs['VEPar2_PLexpt_lay3'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VertScaleR(): 
        Cor.SamplePars['VertScaleR'] = incdec(Cor.SamplePars['VertScaleR'],SamplePars_SVs['VertScaleR'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_AspRat(): 
        Cor.SamplePars['AspRat'] = incdec(Cor.SamplePars['AspRat'],SamplePars_SVs['AspRat'].get())
        Cor.Adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)

    def enter_VEPar_lay1(event): 
        VEPar = event.widget.get()
        VEtype_old = Cor.SamplePars['VEtype_lay1']
        for i,VEPar_Choice in enumerate(VEPar_Choices):
            if VEPar == VEPar_Choice: 
                Cor.SamplePars['VEtype_lay1'] = i
                VEtype_new = Cor.SamplePars['VEtype_lay1']
                VEPar1_old = Cor.SamplePars['VEPar1_lay1']
                VEPar2_old = Cor.SamplePars['VEPar2_lay1']
                VEPar1_PLexpt_old = Cor.SamplePars['VEPar1_PLexpt_lay1']
                VEPar2_PLexpt_old = Cor.SamplePars['VEPar2_PLexpt_lay1']
                Cor.SamplePars['VEPar1_lay1'],Cor.SamplePars['VEPar2_lay1'],Cor.SamplePars['VEPar1_PLexpt_lay1'],\
                    Cor.SamplePars['VEPar2_PLexpt_lay1'] = \
                    Cor.VEPars_Old2New(VEPar1_old,VEPar2_old,VEPar1_PLexpt_old,VEPar2_PLexpt_old,VEtype_old,VEtype_new)
        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config() 
        PlotSingle(PlotSingleFrame)
        Limits.Set_Defaults()
        MakeSampleParsFrame(cntr)

    def enter_VEPar_lay2(event):    
        VEPar = event.widget.get()
        VEtype_old = Cor.SamplePars['VEtype_lay2']
        for i,VEPar_Choice in enumerate(VEPar_Choices):
            if VEPar == VEPar_Choice: 
                Cor.SamplePars['VEtype_lay2'] = i
                VEtype_new = Cor.SamplePars['VEtype_lay2']
                VEPar1_old = Cor.SamplePars['VEPar1_lay2']
                VEPar2_old = Cor.SamplePars['VEPar2_lay2']
                VEPar1_PLexpt_old = Cor.SamplePars['VEPar1_PLexpt_lay2']
                VEPar2_PLexpt_old = Cor.SamplePars['VEPar2_PLexpt_lay2']
                Cor.SamplePars['VEPar1_lay2'],Cor.SamplePars['VEPar2_lay2'],Cor.SamplePars['VEPar1_PLexpt_lay2'],\
                    Cor.SamplePars['VEPar2_PLexpt_lay2'] = \
                    Cor.VEPars_Old2New(VEPar1_old,VEPar2_old,VEPar1_PLexpt_old,VEPar2_PLexpt_old,VEtype_old,VEtype_new)
        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        PlotSingle(PlotSingleFrame) 
        Limits.Set_Defaults()
        MakeSampleParsFrame(cntr)        

    def enter_VEPar_lay3(event): 
        VEPar = event.widget.get()
        VEtype_old = Cor.SamplePars['VEtype_lay3']
        for i,VEPar_Choice in enumerate(VEPar_Choices):
            if VEPar == VEPar_Choice: 
                Cor.SamplePars['VEtype_lay3'] = i
                VEtype_new = Cor.SamplePars['VEtype_lay3']
                VEPar1_old = Cor.SamplePars['VEPar1_lay3']
                VEPar2_old = Cor.SamplePars['VEPar2_lay3']
                VEPar1_PLexpt_old = Cor.SamplePars['VEPar1_PLexpt_lay3']
                VEPar2_PLexpt_old = Cor.SamplePars['VEPar2_PLexpt_lay3']
                Cor.SamplePars['VEPar1_lay3'],Cor.SamplePars['VEPar2_lay3'],Cor.SamplePars['VEPar1_PLexpt_lay3'],\
                    Cor.SamplePars['VEPar2_PLexpt_lay3'] = \
                    Cor.VEPars_Old2New(VEPar1_old,VEPar2_old,VEPar1_PLexpt_old,VEPar2_PLexpt_old,VEtype_old,VEtype_new)
        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        PlotSingle(PlotSingleFrame) 
        Limits.Set_Defaults()
        MakeSampleParsFrame(cntr)        

    def Enter_fundamental(event,iovt,WhichStuffStr,key):
        if WhichStuffStr == 'f_fund': 
            string = f_fund_SV.get(); string.strip()
            try: Cor.f_fund = np.float64(string)*1e6
            except: pass    
        if WhichStuffStr == 'Zq': 
            string = Zq_SV.get(); string.strip()
            try: Cor.Zq = np.float64(string)*1e6
            except: pass    
        if WhichStuffStr == 'f_cen': 
            string = f_cen_SV.get(); string.strip()
            try: Cor.f_cen = np.float64(string)*1e6
            except: pass
        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes'; Cor.Write_Config() 
        MakeSampleParsFrame(cntr)

    def Check_lay1(): 
        if int(i_Show_lay1_IV.get()) == 1: Cor.Show_lay1 = 'yes'
        if int(i_Show_lay1_IV.get()) == 0: Cor.Show_lay1 = 'no'
        Cor.Check_Show_IncInFit()
        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes'; Cor.Write_Config() 
        MakeSampleParsFrame(cntr)
        
    def Check_lay2(): 
        if int(i_Show_lay2_IV.get()) == 1: Cor.Show_lay2 = 'yes'
        if int(i_Show_lay2_IV.get()) == 0: Cor.Show_lay2 = 'no'
        Cor.Check_Show_IncInFit()
        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes'; Cor.Write_Config() 
        MakeSampleParsFrame(cntr)
        
    def Check_bulk(): 
        if int(i_Show_bulk_IV.get()) == 1: Cor.Show_bulk = 'yes'
        if int(i_Show_bulk_IV.get()) == 0: Cor.Show_bulk = 'no'
        Cor.Check_Show_IncInFit()
        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes'; Cor.Write_Config() 
        MakeSampleParsFrame(cntr)
        
    def Check_t_lay1():
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['t_lay1'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['t_lay1'].set(0) 
        else: Cor.IncPars['t_lay1']=int(IncPars_IVs['t_lay1'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes'; Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VEPar1_lay1():      
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar1_lay1'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar1_lay1'].set(0) 
        else: Cor.IncPars['VEPar1_lay1']      = int(IncPars_IVs['VEPar1_lay1'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VEPar2_lay1():     
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar2_lay1'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar2_lay1'].set(0) 
        else: Cor.IncPars['VEPar2_lay1']     = int(IncPars_IVs['VEPar2_lay1'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VEPar1_PLexpt_lay1():  
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar1_PLexpt_lay1'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar1_PLexpt_lay1'].set(0) 
        else: Cor.IncPars['VEPar1_PLexpt_lay1']  = int(IncPars_IVs['VEPar1_PLexpt_lay1'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VEPar2_PLexpt_lay1(): 
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar2_PLexpt_lay1'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar2_PLexpt_lay1'].set(0) 
        else: Cor.IncPars['VEPar2_PLexpt_lay1'] = int(IncPars_IVs['VEPar2_PLexpt_lay1'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_t_lay2():       
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['t_lay2'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['t_lay2'].set(0) 
        else: Cor.IncPars['t_lay2'] = int(IncPars_IVs['t_lay2'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VEPar1_lay2():      
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar1_lay2'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar1_lay2'].set(0) 
        else: Cor.IncPars['VEPar1_lay2'] = int(IncPars_IVs['VEPar1_lay2'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VEPar2_lay2():     
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar2_lay2'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar2_lay2'].set(0) 
        else: Cor.IncPars['VEPar2_lay2'] = int(IncPars_IVs['VEPar2_lay2'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VEPar1_PLexpt_lay2():  
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar1_PLexpt_lay2'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar1_PLexpt_lay2'].set(0) 
        else: Cor.IncPars['VEPar1_PLexpt_lay2']  = int(IncPars_IVs['VEPar1_PLexpt_lay2'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VEPar2_PLexpt_lay2(): 
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar2_PLexpt_lay2'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar2_PLexpt_lay2'].set(0) 
        else: Cor.IncPars['VEPar2_PLexpt_lay2'] = int(IncPars_IVs['VEPar2_PLexpt_lay2'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VEPar1_lay3():      
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar1_lay3'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar1_lay3'].set(0) 
        else: Cor.IncPars['VEPar1_lay3']      = int(IncPars_IVs['VEPar1_lay3'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VEPar2_lay3():     
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar2_lay3'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar2_lay3'].set(0) 
        else: Cor.IncPars['VEPar2_lay3']     = int(IncPars_IVs['VEPar2_lay3'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VEPar1_PLexpt_lay3():  
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar1_PLexpt_lay3'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar1_PLexpt_lay3'].set(0) 
        else: Cor.IncPars['VEPar1_PLexpt_lay3']  = int(IncPars_IVs['VEPar1_PLexpt_lay3'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VEPar2_PLexpt_lay3(): 
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar2_PLexpt_lay3'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar2_PLexpt_lay3'].set(0) 
        else: Cor.IncPars['VEPar2_PLexpt_lay3'] = int(IncPars_IVs['VEPar2_PLexpt_lay3'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars(); MakeConvertFrame(ConvertFrame)
    def Check_VertScaleR():      
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VertScaleR'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VertScaleR'].set(0) 
        else: Cor.IncPars['VertScaleR'] = int(IncPars_IVs['VertScaleR'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars()
    def Check_AspRat():    
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['AspRat'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['AspRat'].set(0) 
        else: Cor.IncPars['AspRat']    = int(IncPars_IVs['AspRat'].get()); Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        Calc_nFPars()
        
    SamplePars_SVs_List = []; IncPars_IVs_List = [] 
    
    for key in Cor.keys:
        if not key in ['VEtype_lay1','VEtype_lay2','VEtype_lay3']:
            if not np.isnan(Cor.SampleStdErrs[key]) and Cor.ParsGood == 'yes' and Cor.IncPars[key] == 1:
                SamplePars_SVs_List.append(tk.StringVar(cntr,str(np.round(Cor.SamplePars[key],3))+ '\u00b1' + \
                          str(np.round(Cor.SampleStdErrs[key],5))))
            if np.isnan(Cor.SampleStdErrs[key]) or Cor.ParsGood == 'no' or Cor.IncPars[key] == 0:
                SamplePars_SVs_List.append(tk.StringVar(cntr,np.round(Cor.SamplePars[key],3)))
        else:  SamplePars_SVs_List.append(tk.StringVar(cntr,Cor.SamplePars[key]))       
        IncPars_IVs_List.append(           tk.IntVar(   cntr,Cor.IncPars[key]))
    SamplePars_SVs = dict(zip(Cor.keys,SamplePars_SVs_List))
    IncPars_IVs    = dict(zip(Cor.keys,IncPars_IVs_List))

    tk.Label(cntr,width=11,text='f\u2080 [MHz]'             ,anchor='e').grid(row=0 ,column=5,columnspan=2,sticky='E')
    tk.Label(cntr,width=13,text='Z_q [10\u2076 kg/m\u00B2s]',anchor='e').grid(row=0,column=8,columnspan=2,sticky='E')
    tk.Label(cntr,width=11,text='f_cen [MHz]'               ,anchor='e',fg='blue').grid(row=0,column=11,columnspan=2,sticky='E')
    f_fund_Entry = tk.Entry(cntr,width=5,textvariable=f_fund_SV      )
    f_fund_Entry.grid(row=0,column=7,sticky='W')
    f_fund_Entry.bind('<Return>',lambda event: Enter_fundamental(event,0,'f_fund',''))
    Zq_Entry = tk.Entry(cntr,width=5,textvariable=Zq_SV                   )
    Zq_Entry.grid(row=0,column=10,sticky='W')
    Zq_Entry.bind('<Return>',lambda event: Enter_fundamental(event,0,'Zq',''))
    f_cen_Entry = tk.Entry(cntr,width=5,textvariable=f_cen_SV)
    f_cen_Entry.grid(row=0,column=13,sticky='W')
    f_cen_Entry.bind('<Return>',lambda event: Enter_fundamental(event,0,'f_cen',''))
    
    f_width=12
    if Cor.Show_lay1 == 'yes':
        tk.Label(cntr,text='Thickness [nm]'      ,width=f_width                   ).grid(row=1,column=1)
        tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]',width=f_width-3                 ).grid(row=1,column=3)
        tk.Label(cntr,text=Cor.VE_Labels1[Cor.SamplePars['VEtype_lay1']],width=f_width).grid(row=1,column=4)
        tk.Label(cntr,text=Cor.VE_Labels2[Cor.SamplePars['VEtype_lay1']],width=f_width).grid(row=1,column=8)
        tk.Label(cntr,text=u'\u03B2\''           ,width=f_width                   ).grid(row=1,column=6)
        tk.Label(cntr,text=u'\u03B2\'\''         ,width=f_width-3                 ).grid(row=1,column=10)
        tk.Label(cntr,text='Viscoelastic Par''s' ,width=f_width+1                 ).grid(row=1,column=12)

    if Cor.Show_lay2 == 'yes':
        tk.Label(cntr,text='Thickness [nm]'      ,width=f_width                   ).grid(row=3,column=1)
        tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]',width=f_width-3                 ).grid(row=3,column=3)
        tk.Label(cntr,text=Cor.VE_Labels1[Cor.SamplePars['VEtype_lay2']],width=f_width).grid(row=3,column=4)
        tk.Label(cntr,text=Cor.VE_Labels2[Cor.SamplePars['VEtype_lay2']],width=f_width).grid(row=3,column=8)
        tk.Label(cntr,text=u'\u03B2\''           ,width=f_width                   ).grid(row=3,column=6)
        tk.Label(cntr,text=u'\u03B2\'\''         ,width=f_width-3                 ).grid(row=3,column=10)
        tk.Label(cntr,text='Viscoelastic Par''s' ,width=f_width+1                 ).grid(row=3,column=12)

    if Cor.Show_bulk == 'yes':
        tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]',width=f_width-3                 ).grid(row=5,column=3)
        tk.Label(cntr,text=Cor.VE_Labels1[Cor.SamplePars['VEtype_lay3']],width=f_width).grid(row=5,column=4)
        tk.Label(cntr,text=Cor.VE_Labels2[Cor.SamplePars['VEtype_lay3']],width=f_width).grid(row=5,column=8)
        tk.Label(cntr,text=u'\u03B2\''           ,width=f_width-3                 ).grid(row=5,column=6)
        tk.Label(cntr,text=u'\u03B2\'\''         ,width=f_width-3                 ).grid(row=5,column=10)
        tk.Label(cntr,text='Viscoelastic Par''s' ,width=f_width+1                 ).grid(row=5,column=12)
        tk.Label(cntr,text='Roughness [nm]'      ,width=f_width                   ).grid(row=1,column=13)
        if Cor.SamplePars['VertScaleR'] > 0:
            tk.Label(cntr,text='Aspect Ratio',width=f_width                       ).grid(row=3,column=13)

    tk.Checkbutton(cntr,text='1',   variable=i_Show_lay1_IV,command=Check_lay1, anchor='e').grid(row=2,column=0,sticky='W')
    tk.Checkbutton(cntr,text='2',   variable=i_Show_lay2_IV,command=Check_lay2, anchor='e').grid(row=3,column=0,sticky='W')
    tk.Checkbutton(cntr,text='Bulk',variable=i_Show_bulk_IV,command=Check_bulk, anchor='e').grid(row=5,column=0,sticky='W')

    tk.Button(cntr,text ='Model to Clipboard',command=SamplePars_to_Clpbd,anchor='n').grid(row=0,column=0,columnspan=2,sticky='N') 
    tk.Button(cntr,text ='Make Reference',command=Make_Reference     ,anchor='n').grid(row=0,column=2,columnspan=2,sticky='N')
    
    if Cor.Show_lay1 == 'yes':
        vals=(SamplePars_SVs['t_lay1'].get(),'+','-')
        t_1_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['t_lay1'],fg=fg,wrap=True,width=12,values=vals,command=incdec_t_lay1)
        t_1_Entry.grid(row=2,column=1)
        t_1_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'t_lay1'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['t_lay1'],command=Check_t_lay1).grid(row=2,column=2,sticky='W')
        vals=(SamplePars_SVs['rho_lay1'].get(),'+','-')
        rho_1_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['rho_lay1'],fg=fg,wrap=True,width=12-5,values=vals,command=incdec_rho_lay1)
        rho_1_Entry.grid(row=2,column=3)
        rho_1_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'rho_lay1'))
        vals=(SamplePars_SVs['VEPar1_lay1'].get(),'+','-')
        Jp_1_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar1_lay1'],fg=fg,wrap=True,width=12,values=vals,command=incdec_VEPar1_lay1)
        Jp_1_Entry.grid(row=2,column=4)
        Jp_1_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar1_lay1'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar1_lay1'],command=Check_VEPar1_lay1).grid(row=2,column=5)
        vals=(SamplePars_SVs['VEPar2_lay1'].get(),'+','-')
        Jpp_1_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar2_lay1'],fg=fg,wrap=True,width=12,values=vals,command=incdec_VEPar2_lay1)
        Jpp_1_Entry.grid(row=2,column=8)
        Jpp_1_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar2_lay1'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar2_lay1'],command=Check_VEPar2_lay1 ).grid(row=2,column=9)
        vals=(SamplePars_SVs['VEPar1_PLexpt_lay1'].get(),'+','-')
        Jp_PLexpt_1_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar1_PLexpt_lay1'],fg=fg,wrap=True,width=12-3,values=vals,command=incdec_VEPar1_PLexpt_lay1)
        Jp_PLexpt_1_Entry.grid(row=2,column=6)
        Jp_PLexpt_1_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar1_PLexpt_lay1'))        
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar1_PLexpt_lay1'],command=Check_VEPar1_PLexpt_lay1).grid(row=2,column=7)
        vals=(SamplePars_SVs['VEPar2_PLexpt_lay1'].get(),'+','-')
        Jpp_PLexpt_1_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar2_PLexpt_lay1'],fg=fg,wrap=True,width=12-3,values=vals,command=incdec_VEPar2_PLexpt_lay1)
        Jpp_PLexpt_1_Entry.grid(row=2,column=10)
        Jpp_PLexpt_1_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar2_PLexpt_lay1'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar2_PLexpt_lay1'],command=Check_VEPar2_PLexpt_lay1).grid(row=2,column=11)
    
        VEPar_cb_1 = tk.ttk.Combobox(cntr,state='readonly',width=f_width-1,textvariable=SamplePars_SVs['VEtype_lay1'],values=VEPar_Choices)
        VEPar_cb_1.grid(row=2,column=12)
        VEPar_cb_1.current(Cor.SamplePars['VEtype_lay1'])
        VEPar_cb_1.bind('<<ComboboxSelected>>',enter_VEPar_lay1)

    if Cor.Show_lay2 == 'yes':
        vals=(SamplePars_SVs['t_lay2'].get(),'+','-')
        t_2_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['t_lay2'],fg=fg,wrap=True,width=12,values=vals,command=incdec_t_lay2)
        t_2_Entry.grid(row=4,column=1)
        t_2_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'t_lay2'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['t_lay2'],command=Check_t_lay2).grid(row=4,column=2,sticky='W')
        vals=(SamplePars_SVs['rho_lay2'].get(),'+','-')
        rho_2_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['rho_lay2'],fg=fg,wrap=True,width=12-5,values=vals,command=incdec_rho_lay2)
        rho_2_Entry.grid(row=4,column=3)
        rho_2_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'rho_lay2'))
        vals=(SamplePars_SVs['VEPar1_lay2'].get(),'+','-')
        Jp_2_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar1_lay2'],fg=fg,wrap=True,width=12,values=vals,command=incdec_VEPar1_lay2)
        Jp_2_Entry.grid(row=4,column=4)
        Jp_2_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar1_lay2'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar1_lay2'],command=Check_VEPar1_lay2).grid(row=4,column=5)
        vals=(SamplePars_SVs['VEPar2_lay2'].get(),'+','-')
        Jpp_2_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar2_lay2'],fg=fg,wrap=True,width=12,values=vals,command=incdec_VEPar2_lay2)
        Jpp_2_Entry.grid(row=4,column=8)
        Jpp_2_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar2_lay2'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar2_lay2'],command=Check_VEPar2_lay2).grid(row=4,column=9)
        vals=(SamplePars_SVs['VEPar1_PLexpt_lay2'].get(),'+','-')
        Jp_PLexpt_2_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar1_PLexpt_lay2'],fg=fg,wrap=True,width=12-3,values=vals,command=incdec_VEPar1_PLexpt_lay2)
        Jp_PLexpt_2_Entry.grid(row=4,column=6)
        Jp_PLexpt_2_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar1_PLexpt_lay2'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar1_PLexpt_lay2'],command=Check_VEPar1_PLexpt_lay2).grid(row=4,column=7)
        vals=(SamplePars_SVs['VEPar2_PLexpt_lay2'].get(),'+','-')
        Jpp_PLexpt_2_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar2_PLexpt_lay2'],fg=fg,wrap=True,width=12-3,values=vals,command=incdec_VEPar2_PLexpt_lay2)
        Jpp_PLexpt_2_Entry.grid(row=4,column=10)
        Jpp_PLexpt_2_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar2_PLexpt_lay2'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar2_PLexpt_lay2'],command=Check_VEPar2_PLexpt_lay2).grid(row=4,column=11)
        VEPar_cb_2 = tk.ttk.Combobox(cntr,state='readonly',width=f_width-1,textvariable=SamplePars_SVs['VEtype_lay2'],values=VEPar_Choices)
        VEPar_cb_2.grid(row=4,column=12)
        VEPar_cb_2.current(Cor.SamplePars['VEtype_lay2'])
        VEPar_cb_2.bind('<<ComboboxSelected>>',enter_VEPar_lay2)
    
    if Cor.Show_bulk == 'yes':
        vals=(SamplePars_SVs['rho_lay3'].get(),'+','-')
        rho_3_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['rho_lay3'],fg=fg,wrap=True,width=12-5,values=vals,command=incdec_rho_lay3)
        rho_3_Entry.grid(row=6,column=3)
        rho_3_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'rho_lay3'))
        vals=(SamplePars_SVs['VEPar1_lay3'].get(),'+','-')
        Jp_3_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar1_lay3'],fg=fg,wrap=True,width=12,values=vals,command=incdec_VEPar1_lay3)
        Jp_3_Entry.grid(row=6,column=4)
        Jp_3_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar1_lay3'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar1_lay3'],command=Check_VEPar1_lay3).grid(row=6,column=5)
        vals=(SamplePars_SVs['VEPar2_lay3'].get(),'+','-')
        Jpp_3_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar2_lay3'],fg=fg,wrap=True,width=12,values=vals,command=incdec_VEPar2_lay3)
        Jpp_3_Entry.grid(row=6,column=8)
        Jpp_3_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar2_lay3'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar2_lay3'],command=Check_VEPar2_lay3).grid(row=6,column=9)
        vals=(SamplePars_SVs['VEPar1_PLexpt_lay3'].get(),'+','-')
        Jp_PLexpt_3_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar1_PLexpt_lay3'],fg=fg,wrap=True,width=12-3,values=vals,command=incdec_VEPar1_PLexpt_lay3)
        Jp_PLexpt_3_Entry.grid(row=6,column=6)
        Jp_PLexpt_3_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar1_PLexpt_lay3'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar1_PLexpt_lay3'],command=Check_VEPar1_PLexpt_lay3).grid(row=6,column=7)
        vals=(SamplePars_SVs['VEPar2_PLexpt_lay3'].get(),'+','-')
        Jpp_PLexpt_3_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar2_PLexpt_lay3'],fg=fg,wrap=True,width=12-3,values=vals,command=incdec_VEPar2_PLexpt_lay3)
        Jpp_PLexpt_3_Entry.grid(row=6,column=10)
        Jpp_PLexpt_3_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar2_PLexpt_lay3'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar2_PLexpt_lay3'],command=Check_VEPar2_PLexpt_lay3).grid(row=6,column=11)
        vals=(SamplePars_SVs['VertScaleR'].get(),'+','-')
        VertScaleR_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VertScaleR'],fg=fg,wrap=True,width=12,values=vals,command=incdec_VertScaleR)
        VertScaleR_Entry.grid(row=2,column=13)
        VertScaleR_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VertScaleR'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VertScaleR'],command=Check_VertScaleR).grid(row=2,column=14,sticky='W')
        if Cor.SamplePars['VertScaleR'] > 0:
            vals=(SamplePars_SVs['AspRat'].get(),'+','-')
            AspRat_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['AspRat'],fg=fg,wrap=True,width=12,values=vals,command=incdec_AspRat)
            AspRat_Entry.grid(row=4,column=13)
            AspRat_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'AspRat'))
            tk.Checkbutton(cntr,variable=IncPars_IVs['AspRat'],command=Check_AspRat).grid(row=4,column=14,sticky='W')
        else: 
            Cor.IncPars['AspRat'] = 0; IncPars_IVs['AspRat'].set(0); Cor.Write_Config()
        VEPar_cb_3 = tk.ttk.Combobox(cntr,state='readonly',width=f_width-1,textvariable=SamplePars_SVs['VEtype_lay3'],values=VEPar_Choices)
        VEPar_cb_3.grid(row=6,column=12)
        VEPar_cb_3.current(Cor.SamplePars['VEtype_lay3'])
        VEPar_cb_3.bind('<<ComboboxSelected>>',enter_VEPar_lay3)
        MakeConvertFrame(ConvertFrame)

def MakeDfcbynsFrame(cntr):
    for widget in cntr.winfo_children(): widget.destroy()
    global DD_DGbyn_Labels 
    DD_DGbyn_Labels = ['\u0394\u0393/n','\u0394D']

    def NewBLine():
        if os.path.isfile(Cor.CurrWD+'/tmp/Shifts_for_unhide.qt2'): DfDGbyns_for_Unhide = np.loadtxt(Cor.CurrWD+'/tmp/Shifts_for_unhide.qt2',skiprows=1)
        else                                    : DfDGbyns_for_Unhide = np.ones((1,4*Cor.novt+3))*np.nan
        for iovt in range(Cor.novt):
            DfDGbyns_for_Unhide[:,2+4*iovt  ] -= Cor.Dfcbyns[iovt].real
            DfDGbyns_for_Unhide[:,2+4*iovt+1] -= Cor.Dfcbyns[iovt].imag
            DfDGbyns_for_Unhide[:,2+4*iovt+2] -= Cor.Dfcbyns[iovt].real
            DfDGbyns_for_Unhide[:,2+4*iovt+3] -= Cor.Dfcbyns[iovt].imag
        np.savetxt(Cor.CurrWD+'/tmp/Shifts_for_unhide.qt2',DfDGbyns_for_Unhide,header=TT.header_DfDGbyns,delimiter='\t',newline='\n')

        for iovt in range(Cor.novt):
            TT.DfDGbyns[:,2+4*iovt  ] -= Cor.Dfcbyns[iovt].real
            TT.DfDGbyns[:,2+4*iovt+1] -= Cor.Dfcbyns[iovt].imag
            TT.DfDGbyns[:,2+4*iovt+2] -= Cor.Dfcbyns[iovt].real
            TT.DfDGbyns[:,2+4*iovt+3] -= Cor.Dfcbyns[iovt].imag
            Cor.Dfbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt  ]
            Cor.DGbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt+1]
        Cor.Dfcbyns = Cor.Dfbyns + 1j * Cor.DGbyns; MakeDfcbynsFrame(DfcbynsFrame)
        TT.Make_headers(); np.savetxt(Cor.CurrWD+'/tmp/Shifts.qt2',TT.DfDGbyns,header=TT.header_DfDGbyns,delimiter='\t',newline='\n')
        PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
        Cor.i_strt_avg = 0; Cor.i_stop_avg = 0;
        Cor.Write_Config()

    def Enter_Stuff_Dfcbyns(event,iovt,WhichStuffStr,key):
        if WhichStuffStr == 'Df':
            string = Df_SVs[iovt].get(); string.strip()
            try: Cor.Dfbyns[iovt] = np.float64(string);
            except: pass
        if WhichStuffStr == 'DG': 
            string = DG_SVs[iovt].get(); string.strip()
            try: Cor.DGbyns[iovt] = np.float64(string)
            except: pass

        Cor.Dfcbyns.real = Cor.Dfbyns
        Cor.Dfcbyns.imag = Cor.DGbyns
        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes'; Cor.Write_Config() 
        PlotSingle(PlotSingleFrame) 
        MakeDfcbynsFrame(DfcbynsFrame)

    Df_SVs = []; DG_SVs = []; OvtInc_IVs = []
    if Cor.i_current < Cor.i_strt_fit: Cor.i_current = Cor.i_strt_fit 
    if Cor.i_current > Cor.i_stop_fit: Cor.i_current = Cor.i_stop_fit 
    for iovt in range(Cor.novt):  
        if np.isnan(Cor.Dfbyns[iovt]): Df_SVs.append(tk.StringVar(cntr,''))
        else: Df_SVs.append(tk.StringVar(cntr,np.round(Cor.Dfbyns[iovt],2)))
        if np.isnan(Cor.DGbyns[iovt]): DG_SVs.append(tk.StringVar(cntr,''))
        else:     
            if Cor.DD_DGbyn == 'DD': 
                DG_SVs.append(tk.StringVar(cntr,np.round(Cor.DGbyns[iovt]/Cor.f_fund*2./1e-6,2)))
            if Cor.DD_DGbyn == 'DGbyn': 
                DG_SVs.append(tk.StringVar(cntr,np.round(Cor.DGbyns[iovt],2)))
        OvtInc_IVs.append(tk.IntVar(cntr,int(Cor.OvtInc[iovt])))
    if Cor.i_selec > 0 and Cor.i_selec < len(TT.DfDGbyns) and Cor.i_stop_avrg == Cor.i_strt_avrg:     
        tk.Label(cntr,text=str(np.round(TT.DfDGbyns[Cor.i_selec,Cor.i_col_x],1))).grid(row=0,column=0)
    if Cor.i_stop_avrg > Cor.i_strt_avrg and Cor.i_strt_avrg < len(TT.DfDGbyns) and Cor.i_stop_avrg < len(TT.DfDGbyns):  
        tk.Label(cntr,text=str(np.round(TT.DfDGbyns[Cor.i_strt_avrg,Cor.i_col_x],1))+'-'+\
                           str(np.round(TT.DfDGbyns[Cor.i_stop_avrg,Cor.i_col_x],1))   ).grid(row=0,column=0)
    tk.Label(cntr,text='\u0394f/n [Hz]').grid(row=0,column=1)
    if Cor.DD_DGbyn == 'DD'   : tk.Label(cntr,text='\u0394D [10\u207B\u2076]').grid(row=0,column=2)
    if Cor.DD_DGbyn == 'DGbyn': tk.Label(cntr,text='\u0394\u0393/n [Hz]').grid(row=0,column=2)
    
    entriesDf = []; entriesDG = []
    for iovt,n in enumerate(Cor.n_arr):
        tk.Label(cntr,width=6,text=str(round(n*Cor.f_fund/1e6)) + ' MHz',anchor='e').grid(row=iovt+1,column=0,sticky='E')
        entriesDf.append(tk.Entry(cntr,width=7,textvariable=Df_SVs[iovt]))
        entriesDf[iovt].grid(row=iovt+1,column=1)
        if iovt == 0: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,0,'Df',''))
        if iovt == 1: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,1,'Df',''))
        if iovt == 2: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,2,'Df',''))
        if iovt == 3: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,3,'Df',''))
        if iovt == 4: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,4,'Df',''))
        if iovt == 5: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,5,'Df',''))
        if iovt == 6: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,6,'Df',''))
        entriesDG.append(tk.Entry(cntr,width=7,textvariable=DG_SVs[iovt]))
        entriesDG[iovt].grid(row=iovt+1,column=2)
        if iovt == 0: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,0,'DG',''))
        if iovt == 1: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,1,'DG',''))
        if iovt == 2: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,2,'DG',''))
        if iovt == 3: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,3,'DG',''))
        if iovt == 4: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,4,'DG',''))
        if iovt == 5: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,5,'DG',''))
        if iovt == 6: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,6,'DG',''))

    def Check_ovt1():
        Cor.OvtInc[0] = int(OvtInc_IVs[0].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    def Check_ovt2():
        Cor.OvtInc[1] = int(OvtInc_IVs[1].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    def Check_ovt3():
        Cor.OvtInc[2] = int(OvtInc_IVs[2].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    def Check_ovt4():
        Cor.OvtInc[3] = int(OvtInc_IVs[3].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    def Check_ovt5():
        Cor.OvtInc[4] = int(OvtInc_IVs[4].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    def Check_ovt6():
        Cor.OvtInc[5] = int(OvtInc_IVs[5].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    def Check_ovt7():
        Cor.OvtInc[6] = int(OvtInc_IVs[6].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[0],command=Check_ovt1).grid(row=1,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[1],command=Check_ovt2).grid(row=2,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[2],command=Check_ovt3).grid(row=3,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[3],command=Check_ovt4).grid(row=4,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[4],command=Check_ovt5).grid(row=5,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[5],command=Check_ovt6).grid(row=6,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[6],command=Check_ovt7).grid(row=7,column=3)
    
    tk.Button(cntr,text='Set Baseline',command=NewBLine,anchor='n').grid(row=8,column=1,columnspan=2,sticky='N')

def MakeFitFrame(cntr):
    global FitRange_Btn,Fit_Series_Btn

    for widget in cntr.winfo_children(): widget.destroy()
    Model_Labels = ['Multilayer Formalism','3rd Order Perturbation','5th Order Perturbation']
    weight_Labels = ['~n^-1','~n^-0.5','flat','~n^0.5','~n^1']
    RelWeight_DfDG_SV = tk.StringVar(cntr,Cor.RelWeight_DfDG)
    ErrDfbyn_SV = tk.StringVar(cntr,Cor.ErrDfbyn)

    Update_Inval_SV  = tk.StringVar(cntr,Cor.Update_Inval)
    TT_fit_from_Labels  = ['Guess \u2190 Prev Result','Guess \u2190 ParsPanel']
    TT_direcFitSeries_Labels     = ['\u2192','\u2190']

    def Enter_Stuff_Fit(event,WhichStuffStr):
        if WhichStuffStr == 'ErrDfbyn': 
            string = ErrDfbyn_SV.get(); string.strip()
            try: 
                Cor.ErrDfbyn = np.float64(string)
                MakeFitFrame(cntr);
                Cor.Write_Config()
            except: pass    
        if WhichStuffStr == 'RelWeight_DfDG':
            string = RelWeight_DfDG_SV.get(); string.strip()
            try: 
                Cor.RelWeight_DfDG = np.float64(string)
                Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes'; Cor.Write_Config()
            except: pass
        
        if WhichStuffStr == 'Update_Inval': 
            string = Update_Inval_SV.get(); string.strip()
            try: 
                Cor.Update_Inval = int(string); 
                if Cor.Update_Inval < 1: Cor.Update_Inval = 1
                Cor.Write_Config(); 
                PlotFPars(PlotFParsFrame)
            except: pass        
        MakeFitFrame(FitFrame)
        Cor.Write_Config()

    def enter_i_Model(event):    
        Model = event.widget.get()
        for i,Model_Label in enumerate(Model_Labels):
            if Model == Model_Label: Cor.Model = Cor.Model_strings[i]
        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        PlotSingle(PlotSingleFrame)
        MakeFitFrame(FitFrame)
        
    def enter_stat_weight(event):    
        weight = event.widget.get()
        for i,weight_Label in enumerate(weight_Labels):
            if weight == weight_Label: Cor.stat_weight = Cor.stat_weight_strings[i]
        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes';  Cor.Write_Config()
        MakeFitFrame(FitFrame)
        
    def checkPlotErrBars():
        Cor.i_PlotErrBars = i_PlotErrBars_IV.get(); Cor.Write_Config()
        PlotFPars(PlotFParsFrame)

    def enter_i_TT_fit_from(event):    
        TT_fit_from = event.widget.get()
        for i,TT_fit_from_Label in enumerate(TT_fit_from_Labels):
            if TT_fit_from == TT_fit_from_Label: 
                Cor.TT_guess_from = Cor.TT_guess_from_strings[i]
                # print(i,Cor.TT_guess_from,TT_fit_from,TT_fit_from_Label)    
        Cor.Write_Config()
        MakeFitFrame(FitFrame)

    def enter_i_TT_direcFitSeries(event):    
        TT_direcFitSeries = event.widget.get()
        for i,TT_direcFitSeries_Label in enumerate(TT_direcFitSeries_Labels):
            if TT_direcFitSeries == TT_direcFitSeries_Label: Cor.TT_direcFitSeries = Cor.TT_direcFitSeries_strings[i]
        Cor.Write_Config()
        MakeFitFrame(FitFrame)
    
    def Set_FitRange():  Cor.ready_state = 'FitRange';      Root.config(cursor='hand2'); FitRange_Btn['bg'] = 'lightgrey'

    tk.Button(cntr,text ='Fit Point',command=Fit,fg='red').grid(row=0,column=0,sticky='W')
    tk.Button(cntr,text ='Undo Fit',command=Undo).grid(         row=0,column=1,sticky='W')
    tk.Button(cntr,text ='Conf Limits\u2192Console',command=ConfLims_lmfit_2_Console,width=18).grid(row=0,column=2,columnspan=2,sticky='W')

    if Cor.Model == 'Multilayer_Formalism':
        Model_cb = tk.ttk.Combobox(cntr,state='readonly',width=32,textvariable=Model_Labels[0],values=Model_Labels); Model_cb.current(0)
    if Cor.Model == '3rd-Order_Perturbation':
        Model_cb = tk.ttk.Combobox(cntr,state='readonly',width=32,textvariable=Model_Labels[1],values=Model_Labels); Model_cb.current(1)
    if Cor.Model == '5th-Order_Perturbation':
        Model_cb = tk.ttk.Combobox(cntr,state='readonly',width=32,textvariable=Model_Labels[2],values=Model_Labels); Model_cb.current(2)
    Model_cb.grid(row=1,column=0,columnspan=3,sticky='W')
    Model_cb.bind('<<ComboboxSelected>>',enter_i_Model)
    Cor.Calc_chi2()
    if not np.isnan(Cor.chi2):
        if Cor.chi2 < 1e9: 
            tk.Label(FitFrame,width=13,text=' \u03c7\u00b2 ' + str(np.round(Cor.chi2,2)),fg='blue').grid(row=1,column=2,columnspan=2,sticky='W')
        else: 
            tk.Label(FitFrame,width=13,text=' \u03c7\u00b2 ').grid(row=1,column=2,columnspan=2,sticky='W')
    else:    
        tk.Label(FitFrame,width=13,text=' \u03c7\u00b2 ').grid(row=1,column=2,columnspan=2,sticky='W')

    tk.Label(cntr,text='(\u03b4f/n)_err[Hz]',anchor='w').grid(row=2,column=0,columnspan=2,sticky='W')
    ErrDfbyn_Entry = tk.Entry(cntr,width=4,textvariable=ErrDfbyn_SV)
    ErrDfbyn_Entry.grid(row=2,column=1,sticky='E')
    ErrDfbyn_Entry.bind('<Return>',lambda event: Enter_Stuff_Fit(event,'ErrDfbyn'))

    if Cor.i_PlotErrBars == 1: i_PlotErrBars_IV = tk.IntVar(cntr,1)
    if Cor.i_PlotErrBars == 0: i_PlotErrBars_IV = tk.IntVar(cntr,0)
    tk.Checkbutton(cntr,anchor='w',text='Error Bars',variable=i_PlotErrBars_IV,command=checkPlotErrBars).grid(row=2,column=2,columnspan=2,sticky = 'W')

    tk.Label(cntr,text='ErrB Inval').grid(row=2,column=3,sticky='W')
    Update_Inval_Entry = tk.Entry(cntr,width=4,textvariable=Update_Inval_SV)
    Update_Inval_Entry.grid(row=2,column=4,sticky='W')
    Update_Inval_Entry.bind('<Return>',lambda event: Enter_Stuff_Fit(event,'Update_Inval'))

    tk.Label(cntr,text='RelWeight\u0394\u0393,\u0394f').grid(row=3,column=0,columnspan=2,sticky='W')
    RelWeight_DfDG_SV_Entry = tk.Entry(cntr,width=4,textvariable=RelWeight_DfDG_SV)
    RelWeight_DfDG_SV_Entry.grid(row=3,column=1,sticky='E')
    RelWeight_DfDG_SV_Entry.bind('<Return>',lambda event: Enter_Stuff_Fit(event,'RelWeight_DfDG'))

    tk.Label(cntr,text='Stat Weight (n)').grid(row=3,column=2,columnspan=2,sticky='W')
    if Cor.stat_weight == 'n^-1':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,textvariable=weight_Labels[0],values=weight_Labels); weight_cb.current(0)
    if Cor.stat_weight == 'n^-(0.5)':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,textvariable=weight_Labels[1],values=weight_Labels); weight_cb.current(1)
    if Cor.stat_weight == 'flat':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,textvariable=weight_Labels[2],values=weight_Labels); weight_cb.current(2)
    if Cor.stat_weight == 'n^(0.5)':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,textvariable=weight_Labels[3],values=weight_Labels); weight_cb.current(3)
    if Cor.stat_weight == 'n^1':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,textvariable=weight_Labels[4],values=weight_Labels); weight_cb.current(4)
    weight_cb.grid(row=3,column=3,columnspan=2,sticky='W')
    weight_cb.bind('<<ComboboxSelected>>',enter_stat_weight)

    Fit_Series_Btn= tk.Button(cntr,text ='Fit Series',command=Fit_Series,fg='red')
    Fit_Series_Btn.grid(row=8,column=0,sticky='W')
    tk.Button(cntr,text ='Clear',command=Clear_Fits).grid(row=8,column=1,columnspan=2,sticky='W')
    FitRange_Btn = tk.Button(cntr,text ='Select Fit Range',command=Set_FitRange)
    FitRange_Btn.grid(row=8,column=2,sticky='W')
    
    # print('Cor.TT_guess_from',Cor.TT_guess_from)
    if Cor.TT_guess_from == 'from_previous_fit':
        TT_guess_from_cb = tk.ttk.Combobox(cntr,state='readonly',width=18,textvariable=TT_fit_from_Labels[0],values=TT_fit_from_Labels); TT_guess_from_cb.current(0)
    else:
        TT_guess_from_cb = tk.ttk.Combobox(cntr,state='readonly',width=18,textvariable=TT_fit_from_Labels[1],values=TT_fit_from_Labels); TT_guess_from_cb.current(1)
    TT_guess_from_cb.grid(row=11,column=0,columnspan=3,sticky='W')
    TT_guess_from_cb.bind('<<ComboboxSelected>>',enter_i_TT_fit_from)

    if Cor.TT_direcFitSeries == 'start_to_stop': 
        TT_direcFitSeries_cb = tk.ttk.Combobox(cntr,state='readonly',width=3,textvariable=TT_direcFitSeries_Labels[0],values=TT_direcFitSeries_Labels); TT_direcFitSeries_cb.current(0)
    else: 
        TT_direcFitSeries_cb = tk.ttk.Combobox(cntr,state='readonly',width=3,textvariable=TT_direcFitSeries_Labels[1],values=TT_direcFitSeries_Labels); TT_direcFitSeries_cb.current(1)
    TT_direcFitSeries_cb.grid(row=11,column=3,columnspan=1,sticky='W')
    TT_direcFitSeries_cb.bind('<<ComboboxSelected>>',enter_i_TT_direcFitSeries)

def MakeStartupFrame(cntr):
    def enter_Start_from(event):
        Start_from = event.widget.get()
        for i,Start_from_Label in enumerate(Start_from_Labels):
            if Start_from == Start_from_Label: Cor.Start_from = Cor.Start_from_strings[i]
        Cor.Write_QTM_cfg()

    for widget in cntr.winfo_children(): widget.destroy()
    Start_from_Labels   = ['Start from Default','Recover Previous Session']

    if Cor.Start_from == 'Start_from_Default':
        Start_from_cb = tk.ttk.Combobox(cntr,state='readonly',width=25,textvariable=Start_from_Labels[0],values=Start_from_Labels); Start_from_cb.current(0)
    else:
        Start_from_cb = tk.ttk.Combobox(cntr,state='readonly',width=25,textvariable=Start_from_Labels[1],values=Start_from_Labels); Start_from_cb.current(1)
    Start_from_cb.grid(row=10,column=0,columnspan=3,sticky='W')
    Start_from_cb.bind('<<ComboboxSelected>>',enter_Start_from)
    
def MakeTT_IOFrame(cntr):
    global noise_label
    for widget in cntr.winfo_children(): widget.destroy()  
    n_pre_avg_SV       = tk.StringVar(cntr,Cor.n_pre_avg)

    def ImportFromClipboard():
        Proceed = tk.messagebox.askokcancel('','This will clear previous data, fits, and fit results. Are you sure you want to proceed?')
        if not Proceed: return
        NewFile()
        Root.update()
        cliptext = Root.clipboard_get()
        lines = cliptext.splitlines()
        for iovt in range(Cor.novt):
            Cor.Dfbyns[iovt] = np.nan
            Cor.DGbyns[iovt] = np.nan
        for j in range(len(lines)):
            try: 
                nL = int(lines[j].split()[0])
                DfbynL     = float(lines[j].split()[1])
                DGbynOrDDL = float(lines[j].split()[2])
                for iovtt,n in enumerate(Cor.n_arr):
                    if nL == n:
                        iovt = iovtt
                        Cor.Dfbyns[iovt] = DfbynL
                        if Cor.DD_DGbyn == 'DGbyn': Cor.DGbyns[iovt] = DGbynOrDDL
                        if Cor.DD_DGbyn == 'DD':    Cor.DGbyns[iovt] = DGbynOrDDL/2*Cor.f_fund*1e-6
            except: pass
        for iovt in range(Cor.novt): 
            if not np.isnan(Cor.Dfbyns[iovt]) and not np.isnan(Cor.DGbyns[iovt]):
                Cor.OvtInc[iovt] = 1
            else: Cor.OvtInc[iovt] = 0 
        Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns     

        Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'yes'; Cor.Write_Config()
        PlotSingle(PlotSingleFrame)
        MakeDfcbynsFrame(DfcbynsFrame)    

    def enter_format(event):
        DD_DGbyn = event.widget.get()
        for i,DD_DGbyn_Label in enumerate(DD_DGbyn_Labels):
            if DD_DGbyn == DD_DGbyn_Label: Cor.DD_DGbyn = Cor.DD_DGbyn_strings[i]
        Cor.Write_Config()
        Make_Menu()
        MakeDfcbynsFrame(DfcbynsFrame)
        PlotDfDGbyns(PlotDfDGbynsFrame)
        PlotSingle(PlotSingleFrame)

    def Enter_Stuff_TT_IO(event,iovt,WhichStuffStr,key):
        if WhichStuffStr == 'n_pre_avg': 
            string = n_pre_avg_SV.get(); string.strip()
            try: Cor.n_pre_avg = int(string)
            except: pass    
        MakeTT_IOFrame(TT_IOFrame)
        Cor.Write_Config()
        if WhichStuffStr == 'Update_Inval': PlotFPars(PlotFParsFrame)

    IO_Format_Labels    = ['QTZ','QSoft','QSoft New','AWSensors','OpenQCM','QCM-I']
    Channel_Labels      = ['Channel 1','Channel 2','Channel 3','Channel 4']
    vs_time_datapoint_Labels = ['x: time','x: i']
           
    def Import_TT():
        filetypes = (('text files','*.txt'),('data files','*.dat'))
        f = fd.askopenfile(filetypes=filetypes)
        if not os.path.isfile(f.name): return
        if len(f.name) == 0: return
        Import_Btn['state'] = 'disabled'
        Root.update()
        Cor.Write_Config()
        Clear_Fits(); Clear()
        Cor.TT_filename = f.name
        TT.Import_TT() 
        Import_Btn['state'] = 'normal'
        Cor.i_selec = 0
        while All_NaNs_in_Dfcs() and Cor.i_selec < len(TT.DfDGbyns) - 1:
            Cor.i_selec += 1
        for iovt in range(Cor.novt): 
            Cor.Dfbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt]  
            Cor.DGbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt+1]  
        PlotDfDGbyns(PlotDfDGbynsFrame); 
        PlotFPars(PlotFParsFrame) 
        MakeDfcbynsFrame(DfcbynsFrame); PlotSingle(PlotSingleFrame)
        MakeSampleParsFrame(SampleParsFrame)
        MakeTT_IOFrame(TT_IOFrame)
        f = open(Cor.CurrWD+'/tmp/LogFile.qt2','w'); f.close()
        Root.title('PyQTM:    ' + os.path.basename(Cor.filename) + '   /   ' + os.path.basename(Cor.TT_filename))

    def Import_TT_Clipbrd():
        if Cor.TT_IO_Format == 'from_AWSensors':
            tempdf=pd.read_clipboard()
            if not tempdf.empty:
                tempdf.to_csv('importtemp.txt', sep ='\t', index=False)
                Cor.TT_filename = 'importtemp.txt'
                TT.Import_TT()
                Cor.TT_filename = ''
                if os.path.isfile('importtemp.txt'): os.remove('importtemp.txt')
                Cor.i_selec = 0
                while All_NaNs_in_Dfcs() and Cor.i_selec < len(TT.DfDGbyns) - 1:
                   Cor.i_selec += 1

                for iovt in range(Cor.novt): 
                    Cor.Dfbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt]  
                    Cor.DGbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt+1]  
                PlotDfDGbyns(PlotDfDGbynsFrame); 
                PlotFPars(PlotFParsFrame) 
                MakeDfcbynsFrame(DfcbynsFrame); PlotSingle(PlotSingleFrame)
                MakeSampleParsFrame(SampleParsFrame)
                MakeTT_IOFrame(TT_IOFrame) 
                f = open(Cor.CurrWD+'/tmp/LogFile.qt2','w'); f.close()
                Root.title('PyQTM:    Imported from Clipboard')

        else:
            tk.messagebox.showinfo('','Feature not yet implemented')
            return
    
    def enter_i_IO_Format_TT(event): 
        IO_Format = event.widget.get()
        for i,IO_Format_Label in enumerate(IO_Format_Labels):
            if IO_Format == IO_Format_Label: 
                Cor.TT_IO_Format = Cor.TT_IO_Format_strings[i]
        MakeTT_IOFrame(TT_IOFrame)
        Cor.Write_Config()
       
    def enter_i_channel_TT(event):
        Channel = event.widget.get()
        for i,Channel_Label in enumerate(Channel_Labels):
            if Channel == Channel_Label: Cor.i_channel = i
        Cor.Write_Config()
        
    def enter_vs_time_datapoint(event):    
        vs_time_datapoint = event.widget.get()
        for i,vs_time_datapoint_Label in enumerate(vs_time_datapoint_Labels):
            if vs_time_datapoint == vs_time_datapoint_Label: Cor.vs_time_datapoint = Cor.vs_time_datapoint_strings[i]
        if Cor. vs_time_datapoint == 'time': Cor.i_col_x = 1
        else:                               Cor.i_col_x = 0 
        Cor.Write_Config()
        PlotDfDGbyns(PlotDfDGbynsFrame)
        PlotFPars(PlotFParsFrame)

    def Check_TT_Correct_Drift():
        if int(TT_Correct_Drift_IV.get()) == 0: Cor.TT_Correct_Drift = 'no'
        if int(TT_Correct_Drift_IV.get()) == 1: Cor.TT_Correct_Drift = 'yes'
        Cor.Write_Config()

    tk.Button(cntr,text='Point from Clpbd',command=ImportFromClipboard,fg='blue', anchor='e').grid(row=1,column=0,columnspan=2,sticky='W')
    if Cor.DD_DGbyn == 'DGbyn':
        DD_DGbyn_cb = tk.ttk.Combobox(cntr,state='readonly',width=5,textvariable=DD_DGbyn_Labels[0],values=DD_DGbyn_Labels); DD_DGbyn_cb.current(0)
    if Cor.DD_DGbyn == 'DD':
        DD_DGbyn_cb = tk.ttk.Combobox(cntr,state='readonly',width=5,textvariable=DD_DGbyn_Labels[1],values=DD_DGbyn_Labels); DD_DGbyn_cb.current(1)
    DD_DGbyn_cb.grid(row=1,column=3,sticky='W')
    DD_DGbyn_cb.bind('<<ComboboxSelected>>',enter_format)
    
    wdt=9
    if Cor.TT_IO_Format =='from_AWSensors': 
        Import_Btn = tk.Button(cntr,text ='Series from Clpbd',command=Import_TT_Clipbrd,fg='blue')
        Import_Btn.grid(row=3,column=0,columnspan=2,sticky='N')
    Import_Btn = tk.Button(cntr,text ='Series from file',command=Import_TT,fg='blue')
    Import_Btn.grid(row=4,column=0,columnspan=2,sticky='N')
    if Cor.TT_IO_Format =='from_QSoft':
        IO_Format_cb = tk.ttk.Combobox(cntr,state='readonly',width=wdt,textvariable=IO_Format_Labels[1],values=IO_Format_Labels); IO_Format_cb.current(1)
    elif Cor.TT_IO_Format =='from_QSoft_new':
        IO_Format_cb = tk.ttk.Combobox(cntr,state='readonly',width=wdt,textvariable=IO_Format_Labels[2],values=IO_Format_Labels); IO_Format_cb.current(2)
    elif Cor.TT_IO_Format =='from_AWSensors':
        IO_Format_cb = tk.ttk.Combobox(cntr,state='readonly',width=wdt,textvariable=IO_Format_Labels[3],values=IO_Format_Labels); IO_Format_cb.current(3)
    elif Cor.TT_IO_Format =='from_OpenQCM':
        IO_Format_cb = tk.ttk.Combobox(cntr,state='readonly',width=wdt,textvariable=IO_Format_Labels[4],values=IO_Format_Labels); IO_Format_cb.current(4)
    elif Cor.TT_IO_Format =='from_QCM-I':
        IO_Format_cb = tk.ttk.Combobox(cntr,state='readonly',width=wdt,textvariable=IO_Format_Labels[4],values=IO_Format_Labels); IO_Format_cb.current(5)
    else:
        IO_Format_cb = tk.ttk.Combobox(cntr,state='readonly',width=wdt,textvariable=IO_Format_Labels[0],values=IO_Format_Labels); IO_Format_cb.current(0)
    IO_Format_cb.grid(row=3,column=3,rowspan=2,columnspan=2,sticky='W')
    IO_Format_cb.bind('<<ComboboxSelected>>',enter_i_IO_Format_TT)
    tk.Label(cntr,text='Avg on Import').grid(row=7,column=0,sticky='E')
    n_pre_avg_Entry = tk.Entry(cntr,textvariable=n_pre_avg_SV,width=4)
    n_pre_avg_Entry.grid(row=7,column=1,sticky='W')
    n_pre_avg_Entry.bind('<Return>',lambda event: Enter_Stuff_TT_IO(event,0,'n_pre_avg',''))

    if Cor.TT_IO_Format == 'from_QSoft_new':
        IO_Format_cb.grid(row=2,column=3,rowspan=1,columnspan=2,sticky='W')
        Channel_cb = tk.ttk.Combobox(cntr,state='readonly',width=10,textvariable=Channel_Labels[Cor.i_channel],values=Channel_Labels)
        Channel_cb.grid(row=4,column=3,columnspan=2,sticky='W')
        Channel_cb.current(Cor.i_channel)
        Channel_cb.bind('<<ComboboxSelected>>',enter_i_channel_TT)

    noise_label = tk.Label(cntr,text='(\u03b4f/n)_rms [mHz]: --')
    noise_label.grid(row=11,column=0,columnspan=4,sticky='N')
    TT.get_rms_noise_Dfbyn()
    if not np.isnan(Cor.rms_noise_Dfbyn):
        noise_label = tk.Label(cntr,text='(\u03b4f/n)_rms [mHz]: '+ str(np.round(Cor.rms_noise_Dfbyn*1e3,1)),anchor='w')
        noise_label.grid(row=11,column=0,columnspan=4,sticky='N')

    if Cor.vs_time_datapoint == 'time':
        vs_time_datapoint_cb = tk.ttk.Combobox(cntr,state='readonly',width=9,textvariable=vs_time_datapoint_Labels[0],values=vs_time_datapoint_Labels); vs_time_datapoint_cb.current(0)
    if Cor.vs_time_datapoint == 'datapoint':
        vs_time_datapoint_cb = tk.ttk.Combobox(cntr,state='readonly',width=9,textvariable=vs_time_datapoint_Labels[1],values=vs_time_datapoint_Labels); vs_time_datapoint_cb.current(1)
    vs_time_datapoint_cb.grid(row=7,column=3,columnspan=2,sticky='W')
    vs_time_datapoint_cb.bind('<<ComboboxSelected>>',enter_vs_time_datapoint)

    if Cor.TT_Correct_Drift == 'yes': TT_Correct_Drift_IV = tk.IntVar(cntr,1)
    if Cor.TT_Correct_Drift == 'no' : TT_Correct_Drift_IV = tk.IntVar(cntr,0)
    TT_Correct_Drift_CBtn = tk.Checkbutton(cntr,text='Import: Comp Drift',variable=TT_Correct_Drift_IV,command=Check_TT_Correct_Drift)
    TT_Correct_Drift_CBtn.grid(row=9,column=0,columnspan=3,sticky='W')

    MakeStartupFrame(StartupFrame)

def MakeConvertFrame(cntr):
    for widget in cntr.winfo_children(): widget.destroy()
    if Cor.Do_Conv == 'yes': i_Do_Conv_IV = tk.IntVar(cntr,1)
    if Cor.Do_Conv == 'no' : i_Do_Conv_IV = tk.IntVar(cntr,0)

    def Check_Conv(): 
        if int(i_Do_Conv_IV.get()) == 1: Cor.Do_Conv = 'yes'
        if int(i_Do_Conv_IV.get()) == 0: Cor.Do_Conv = 'no'
        Cor.Write_Config()
        if Cor.Do_Conv == 'yes' : TT.Convert_TimeSeries()
        MakeConvertFrame(ConvertFrame)
        PlotFPars(PlotFParsFrame)

    def enter_VEPar_Conv(event): 
        VEPar = event.widget.get()
        for i,VEPar_Choice in enumerate(VEPar_Choices):
            if VEPar == VEPar_Choice: Cor.VEPar_Conv = i
        Cor.Write_Config()
        TT.Convert_TimeSeries()
        MakeConvertFrame(ConvertFrame)
        PlotFPars(PlotFParsFrame)
    
    SingleLayer,i_layer = Cor.Determine_Layers_IncInFits()
    if SingleLayer: 
        Convert_CBox = tk.Checkbutton(cntr,text='Convert after fit',variable=i_Do_Conv_IV,command=Check_Conv,anchor='w')
        Convert_CBox.grid(row=1,column=0,columnspan=2,sticky='N')
        if Cor.Do_Conv == 'yes':
            VEPar_cb_Conv = tk.ttk.Combobox(cntr,state='readonly',width=11,\
                textvariable=VEPar_Choices[Cor.VEPar_Conv],values=VEPar_Choices)
            VEPar_cb_Conv.grid(row=1,column=2,columnspan=2)
            VEPar_cb_Conv.current(Cor.VEPar_Conv)
            VEPar_cb_Conv.bind('<<ComboboxSelected>>',enter_VEPar_Conv)
    else : Cor.Do_Conv == 'no'

def NewFile():
    if Cor.Do_SaveQuery == 'yes':
        answer = tk.messagebox.askyesnocancel('','Save current work?')
        if answer == None: return
        if answer == True    : Save_As()
    Cor.CurrWD = os.getcwd()
    for Filename in os.listdir(Cor.CurrWD+'/tmp/'):
        os.remove(Cor.CurrWD+'/tmp/'+Filename) 
    if os.path.isfile(Cor.CurrWD+'/Defaults.qtm'): 
        shutil.copyfile(Cor.CurrWD+'/Defaults.qtm',Cor.CurrWD+'/tmp/Master.qtm')
    Cor.Read_Config(); Limits.Set_Defaults()
    Clear_Fits(); Clear()
    Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'no'
    Cor.Write_Config()
    TT.Initialize()
    Update_User_Interface()
    
def OpenPrevious(i): 
    if Cor.Do_SaveQuery == 'yes':
        answer = tk.messagebox.askyesnocancel('','Save current work?')
        if answer == None : return
        if answer == True    : Save_As()
    Cor.folder   = os.path.dirname( Cor.Previous_Filenames[i])
    Cor.filename = os.path.basename(Cor.Previous_Filenames[i])
    Cor.Write_Config(); Open(Cor.folder,Cor.filename)
    
def OpenFile():
    if Cor.Do_SaveQuery == 'yes':
        answer = tk.messagebox.askyesnocancel('','Save current work?')
        if answer == None : return
        if answer == True    : Save_As()
    # filetypes = (('qtm files','*.qtm'))
    OpenFilename = fd.askopenfile(filetypes = [("qtm file", ".qtm")])
    Cor.folder   = os.path.dirname( OpenFilename.name)
    Cor.filename = os.path.basename(OpenFilename.name).replace('_Master.qtm','')
    Update_Previous_Filenames() 
    Open(Cor.folder,Cor.filename)

def Open(folder,filename):
    if not os.path.isfile(folder+'/'+filename + '_Master.qtm') and \
           os.path.isfile(folder+'/'+filename + '~tmp.qtm'):
        shutil.copyfile(  folder+'/'+filename + '~tmp.qtm',folder+'/'+filename + '~Master.qtm')

    if os.path.isfile(folder+'/'+filename + '_Master.qtm'): 
        shutil.copyfile(folder+'/'+filename + '_Master.qtm',Cor.CurrWD+'/tmp/Master.qtm')
    else: tk.messagebox.showinfo('','file not found'); return
    Cor.Read_Config(); 
    Cor.folder   = folder
    Cor.filename = filename
    Cor.Do_SaveQuery = 'no'; Cor.Write_Config() 
    Clear_Fits(); Clear()
    if os.path.isfile(folder+'/'+filename + '_Shifts.qt2')     : shutil.copyfile(folder+'/'+filename + '_Shifts.qt2'     ,Cor.CurrWD+'/tmp/Shifts.qt2')
    if os.path.isfile(folder+'/'+filename + '_FitPars.qt2')    : shutil.copyfile(folder+'/'+filename + '_FitPars.qt2'    ,Cor.CurrWD+'/tmp/FitPars.qt2')
    if os.path.isfile(folder+'/'+filename + '_FitParsConv.qt2'): shutil.copyfile(folder+'/'+filename + '_FitParsConv.qt2',Cor.CurrWD+'/tmp/FitParsConv.qt2')
    if os.path.isfile(folder+'/'+filename + '_Logfile.qt2')    : shutil.copyfile(folder+'/'+filename + '_Logfile.qt2'    ,Cor.CurrWD+'/tmp/LogFile.qt2')

    if os.path.isfile(folder+'/'+filename + '_Backup.qt2')                : shutil.copyfile(folder+'/'+filename + '_Backup.qt2'                ,Cor.CurrWD+'/tmp/Backup.qt2')
    if os.path.isfile(folder+'/'+filename + '_Shifts_for_unhide.qt2')     : shutil.copyfile(folder+'/'+filename + '_Shifts_for_unhide.qt2'     ,Cor.CurrWD+'/tmp/Shifts_for_unhide.qt2')
    if os.path.isfile(folder+'/'+filename + '_FitPars_for_unhide.qt2')    : shutil.copyfile(folder+'/'+filename + '_FitPars_for_unhide.qt2'    ,Cor.CurrWD+'/tmp/FitPars_for_unhide.qt2')
    if os.path.isfile(folder+'/'+filename + '_FitParsConv_for_unhide.qt2'): shutil.copyfile(folder+'/'+filename + '_FitParsConv_for_unhide.qt2',Cor.CurrWD+'/tmp/FitParsConv_for_unhide.qt2')
    if os.path.isfile(folder+'/'+filename + '_Single.png')                : shutil.copyfile(folder+'/'+filename + '_Single.png'                ,Cor.CurrWD+'/tmp/Single.png')
    if os.path.isfile(folder+'/'+filename + '_All_FPars.png')             : shutil.copyfile(folder+'/'+filename + '_All_FPars.png'             ,Cor.CurrWD+'/tmp/All_FPars.png')
    if os.path.isfile(folder+'/'+filename + '_All_DfDGbyns.png')          : shutil.copyfile(folder+'/'+filename + '_All_DfDGbyns.png'          ,Cor.CurrWD+'/tmp/All_DfDGbyns.png')
    if os.path.isfile(folder+'/'+filename + '_Simulated_Dfcbyn.qt2')      : shutil.copyfile(folder+'/'+filename + '_Simulated_Dfcbyn.qt2'      ,Cor.CurrWD+'/tmp/Simulated_Dfcbyn.qt2')
    if os.path.isfile(folder+'/'+filename + '_Experimental_Dfcbyn.qt2')   : shutil.copyfile(folder+'/'+filename + '_Experimental_Dfcbyn.qt2'   ,Cor.CurrWD+'/tmp/Experimental_Dfcbyn.qt2')
    if os.path.isfile(folder+'/'+filename + '_SourceFile.qt2')            : shutil.copyfile(folder+'/'+filename + '_SourceFile.qt2'            ,Cor.CurrWD+'/tmp/SourceFile.qt2')
    if os.path.isfile(folder+'/'+filename + '_ConfLims.qt2')              : shutil.copyfile(folder+'/'+filename + '_ConfLims.qt2'              ,Cor.CurrWD+'/tmp/ConfLims.qt2')
    if os.path.isfile(folder+'/'+filename + '_chi2LS_SinglePar.qt2')      : shutil.copyfile(folder+'/'+filename + '_chi2LS_SinglePar.qt2'      ,Cor.CurrWD+'/tmp/chi2LS_SinglePar.qt2')
    if os.path.isfile(folder+'/'+filename + '_chi2LS_SinglePar.png')      : shutil.copyfile(folder+'/'+filename + '_chi2LS_SinglePar.png'      ,Cor.CurrWD+'/tmp/chi2LS_SinglePar.png')
    if os.path.isfile(folder+'/'+filename + '_chi2LS_AllPars.qt2')        : shutil.copyfile(folder+'/'+filename + '_chi2LS_AllPars.qt2'        ,Cor.CurrWD+'/tmp/chi2LS_AllPars.qt2')
    if os.path.isfile(folder+'/'+filename + '_chi2LS_AllPars.png')        : shutil.copyfile(folder+'/'+filename + '_chi2LS_AllPars.png'        ,Cor.CurrWD+'/tmp/chi2LS_AllPars.png')   
    if os.path.isfile(folder+'/'+filename + '_Bootstrap_Correlations.png'): shutil.copyfile(folder+'/'+filename + '_Bootstrap_Correlations.png',Cor.CurrWD+'/tmp/Bootstrap_Correlations.png')   
    if os.path.isfile(folder+'/'+filename + '_Bootstrap_Histograms.png')  : shutil.copyfile(folder+'/'+filename + '_Bootstrap_Histograms.png'  ,Cor.CurrWD+'/tmp/Bootstrap_Histograms.png')   
    if os.path.isfile(folder+'/'+filename + '_RndNoise_Correlations.png') : shutil.copyfile(folder+'/'+filename + '_RndNoise_Correlations.png' ,Cor.CurrWD+'/tmp/RndNoise_Correlations.png')   
    if os.path.isfile(folder+'/'+filename + '_RndNoise_Histograms.png')   : shutil.copyfile(folder+'/'+filename + '_RndNoise_Histograms.png'   ,Cor.CurrWD+'/tmp/RndNoise_Histograms.png')   
    
    Cor.Read_Config(); Limits.Set_Defaults(); TT.Initialize(); Update_User_Interface()

def Save_As():
    SaveFilename = fd.asksaveasfilename(initialfile='test_'+ os.path.basename(Cor.TT_filename[:-4]),\
            filetypes=[("qtm file", ".qtm")])
    if SaveFilename == '' : return
    if os.path.isfile(SaveFilename+'_Master.qtm'):
        if tk.messagebox.askquestion('','Files exist, overwrite?') != 'yes': return
        
    Cor.CurrWD = os.getcwd()
    Cor.folder   = os.path.dirname( SaveFilename)
    # print('Cor.folder',Cor.folder)
    SaveFilename = os.path.basename(SaveFilename).replace('_Master.qtm','')
    Cor.filename = os.path.basename(SaveFilename)
    Update_Previous_Filenames()
    Cor.Do_SaveQuery = 'no'; Cor.Write_Config()
    PlotDfDGbyns(PlotDfDGbynsFrame)
    PlotFPars(   PlotFParsFrame)
    PlotSingle(  PlotSingleFrame)
    for Filename in os.listdir(Cor.CurrWD+'/tmp') : 
        # print(Cor.folder + '/' + SaveFilename + '_' + Filename)
        shutil.copyfile(Cor.CurrWD+'/tmp/'+Filename,\
                        Cor.folder + '/' + SaveFilename + '_' + Filename)

def Save_tmps_to_Excel():
    if Cor.ParsGood == 'yes':
        f_head, f_tail = os.path.split(Cor.TT_filename)
        f_name, f_extension = os.path.splitext(f_tail)
        now = datetime.datetime.now()
        date_time_of_fit = now.strftime("%m-%d-%Y_%H-%M-%S")
        datapoint='Error'
        datatime='Error'
        results_save_path = fd.askdirectory(title='Select Results Folder', initialdir=f_head)
        if results_save_path !="":
            Filename = Cor.CurrWD+'/tmp/LogFile.qt2'
            if os.path.isfile(Filename):
                print(Filename)
                f = open(Filename,'r'); lines = f.readlines(); f.close()
                for i in range(len(lines)) : lines[i] = lines[i].split()
                date, time = lines[len(lines)-4]
                now=date + ' ' + time
                now=now.replace(':','-')
                now=now.replace(' ','_')
                date_time_of_fit=now
                outfilename = results_save_path + '/' + f_name + '_Individual_Fits_Log_' + date_time_of_fit + '.txt'
                shutil.copyfile(Filename, outfilename)
                datapoint=lines[len(lines)-1][0]
                datatime=lines[len(lines)-1][1]
                Filename = Cor.CurrWD + '/tmp/FitPars.qt2'
                if os.path.isfile(Filename):
                    outfilename = results_save_path + '/' + f_name + '_Range_Fit_Params_' + date_time_of_fit + '.txt'                   
                    transfer_to_Excel(Filename, outfilename, 1, '','')
                Filename = Cor.CurrWD + '/tmp/FitParsConv.qt2'
                if os.path.isfile(Filename):
                    outfilename = results_save_path + '/' + f_name + '_Range_Fit_Params_Converted' + date_time_of_fit + '.txt'                   
                    transfer_to_Excel(Filename, outfilename, 1, '','')
                Filename = Cor.CurrWD +  '/tmp/Shifts.qt2'
                if os.path.isfile(outfilename):
                    outfilename = results_save_path + '/' + f_name + '_Range_Shifts_Simulation'+ date_time_of_fit +'.txt'
                    transfer_to_Excel(Filename, outfilename, 1, '','')
                Filename = Cor.CurrWD +  '/tmp/Simulated_Dfcbyn.qt2'
                if os.path.isfile(Filename):
                    outfilename = results_save_path + '/' + f_name + '_Individual_Shifts_Simulated_' + date_time_of_fit + '.txt'
                    transfer_to_Excel(Filename, outfilename, 0, datatime, datapoint)            
                Filename = Cor.CurrWD +  '/tmp/Experimental_Dfcbyn.qt2'
                if os.path.isfile(Filename):
                    outfilename = results_save_path + '/' + f_name + '_Individual_Shifts_Experimental'+ date_time_of_fit +'.txt'
                    transfer_to_Excel(Filename, outfilename, 0, datatime, datapoint)
    else: tk.messagebox.showinfo('','Perform a fit first')     
    
def transfer_to_Excel(in_file_name, out_file_name, switch, d_t, d_p):
    df = pd.read_csv(in_file_name, sep ='\t')
    df = df.replace('nan', np.nan)
    df.dropna(axis=0, how='all', inplace=True)
    df.dropna(axis=1, how='all', inplace=True)
    if not df.empty:
        if switch == 1:
            df.drop(df.columns[[0]], axis=1, inplace=True) #Drops the first column in the data frame
            df.to_csv(out_file_name, sep ='\t', index=False)
        if switch == 0:
            with open(out_file_name, 'w') as file:
                file.write('Timepoint: ' +'\t' + str(d_t) + '\t' + 'Datapoint: ' + '\t' + str(d_p) +'\n')
            df.to_csv(out_file_name, sep ='\t', index=False, mode='a')

def Clear():
    Cor.CurrWD = os.getcwd()
    Cor.Write_Config()
    Filenames = os.listdir(Cor.CurrWD+'/tmp/')
    for Filename in Filenames : 
        if Filename != 'Master.qtm' : os.remove(Cor.CurrWD+'/tmp/' + Filename)

def onCloseRefPanel():
    menubar.entryconfig('Reference State',state="normal")
    try: Ref_Panel.destroy()
    except: pass
    
def OpenRef():
    global Ref_Panel
    Ref_Panel = Toplevel(Root); 
    Ref_Panel.title("Reference State"); Ref_Panel.iconbitmap('QTM.ico'); 
    Ref_Panel.attributes('-topmost',True)
    def evaluate():
        for key in Cor.keys:
            if key != 'VEtype_lay1' and key != 'VEtype_lay2' and key != 'VEtype_lay3': 
                string = RefPars_SVs[key].get(); string.strip()
                try: Cor.RefPars[key] = np.float64(string)
                except: print(key,string)
                if Cor.RefPars[key] > Cor.LimitsMaxPars[key]: Cor.RefPars[key] = Cor.LimitsMaxPars[key]
                if Cor.RefPars[key] < Cor.LimitsMinPars[key]: Cor.RefPars[key] = Cor.LimitsMinPars[key]
        Cor.Write_Config()
        MakeRefParsFrame(RefParsFrame)
        PlotSingle(PlotSingleFrame) 

    RefParsFrame = tk.LabelFrame(Ref_Panel)
    RefParsFrame.grid(row=0,column=0,sticky='W')
    MakeRefParsFrame(RefParsFrame)
    evaluate = Ref_Panel.register(evaluate)
    Ref_Panel.bind_all("<Return>",evaluate)
    menubar.entryconfig('Reference State',state="disabled")
    Ref_Panel.protocol("WM_DELETE_WINDOW",onCloseRefPanel)

def MakeRefParsFrame(cntr):
    for widget in cntr.winfo_children(): widget.destroy()    
    global RefPars_SVs
    def enter_VEPar_e(event): 
        VEPar = event.widget.get()
        for i,VEPar_Choice in enumerate(VEPar_Choices):
            if VEPar == VEPar_Choice: Cor.RefPars['VEtype_lay1'] = i
        MakeRefParsFrame(cntr)        
    def enter_VEPar_f(event):    
        VEPar = event.widget.get()
        for i,VEPar_Choice in enumerate(VEPar_Choices):
            if VEPar == VEPar_Choice: Cor.RefPars['VEtype_lay2'] = i
        MakeRefParsFrame(cntr)        
    def enter_VEPar_b(event):    
        VEPar = event.widget.get()
        for i,VEPar_Choice in enumerate(VEPar_Choices):
            if VEPar == VEPar_Choice: Cor.RefPars['VEtype_lay3'] = i
        MakeRefParsFrame(cntr)

    VEPar_Choices = ['J\',J\'\'','G\',G\'\'','\u03B7\',\u03B7\'\'','G\',\u03B7\'',\
                     '|J|,tan(\u03B4)','|G|,tan(\u03B4)','|\u03B7|,tan(\u03B4)\u207B\u00B9']
    RefPars_SVs_List = [] 
    for key in Cor.keys:
        RefPars_SVs_List.append(tk.StringVar(cntr,np.round(Cor.RefPars[key],4)))
    RefPars_SVs = dict(zip(Cor.keys,RefPars_SVs_List))
    f_w=11

    if Cor.Show_lay1 == 'yes': 
        tk.Label(cntr,text='1'   ).grid(row=1,column=0,sticky='E')
        tk.Label(cntr,text='thickness [nm]'      ,width=f_w                         ).grid(row=0,column=1)
        tk.Entry(cntr,textvariable=RefPars_SVs['t_lay1'            ],width=f_w-1    ).grid(row=1,column=1)
        if Cor.RefPars['t_lay1'] != 0:
            tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]'                    ,width=f_w ).grid(row=0,column=3)
            tk.Label(cntr,text=Cor.VE_Labels1[Cor.RefPars['VEtype_lay1']],width=f_w ).grid(row=0,column=4)
            tk.Label(cntr,text=Cor.VE_Labels2[Cor.RefPars['VEtype_lay1']],width=f_w ).grid(row=0,column=6)
            tk.Label(cntr,text=u'\u03B2\''           ,width=f_w                     ).grid(row=0,column=8)
            tk.Label(cntr,text=u'\u03B2\'\''         ,width=f_w                     ).grid(row=0,column=10)
            tk.Label(cntr,text='Viscoelastic Par''s' ,width=f_w+1                   ).grid(row=0,column=12)
            tk.Entry(cntr,textvariable=RefPars_SVs['rho_lay1'          ],width=f_w-1).grid(row=1,column=3)
            tk.Entry(cntr,textvariable=RefPars_SVs['VEPar1_lay1'       ],width=f_w-1).grid(row=1,column=4)
            tk.Entry(cntr,textvariable=RefPars_SVs['VEPar2_lay1'       ],width=f_w-1).grid(row=1,column=6)
            tk.Entry(cntr,textvariable=RefPars_SVs['VEPar1_PLexpt_lay1'],width=f_w-1).grid(row=1,column=8)
            tk.Entry(cntr,textvariable=RefPars_SVs['VEPar2_PLexpt_lay1'],width=f_w-1).grid(row=1,column=10)
            VEPar_cb_1 = tk.ttk.Combobox(cntr,width=f_w-1,textvariable=RefPars_SVs['VEtype_lay1'],values=VEPar_Choices)
            VEPar_cb_1.grid(row=1,column=12)
            VEPar_cb_1.current(Cor.RefPars['VEtype_lay1'])
            VEPar_cb_1.bind("<<ComboboxSelected>>",enter_VEPar_e)

    if Cor.Show_lay2 == 'yes': 
        tk.Label(cntr,text='2'   ).grid(row=3,column=0,sticky='E')
        tk.Label(cntr,text='thickness [nm]'      ,width=f_w                         ).grid(row=2,column=1)
        tk.Entry(cntr,textvariable=RefPars_SVs['t_lay2'            ],width=f_w-1    ).grid(row=3,column=1)
        if Cor.RefPars['t_lay2'] != 0:
            tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]',width=f_w                     ).grid(row=2,column=3)
            tk.Label(cntr,text=Cor.VE_Labels1[Cor.RefPars['VEtype_lay2']],width=f_w ).grid(row=2,column=4)
            tk.Label(cntr,text=Cor.VE_Labels2[Cor.RefPars['VEtype_lay2']],width=f_w ).grid(row=2,column=6)
            tk.Label(cntr,text=u'\u03B2\'',       width=f_w                         ).grid(row=2,column=8)
            tk.Label(cntr,text=u'\u03B2\'\'',     width=f_w                         ).grid(row=2,column=10)
            tk.Label(cntr,text='Viscoelastic Par''s',width=f_w+1                    ).grid(row=2,column=12)
            tk.Entry(cntr,textvariable=RefPars_SVs['rho_lay2'          ],width=f_w-1).grid(row=3,column=3)
            tk.Entry(cntr,textvariable=RefPars_SVs['VEPar1_lay2'       ],width=f_w-1).grid(row=3,column=4)
            tk.Entry(cntr,textvariable=RefPars_SVs['VEPar2_lay2'       ],width=f_w-1).grid(row=3,column=6)
            tk.Entry(cntr,textvariable=RefPars_SVs['VEPar1_PLexpt_lay2'],width=f_w-1).grid(row=3,column=8)
            tk.Entry(cntr,textvariable=RefPars_SVs['VEPar2_PLexpt_lay2'],width=f_w-1).grid(row=3,column=10)
        
            VEPar_cb_2 = tk.ttk.Combobox(cntr,width=f_w-1,textvariable=RefPars_SVs['VEtype_lay2'],values=VEPar_Choices)
            VEPar_cb_2.grid(row=3,column=12)
            VEPar_cb_2.current(Cor.RefPars['VEtype_lay2'])
            VEPar_cb_2.bind("<<ComboboxSelected>>",enter_VEPar_f)
        
    if Cor.Show_bulk == 'yes': 
        tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]'                   ,width=f_w  ).grid(row=4,column=3)
        tk.Entry(cntr,textvariable=RefPars_SVs['rho_lay3'          ],width=f_w-1).grid(row=5,column=3)
        if Cor.RefPars['rho_lay3'] > 1e-9:
            tk.Label(cntr,text=Cor.VE_Labels1[Cor.RefPars['VEtype_lay3']],width=f_w  ).grid(row=4,column=4)
            tk.Label(cntr,text=Cor.VE_Labels2[Cor.RefPars['VEtype_lay3']],width=f_w  ).grid(row=4,column=6)
            tk.Label(cntr,text=u'\u03B2\''                               ,width=f_w  ).grid(row=4,column=8)
            tk.Label(cntr,text=u'\u03B2\'\''                             ,width=f_w  ).grid(row=4,column=10)
            tk.Label(cntr,text='Viscoelastic Par''s'                     ,width=f_w+1).grid(row=4,column=12)
            tk.Entry(cntr,textvariable=RefPars_SVs['VEPar1_lay3'       ] ,width=f_w-1).grid(row=5,column=4)
            tk.Entry(cntr,textvariable=RefPars_SVs['VEPar2_lay3'       ] ,width=f_w-1).grid(row=5,column=6)
            tk.Entry(cntr,textvariable=RefPars_SVs['VEPar1_PLexpt_lay3'] ,width=f_w-1).grid(row=5,column=8)
            tk.Entry(cntr,textvariable=RefPars_SVs['VEPar2_PLexpt_lay3'] ,width=f_w-1).grid(row=5,column=10)
            tk.Entry(cntr,textvariable=RefPars_SVs['VertScaleR'        ] ,width=f_w-1).grid(row=1,column=13)
            tk.Entry(cntr,textvariable=RefPars_SVs['AspRat'            ] ,width=f_w-1).grid(row=3,column=13)
            VEPar_cb_b = tk.ttk.Combobox(cntr,width=f_w-1,textvariable=RefPars_SVs['VEtype_lay3'],values=VEPar_Choices)
            VEPar_cb_b.grid(row=5,column=12)
            VEPar_cb_b.current(Cor.RefPars['VEtype_lay3'])
            VEPar_cb_b.bind("<<ComboboxSelected>>",enter_VEPar_b)
            tk.Label(cntr,text='Roughn [nm]'                            ,width=f_w+5).grid(row=0,column=13)
            tk.Label(cntr,text='Aspect Ratio'                           ,width=f_w+5).grid(row=2,column=13)
            tk.Label(cntr,text='bulk').grid(row=5,column=0,sticky='E')

def MakeInfoFrame(cntr):
    for widget in cntr.winfo_children(): widget.destroy()
    InfoString_SV = tk.StringVar(cntr,Cor.InfoString)
    def Enter_Info(event,WhichStuffStr):
        if WhichStuffStr == 'InfoString':
            string = InfoString_SV.get(); string.strip()
            try: 
                Cor.Do_SaveQuery = 'yes'; Cor.InfoString = string; Cor.Write_Config()
                PlotDfDGbyns(PlotDfDGbynsFrame)
                PlotFPars(   PlotFParsFrame)
                PlotSingle(  PlotSingleFrame)
            except: pass 
    tk.Label(cntr,text='Info',width=8).grid(row=0,column=0,sticky='E')
    InfoString_Entry = tk.Entry(cntr,textvariable=InfoString_SV,width=38)
    InfoString_Entry.grid(row=0,column=1,sticky='W')
    InfoString_Entry.bind('<Return>',lambda event: Enter_Info(event,'InfoString'))

def Make_Menu():
    global menubar
    menubar = tk.Menu(Root); Root.config(menu=menubar) 
    file_menu = tk.Menu(menubar)
    menubar.add_cascade(label='File',menu=file_menu)
    file_menu.add_command(label='New' ,command=NewFile)
    file_menu.add_command(label='Open',command=OpenFile)
    sub_menu = tk.Menu(file_menu,tearoff=0)
    sub_menu.add_command(label=Cor.Previous_Filenames[0],command=lambda: OpenPrevious(0))
    sub_menu.add_command(label=Cor.Previous_Filenames[1],command=lambda: OpenPrevious(1))
    sub_menu.add_command(label=Cor.Previous_Filenames[2],command=lambda: OpenPrevious(2))
    sub_menu.add_command(label=Cor.Previous_Filenames[3],command=lambda: OpenPrevious(3))
    sub_menu.add_command(label=Cor.Previous_Filenames[4],command=lambda: OpenPrevious(4))
    sub_menu.add_command(label=Cor.Previous_Filenames[5],command=lambda: OpenPrevious(5))
    sub_menu.add_command(label=Cor.Previous_Filenames[6],command=lambda: OpenPrevious(6))
    sub_menu.add_command(label=Cor.Previous_Filenames[7],command=lambda: OpenPrevious(7))
    sub_menu.add_command(label=Cor.Previous_Filenames[8],command=lambda: OpenPrevious(8))
    sub_menu.add_command(label=Cor.Previous_Filenames[9],command=lambda: OpenPrevious(9))
    file_menu.add_cascade(label='Open recent',menu = sub_menu)
    # file_menu.add_command(label='Save'                ,command=Save)
    file_menu.add_command(label='Save as...'          ,command=Save_As)
    file_menu.add_command(label='Export Fit Parameters & Simulation Data',command=Save_tmps_to_Excel)
    menubar.add_command(label='Reference State'       ,command=OpenRef)
    menubar.add_command(label='Limits'                ,command=openLimits)
    menubar.add_command(label='\u03c7\u00b2 Landscape',command=openchi2_Landscape)
    menubar.add_command(label='Bootstrapping'         ,command=openBootstrap)
    menubar.add_command(label='Random Noise'          ,command=openRndNoise)
    menubar.add_command(label='Fuzzy Interface'       ,command=openFuzzyInterface)
    menubar.add_command(label='About'                 ,command=AboutMessage)

def Update_User_Interface():
    MakeSampleParsFrame(SampleParsFrame)
    MakeFitFrame(    FitFrame)
    MakeDfcbynsFrame(DfcbynsFrame)
    MakeTT_IOFrame(  TT_IOFrame)
    MakeConvertFrame(ConvertFrame)
    MakeInfoFrame(   InfoFrame)
    PlotDfDGbyns(PlotDfDGbynsFrame)
    PlotSingle(  PlotSingleFrame)
    PlotFPars(   PlotFParsFrame)
    Root.title('PyQTM:    ' + os.path.basename(Cor.filename) + '   /   ' + os.path.basename(Cor.TT_filename))

def onClose():
    if Cor.Do_SaveQuery == 'yes':
        answer = tk.messagebox.askyesnocancel('','Save current work?')
        if answer == None : return
        if answer == True    : Save_As()
    try: FuzzyInterface.FuzzyInterfaceRoot.destroy() 
    except: pass
    try: chi2_Landscape.chi2_LandscapeRoot.destroy() 
    except: pass
    try: Bootstrap.BootstrapRoot.destroy()
    except: pass
    try: RndNoise.RndNoiseRoot.destroy()
    except: pass
    try: Limits.LimitsRoot.destroy()
    except: pass
    try: Root.destroy()
    except: pass

def onConfigure(event):
    Cor.WindowWidth  = Root.winfo_width()
    Cor.WindowHeight = Root.winfo_height()
    Cor.WindowTop    = Root.winfo_y()
    Cor.WindowLeft   = Root.winfo_x()
    Cor.Write_Config()

Cor.Read_QTM_cfg(); Cor.Get_Labels(); Cor.Read_Config(); Limits.Set_Defaults(); 
Cor.Initialize_Val_arrays()
Cor.CurrWD = os.getcwd()

TT.Initialize() 
Cor.ParsGood = 'no'; Cor.Do_SaveQuery = 'no'; Cor.Write_Config()
Root = tk.Tk()
Cor.WindowHeight += 20  # otherwise the window shrinks every time the program is closed
mydpi = Root.winfo_fpixels('1i')
# users may change the numbers below to make the window fit better to their screen 
FParPlotWidth    = 3.0
FParPlotHeight   = 5.05
DfDGPlotWidth    = 3.3
DfDGPlotHeight   = 3.6
SinglePlotWidth  = 2.5
SinglePlotHeight = 2.0

string_for_size =  str(Cor.WindowWidth)+'x'+\
                   str(Cor.WindowHeight)+'+'+\
                   str(Cor.WindowLeft)+'+'+\
                   str(Cor.WindowTop)
Root.geometry(string_for_size)
Root.protocol("WM_DELETE_WINDOW",onClose)
Root.iconbitmap("QTM.ico")
Root.bind('<Configure>',onConfigure)

SampleParsFrame   = tk.LabelFrame(Root, text='Model'         ,foreground= 'maroon'); SampleParsFrame.grid(  row=0,column=0,columnspan=3,sticky='NW')
DfcbynsFrame      = tk.LabelFrame(Root, text='Point'         ,foreground= 'maroon'); DfcbynsFrame.grid(     row=1,column=0,rowspan=2,   sticky='NW')
TT_IOFrame        = tk.LabelFrame(Root, text='Import'        ,foreground= 'maroon'); TT_IOFrame.grid(       row=3,column=0,             sticky='NW')
StartupFrame      = tk.LabelFrame(Root                       ,foreground= 'maroon'); StartupFrame.grid(     row=4,column=0,             sticky='NW')
PlotSingleFrame   = tk.LabelFrame(Root, text='Point Plot'    ,foreground= 'maroon'); PlotSingleFrame.grid(  row=1,column=1,             sticky='NW')
FitFrame          = tk.LabelFrame(Root, text='Fit'           ,foreground= 'maroon'); FitFrame.grid(         row=2,column=1,rowspan=2,   sticky='NW')
PlotDfDGbynsFrame = tk.LabelFrame(Root, text='Series Plot'   ,foreground= 'maroon'); PlotDfDGbynsFrame.grid(row=1,column=2,rowspan=3,   sticky='NW')
PlotFParsFrame    = tk.LabelFrame(Root, text='Fit Parameters',foreground= 'maroon'); PlotFParsFrame.grid(   row=0,column=3,rowspan=4,   sticky='NW')
ConvertFrame      = tk.LabelFrame(Root                       ,foreground= 'maroon'); ConvertFrame.grid(     row=4,column=3,             sticky='NW')
InfoFrame         = tk.LabelFrame(Root                       ,foreground= 'maroon'); InfoFrame.grid(        row=4,column=1,             sticky='NW')

Make_Menu()
if (Cor.Start_from == 'Start_from_Default'): NewFile()
else: Update_User_Interface()

Root.mainloop()
