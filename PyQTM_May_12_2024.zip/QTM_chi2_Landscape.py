import numpy as np
import tkinter as tk
from tkinter import ttk
import QTM_Core as Cor
import QTM_TT_IO as TT
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg,NavigationToolbar2Tk)
import os
from tkinter import filedialog as fd
import datetime
import pandas as pd
import shutil

def Check_Limits():
    if Cor.chi2LS_min  < Cor.LimitsMinPars[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]]:
        Cor.chi2LS_min = Cor.LimitsMinPars[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]]
    if Cor.chi2LS_max  > Cor.LimitsMaxPars[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]]:
        Cor.chi2LS_max = Cor.LimitsMaxPars[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]]
    Cor.Write_Config()

def MakeFrame1(cntr):
    global Par_Varied_keys
    def Enter_Stuff_chi2(event,WhichStuffStr):
        if WhichStuffStr == 'chi2LS_min': 
            string = chi2LS_min_SV.get(); string.strip()
            try: 
                Cor.chi2LS_min = float(string)
                Cor.Write_Config()
                Check_Limits(); MakeFrame1(Frame1)
            except: pass    
        if WhichStuffStr == 'chi2LS_max': 
            string = chi2LS_max_SV.get(); string.strip()
            try: 
                Cor.chi2LS_max = float(string)
                Cor.Write_Config()
                Check_Limits(); MakeFrame1(Frame1)
            except: pass    

    def enter_Par_Varied(event):
        Par_Varied = event.widget.get()
        for i,Par_Varied_Label in enumerate(Par_Varied_Labels):
            if Par_Varied == Par_Varied_Label: Cor.chi2LS_i_Par_Varied = i
        Check_Limits()
        Cor.Write_Config()

    Par_Varied_Labels = []; Par_Varied_keys = []
    for key in Cor.keys: 
        if Cor.IncPars[key] == 1:
            Par_Varied_Labels.append(TT.header_Labels[key])
            Par_Varied_keys.append(key)
            
    tk.Button(cntr,text ='Run One',command=lambda: Vary_Par()).grid(row=0,column=0,sticky='W')
    chi2LS_min_SV = tk.StringVar(cntr,Cor.chi2LS_min)
    chi2LS_max_SV = tk.StringVar(cntr,Cor.chi2LS_max)
    tk.Label(cntr,text='Min' ).grid(row=0,column=1,sticky='E')
    chi2LS_min_Entry = tk.Entry(cntr,width=6,textvariable = chi2LS_min_SV)
    chi2LS_min_Entry.grid(row=0,column=2,sticky='W')
    chi2LS_min_Entry.bind('<Return>',lambda event: Enter_Stuff_chi2(event,'chi2LS_min'))
    tk.Label(cntr,text='Max' ).grid(row=0,column=3,sticky='E')
    chi2LS_max_Entry = tk.Entry(cntr,width=6,textvariable = chi2LS_max_SV)
    chi2LS_max_Entry.grid(row=0,column=4,sticky='W')
    chi2LS_max_Entry.bind('<Return>',lambda event: Enter_Stuff_chi2(event,'chi2LS_max'))
    
    Par_Varied_cb = ttk.Combobox(cntr,state='readonly',width=22,\
        textvariable=Par_Varied_Labels[Cor.chi2LS_i_Par_Varied],values = Par_Varied_Labels) 
    Par_Varied_cb.current(Cor.chi2LS_i_Par_Varied)
    Par_Varied_cb.grid(row=1,column=0,columnspan=4,sticky='W')
    Par_Varied_cb.bind('<<ComboboxSelected>>', enter_Par_Varied)
    tk.Button(cntr,text ='Export',command=lambda: ExportSingle()).grid(row=1,column=4,sticky='W')

def MakeFrame1b(cntr):
    def Enter_Stuff_chi2(event,WhichStuffStr):
        if WhichStuffStr == 'chi2LS_Fac': 
            string = chi2LS_Fac_SV.get(); string.strip()
            try: 
                Cor.chi2LS_Fac = float(string)
                Cor.Write_Config()
                Check_Limits(); MakeFrame1b(Frame1b)
            except: pass    
    chi2LS_Fac_SV = tk.StringVar(cntr,Cor.chi2LS_Fac)
    chi2LS_Fac_Label = tk.Label(cntr,text='Width Factor' )
    chi2LS_Fac_Label.grid(row=0,column=1,sticky='E')
    chi2LS_Fac_Entry = tk.Entry(cntr,width=6,textvariable = chi2LS_Fac_SV)
    chi2LS_Fac_Entry.grid(row=0,column=2,sticky='W')
    chi2LS_Fac_Entry.bind('<Return>',lambda event: Enter_Stuff_chi2(event,'chi2LS_Fac'))
    tk.Button(cntr,text ='Run All',command=lambda: Vary_All()).grid(row=0,column=0,sticky='W')
    tk.Button(cntr,text ='Export',command=lambda: ExportAll()).grid(row=0,column=3,sticky='W')

def Vary_All():
    global Pars_all, chi2s_all
    chi2_LandscapeRoot.config(cursor='watch')
    Par_Varied_keys = []
    for key in Cor.keys: 
        if Cor.IncPars[key] == 1: Par_Varied_keys.append(key)
    Cor.Fit() 
    centers = Cor.FittedVals
    LimLows = np.ones(len(centers))*np.nan
    LimUps = np.ones(len(centers))*np.nan
    for iFPar in range(Cor.nFPars):
        if centers[iFPar] > 0: 
            LimLows[iFPar] = centers[iFPar]/Cor.chi2LS_Fac
            LimUps[iFPar]  = centers[iFPar]*Cor.chi2LS_Fac
        if centers[iFPar] < 0: 
            LimLows[iFPar] = centers[iFPar]*Cor.chi2LS_Fac
            LimUps[iFPar]  = centers[iFPar]/Cor.chi2LS_Fac
        if 'exp' in Par_Varied_keys[iFPar]: 
            LimLows[iFPar] = Cor.LimitsMinPars[Par_Varied_keys[iFPar]]
            LimUps[iFPar ] = Cor.LimitsMaxPars[Par_Varied_keys[iFPar]]
    Pars_all  = np.ones((Cor.nFPars,Cor.chi2LS_n))*np.nan
    chi2s_all = np.ones((Cor.nFPars,Cor.chi2LS_n))*np.nan
    i_Par_Varied_old = Cor.chi2LS_i_Par_Varied
    for iFPar in range(Cor.nFPars):
        for key in Cor.keys: Cor.SamplePars_old[key] = Cor.SamplePars[key]    
        if 'exp' in Par_Varied_keys[iFPar]: 
            Pars_all[iFPar] =  np.linspace(LimLows[iFPar],LimUps[iFPar],num=Cor.chi2LS_n)
        if not 'exp' in Par_Varied_keys[iFPar] and centers[iFPar] > 0: 
            Pars_all[iFPar] =  np.logspace(np.log10( LimLows[iFPar]),\
                                           np.log10( LimUps[ iFPar]),num=Cor.chi2LS_n)
        if not 'exp' in Par_Varied_keys[iFPar] and centers[iFPar] < 0: 
            Pars_all[iFPar] = -np.logspace(np.log10(-LimLows[iFPar]),\
                                           np.log10(-LimUps[ iFPar]),num=Cor.chi2LS_n)
        Cor.chi2LS_i_Par_Varied = iFPar            
        IncPar_old = Cor.IncPars[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]]
        Cor.IncPars[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]] = 0
        Cor.nFPars = 0 
        for key in Cor.keys: Cor.nFPars += Cor.IncPars[key]
        Cor.Write_Config()
        VEPars_arr = np.ones((Cor.chi2LS_n,Cor.nFPars))*np.nan
        chi2LS_arr = np.ones( Cor.chi2LS_n)*np.nan
        
        for it, Par_Varied in enumerate(Pars_all[iFPar]):
            Cor.SamplePars[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]] = Par_Varied
            Cor.Write_Config()
            Cor.Fit()
            VEPars_arr[it] = Cor.FittedVals
            Cor.FitVals_to_SamplePars(Cor.FittedVals)
            Cor.Calc_chi2(); chi2LS_arr[it] = Cor.chi2
        chi2s_all[iFPar] = chi2LS_arr
        Cor.IncPars[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]] = IncPar_old 
        Cor.nFPars = 0 
        for key in Cor.keys: Cor.nFPars += Cor.IncPars[key]
        for key in Cor.keys: Cor.SamplePars[key] = Cor.SamplePars_old[key]    
        Cor.chi2LS_i_Par_Varied = i_Par_Varied_old
        Cor.Write_Config()
    Plot_All_chi2s(Frame2)
    chi2_LandscapeRoot.config(cursor='')

def Vary_Par():
    global Par_Varied_arr,VEPars_arr,chi2LS_arr
    chi2_LandscapeRoot.config(cursor='watch')
    for key in Cor.keys: Cor.SamplePars_old[key] = Cor.SamplePars[key]    
    if Cor.chi2LS_min > 1e-9: 
        Par_Varied_arr = np.logspace(np.log10(Cor.chi2LS_min),np.log10(Cor.chi2LS_max),num=Cor.chi2LS_n)
    else:     
        Par_Varied_arr = np.linspace(         Cor.chi2LS_min ,         Cor.chi2LS_max ,num=Cor.chi2LS_n)
    IncPar_old = Cor.IncPars[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]]
    Cor.IncPars[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]] = 0
    Cor.nFPars = 0 
    for key in Cor.keys: Cor.nFPars += Cor.IncPars[key]
    Cor.Write_Config()
    VEPars_arr = np.ones((len(Par_Varied_arr),Cor.nFPars))*np.nan
    chi2LS_arr = np.ones((len(Par_Varied_arr)))*np.nan
    
    for it, Par_Varied in enumerate(Par_Varied_arr):
        Cor.SamplePars[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]] = Par_Varied
        # if it%10 == 0: print('Varies',Par_Varied_keys[Cor.chi2LS_i_Par_Varied], it,'/',len(Par_Varied_arr),Par_Varied)
        Cor.Write_Config()
        Cor.Fit()
        VEPars_arr[it] = Cor.FittedVals
        Cor.FitVals_to_SamplePars(Cor.FittedVals)
        Cor.Calc_chi2(); chi2LS_arr[it] = Cor.chi2

    Plot_Pars_chi2(Frame2)
    Cor.IncPars[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]] = IncPar_old 
    Cor.nFPars = 0 
    for key in Cor.keys: Cor.nFPars += Cor.IncPars[key]
    for key in Cor.keys: Cor.SamplePars[key] = Cor.SamplePars_old[key]   
    Cor.Fit()
    Cor.Write_Config()
    chi2_LandscapeRoot.config(cursor='')

def Plot_Pars_chi2(cntr):
    for widget in cntr.winfo_children(): widget.destroy()    
    fig = Figure(figsize = (6.,5.5),dpi = 100)
    nPloty = int((Cor.nFPars+1)**0.5)+1
    nPlotx = Cor.nFPars//nPloty + 1
    for iFPar in range(Cor.nFPars):
        axis = fig.add_subplot(nPloty,nPlotx,1+iFPar)
        axis.xaxis.label.set_fontsize(7)
        axis.yaxis.label.set_fontsize(7)
        axis.tick_params(labelsize=7,direction='in')
        axis.plot(Par_Varied_arr,VEPars_arr[:,iFPar])
        if np.min(Par_Varied_arr) > 1e-9: axis.set_xscale('log')
        else                            : axis.set_xscale('linear')
        count = 0
        for key in Cor.keys:
            if Cor.IncPars[key] == 1: 
                if iFPar == count: axis.set_ylabel(TT.Graph_TT_Labels[key],fontsize=7)
                count += 1 
        axis.tick_params(direction='in')
        axis.set_xlabel(TT.Graph_TT_Labels[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]],fontsize=7)
    axis = fig.add_subplot(nPloty,nPlotx,Cor.nFPars+1)
    axis.plot(Par_Varied_arr,chi2LS_arr[:])
    if np.min(Par_Varied_arr) > 0: axis.set_xscale('log')
    else: axis.set_xscale('linear')
    axis.set_yscale('log')
    axis.set_xlabel(TT.Graph_TT_Labels[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]],fontsize=7)
    axis.set_ylabel('$\chi^{2}$',fontsize=7)
    axis.tick_params(labelsize = 6,direction='in')
    
    suptitletext = ''
    if len(Cor.InfoString) > 0: suptitletext += Cor.InfoString
    if Cor.TT_IO_Format == 'from_QSoft_new': 
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:45] + ' chan ' + str(Cor.i_channel+1)
    else:  
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:55]
    fig.suptitle(suptitletext,fontsize = 8)

    fig.tight_layout(); fig.savefig(os.getcwd()+'/tmp/chi2LS_SinglePar.png')    
    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); canvas.get_tk_widget().pack()
    toolbar = NavigationToolbar2Tk(canvas,cntr); toolbar.update(); canvas.get_tk_widget().pack()

    TT.Get_Labels_TT_header()
    header = TT.header_Labels[Par_Varied_keys[Cor.chi2LS_i_Par_Varied]] + '\t'
    for iFPar in range(Cor.nFPars):
        count = 0
        for key in Cor.keys:
            if Cor.IncPars[key] == 1: 
                if iFPar == count: header += TT.header_Labels[key] + '\t'
                count += 1 
    header += 'chi^2 \t'
    data = [Par_Varied_arr]
    for iFPar in range(Cor.nFPars):
        data = np.append(data,[VEPars_arr[:,iFPar]],axis = 0)
    data = np.append(data,[chi2LS_arr[:]],axis = 0)
    np.savetxt(os.getcwd()+'/tmp/chi2LS_SinglePar.qt2', np.transpose(data),header = header,delimiter = '\t',newline = '\n')    
    
def Plot_All_chi2s(cntr):
    for widget in cntr.winfo_children(): widget.destroy()    
    fig = Figure(figsize = (6.,5.5),dpi = 90)
    
    nPloty = int(Cor.nFPars**0.5)+1
    nPlotx = Cor.nFPars//nPloty + 1
    for iFPar in range(Cor.nFPars):
        axis = fig.add_subplot(nPloty,nPlotx,1+iFPar)
        axis.plot(Pars_all[iFPar],chi2s_all[iFPar])
        if np.min(Pars_all[iFPar]) > 1e-9: axis.set_xscale('log')
        else                             : axis.set_xscale('linear')
        axis.tick_params(labelsize = 6,direction='in')
        axis.set_yscale('log')
        axis.set_xlabel(TT.Graph_TT_Labels[Par_Varied_keys[iFPar]],fontsize=9)
        axis.set_ylabel('$\chi^{2}$',fontsize=9)
        
    suptitletext = ''
    if len(Cor.InfoString) > 0: suptitletext += Cor.InfoString
    if Cor.TT_IO_Format == 'from_QSoft_new': 
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:45] + ' chan ' + str(Cor.i_channel+1)
    else:  
        suptitletext +=  '\n' + os.path.basename(Cor.TT_filename)[:55]
    fig.suptitle(suptitletext,fontsize = 8)
        
    fig.tight_layout(); fig.savefig(os.getcwd()+'/tmp/chi2LS_AllPars.png')    
    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); canvas.get_tk_widget().pack()
    toolbar = NavigationToolbar2Tk(canvas,cntr); toolbar.update(); canvas.get_tk_widget().pack()

    TT.Get_Labels_TT_header()
    header = ''
    data = np.ones((2*Cor.nFPars,Cor.chi2LS_n))*np.nan
    for iFPar in range(Cor.nFPars):
        count = 0
        for key in Cor.keys:
            if Cor.IncPars[key] == 1: 
                if iFPar == count: header += TT.header_Labels[key] + '\t chi^2 \t'
                count += 1 
        data[2*iFPar  ] = Pars_all[ iFPar] 
        data[2*iFPar+1] = chi2s_all[iFPar] 
    np.savetxt(os.getcwd()+'/tmp/chi2LS_AllPars.qt2', np.transpose(data),header = header,delimiter = '\t')    

def chi2_Landscape_Start():
    if Cor.nFPars < 1 :
        tk.messagebox.showinfo('','not enough active fit parameters'); return
    global Frame1,Frame1b,Frame2,chi2_LandscapeRoot
    chi2_LandscapeRoot = tk.Tk(); chi2_LandscapeRoot.title('\u03c7\u00b2 Landscape')
    Cor.chi2LS_i_Par_Varied = 0; Cor.Write_Config()
    Frame1  = tk.LabelFrame(chi2_LandscapeRoot); Frame1.grid( row=0,column=0,columnspan=1,sticky = 'NW'); MakeFrame1(Frame1)
    Frame1b = tk.LabelFrame(chi2_LandscapeRoot); Frame1b.grid(row=0,column=1,columnspan=1,sticky = 'NW'); MakeFrame1b(Frame1b)
    Frame2  = tk.LabelFrame(chi2_LandscapeRoot); Frame2.grid( row=1,column=0,columnspan=3,sticky = 'NW') 
    chi2_LandscapeRoot.iconbitmap("QTM.ico")
    chi2_LandscapeRoot.mainloop()
    
def transfer_to_Excel(in_file_name, out_file_name):
    df = pd.read_csv(in_file_name, sep ='\t')
    df = df.replace('nan', np.nan)
    df.dropna(axis=0, how='all', inplace=True)
    df.dropna(axis=1, how='all', inplace=True)
    if not df.empty :
        df.to_csv(out_file_name, sep ='\t', index=False)

def ExportSingle():
    ExportFilename = fd.asksaveasfilename(initialfile='test_'+ os.path.basename(Cor.TT_filename[:-4]),\
            filetypes=[("qtm file", ".qtm")])
    if ExportFilename == '' : return
    Folder          = os.path.dirname( ExportFilename)
    ExportFilename2 = os.path.basename(ExportFilename).replace('_Master','')
    ExportFilename2 = ExportFilename2.replace('.qtm','')

    Cor.CurrWD = os.getcwd()
    if os.path.isfile(  os.getcwd()+'/tmp/chi2LS_SinglePar.qt2'):
        shutil.copyfile(os.getcwd()+'/tmp/chi2LS_SinglePar.qt2',\
                        Folder + '/' + ExportFilename2 + '_' + 'chi2LS_SinglePar.qt2')
    
def ExportAll():
    ExportFilename = fd.asksaveasfilename(initialfile='test_'+ os.path.basename(Cor.TT_filename[:-4]),\
            filetypes=[("qtm file", ".qtm")])
    if ExportFilename == '' : return
    Folder          = os.path.dirname( ExportFilename)
    ExportFilename2 = os.path.basename(ExportFilename).replace('_Master','')
    ExportFilename2 = ExportFilename2.replace('.qtm','')

    Cor.CurrWD = os.getcwd()
    if os.path.isfile(  os.getcwd()+'/tmp/chi2LS_AllPars.qt2'):
        shutil.copyfile(os.getcwd()+'/tmp/chi2LS_AllPars.qt2',\
                        Folder + '/' + ExportFilename2 + '_' + 'chi2LS_AllPars.qt2')
    

    
    