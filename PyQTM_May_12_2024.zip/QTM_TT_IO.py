import numpy as np
import QTM_Core as Cor
import os
import tkinter as tk
import pandas as pd
import shutil

def Get_Labels_TT_header(): 
    global Graph_TT_Labels,header_Labels
    Graph_TT_Labels = dict(zip(Cor.keys,''))
    header_Labels   = dict(zip(Cor.keys,''))

    Graph_TT_Labels['t_lay1'] = '$t_{1}$ [nm]'
    Graph_TT_Labels['t_lay2'] = '$t_{2}$ [nm]'
    Graph_TT_Labels['rho_lay3'] = '$\rho_{1}$ [g/cm$^{3}]$'
    Graph_TT_Labels['rho_lay1'] = '$\rho_{2}$ [g/cm$^{3}]$'
    Graph_TT_Labels['rho_lay1'] = '$\rho_{bulk}$ [g/cm$^{3}]$'
    Graph_TT_Labels['VEPar1_PLexpt_lay1'] = '$\\beta^{\prime}_{1}$'
    Graph_TT_Labels['VEPar2_PLexpt_lay1'] = '$\\beta^{\prime\prime}_{1}$'
    Graph_TT_Labels['VEPar1_PLexpt_lay2'] = '$\\beta^{\prime}_{2}$'
    Graph_TT_Labels['VEPar2_PLexpt_lay2'] = '$\\beta^{\prime\prime}_{2}$'
    Graph_TT_Labels['VEPar1_PLexpt_lay3'] = '$\\beta^{\prime}_{bulk}$'
    Graph_TT_Labels['VEPar2_PLexpt_lay3'] = '$\\beta^{\prime\prime}_{bulk}$'
    Graph_TT_Labels['VertScaleR'] = '$h_{r}$ [nm]'
    Graph_TT_Labels['AspRat'] = 'aspect ratio'

    header_Labels['t_lay1'] = 'thickness_1[nm]'
    header_Labels['t_lay2'] = 'thickness_2[nm]'
    header_Labels['rho_lay3'] = 'rho_1[g/cm^3]'
    header_Labels['rho_lay1'] = 'rho_2[g/cm^3]'
    header_Labels['rho_lay3'] = 'rho_bulk[g/cm^3]'
    header_Labels['VertScaleR'] = 'roughn_vert_scale[nm]'
    header_Labels['AspRat'] = 'AspectRatio'
    header_Labels['VEPar1_PLexpt_lay1'] = 'beta\'_1'
    header_Labels['VEPar2_PLexpt_lay1'] = 'beta\'\'_1'
    header_Labels['VEPar1_PLexpt_lay2'] = 'beta\'_2'
    header_Labels['VEPar2_PLexpt_lay2'] = 'beta\'\'_2'
    header_Labels['VEPar1_PLexpt_lay3'] = 'beta\'_3'
    header_Labels['VEPar2_PLexpt_lay3'] = 'beta\'\'_3'

    if Cor.SamplePars['VEtype_lay1'] == 0 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$J^{\prime}_{1}$ [MPa$^{-1}$]'  
        Graph_TT_Labels['VEPar2_lay1'] = '$J^{\prime\prime}_{1}$ [MPa$^{-1}$]'
        header_Labels['VEPar1_lay1']   = 'J\'_1[MPa^-1]'  
        header_Labels['VEPar2_lay1']   = 'J\'\'_1[MPa^-1]'
    if Cor.SamplePars['VEtype_lay1'] == 1 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$G^{\prime}_{1}$ [MPa]'  
        Graph_TT_Labels['VEPar2_lay1'] = '$G^{\prime\prime}_{1}$ [MPa]'  
        header_Labels['VEPar1_lay1']   = 'G\'_1[MPa]'  
        header_Labels['VEPar2_lay1']   = 'G\'\'_1[MPa]'  
    if Cor.SamplePars['VEtype_lay1'] == 2 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$\eta^{\prime}_{1}$ [mPa s]'  
        Graph_TT_Labels['VEPar2_lay1'] = '$\eta^{\prime\prime}_{1}$ [mPa s]'  
        header_Labels['VEPar1_lay1']   = 'eta\'_1[mPa_s]'  
        header_Labels['VEPar2_lay1']   = 'eta\'\'_1[mPa_s]'  
    if Cor.SamplePars['VEtype_lay1'] == 3 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$G^{\prime}_{1}$ [MPa]'  
        Graph_TT_Labels['VEPar2_lay1'] = '$\eta^{\prime}_{1}$ [mPa s]' 
        header_Labels['VEPar1_lay1']   = 'G\'_1[MPa]'  
        header_Labels['VEPar2_lay1']   = 'eta\'_1[mPa_s]' 
    if Cor.SamplePars['VEtype_lay1'] == 4 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$|J_{1}|$ [MPa$^{-1}$]'  
        Graph_TT_Labels['VEPar2_lay1'] = 'tan $\delta_{1}$'  
        header_Labels['VEPar1_lay1']   = '|J_1|[MPa^-1]'  
        header_Labels['VEPar2_lay1']   = 'tan_delta_1'  
    if Cor.SamplePars['VEtype_lay1'] == 5 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$|G_{1}$| [MPa]' 
        Graph_TT_Labels['VEPar2_lay1'] = 'tan $\delta_{1}$'  
        header_Labels['VEPar1_lay1']   = '|G_1|[MPa]' 
        header_Labels['VEPar2_lay1']   = 'tan_delta_1'  
    if Cor.SamplePars['VEtype_lay1'] == 6 : 
        Graph_TT_Labels['VEPar1_lay1'] = '$|\eta_{1}$| [mPa s]'
        Graph_TT_Labels['VEPar2_lay1'] = '(tan $\delta_{1}$)$^{-1}$'
        header_Labels['VEPar1_lay1']   = '|eta_1|_[mPa_s]'
        header_Labels['VEPar2_lay1']   = '(tan_delta_1)^-1'
    if Cor.SamplePars['VEtype_lay2'] == 0 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$J^{\prime}_{2}$ [MPa$^{-1}$]'  
        Graph_TT_Labels['VEPar2_lay2'] = '$J^{\prime\prime}_{2}$ [MPa$^{-1}$]'
        header_Labels['VEPar1_lay2']   = 'J\'_2[MPa^-1]'  
        header_Labels['VEPar2_lay2']   = 'J\'\'_2[MPa^-1]'
    if Cor.SamplePars['VEtype_lay2'] == 1 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$G^{\prime}_{2}$ [MPa]'  
        Graph_TT_Labels['VEPar2_lay2'] = '$G^{\prime\prime}_{2}$ [MPa]'  
        header_Labels['VEPar1_lay2'] = 'G\'_2 MPa]'  
        header_Labels['VEPar2_lay2'] = 'G\'\'_2[MPa]'  
    if Cor.SamplePars['VEtype_lay2'] == 2 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$\eta^{\prime}_{2}$ [mPa s]'  
        Graph_TT_Labels['VEPar2_lay2'] = '$\eta^{\prime\prime}_{2}$ [mPa s]'  
        header_Labels['VEPar1_lay2']   = 'eta\'_2[mPa_s]'  
        header_Labels['VEPar2_lay2']   = 'eta\'\'_2[mPa_s]'  
    if Cor.SamplePars['VEtype_lay2'] == 3 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$G^{\prime}_{2}$ [MPa]'  
        Graph_TT_Labels['VEPar2_lay2'] = '$\eta^{\prime}_{2}$ [mPa s]' 
        header_Labels['VEPar1_lay2']   = 'G\'_2[MPa]'  
        header_Labels['VEPar2_lay2']   = 'eta\'_2[mPa_s]' 
    if Cor.SamplePars['VEtype_lay2'] == 4 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$|J_{2}|$ [MPa$^{-1}$]'  
        Graph_TT_Labels['VEPar2_lay2'] = 'tan $\delta_{2}$'  
        header_Labels['VEPar1_lay2']   = '|J_2| [MPa^-1]'  
        header_Labels['VEPar2_lay2']   = 'tan_delta_2'  
    if Cor.SamplePars['VEtype_lay2'] == 5 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$|G_{2}$| [MPa]' 
        Graph_TT_Labels['VEPar2_lay2'] = 'tan $\delta_{2}$'  
        header_Labels['VEPar1_lay2'] = '|G_2|_[MPa]' 
        header_Labels['VEPar2_lay2'] = 'tan_delta_2'  
    if Cor.SamplePars['VEtype_lay2'] == 6 : 
        Graph_TT_Labels['VEPar1_lay2'] = '$|\eta_{2}$| [mPa s]'
        Graph_TT_Labels['VEPar2_lay2'] = '(tan $\delta_{2}$)$^{-1}$'
        header_Labels['VEPar1_lay2']   = '|eta_2| [mPa_s]'
        header_Labels['VEPar2_lay2']   = '(tan_delta_2)^-1'

    if Cor.SamplePars['VEtype_lay3'] == 0 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$J^{\prime}_{bulk}$ [MPa$^{-1}$]'  
        Graph_TT_Labels['VEPar2_lay3'] = '$J^{\prime\prime}_{bulk}$ [MPa$^{-1}$]'
        header_Labels['VEPar1_lay3']   = 'J\'_bulk[MPa^-1]'  
        header_Labels['VEPar2_lay3']   = 'J\'\'_bulk[MPa^-1]'
    if Cor.SamplePars['VEtype_lay3'] == 1 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$G^{\prime}_{bulk}$ [MPa]'  
        Graph_TT_Labels['VEPar2_lay3'] = '$G^{\prime\prime}_{bulk}$ [MPa]'  
        header_Labels['VEPar1_lay3']   = 'G\'_bulk[MPa]'  
        header_Labels['VEPar2_lay3']   = 'G\'\'_bulk[MPa]'  
    if Cor.SamplePars['VEtype_lay3'] == 2 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$\eta^{\prime}_{bulk}$ [mPa s]'  
        Graph_TT_Labels['VEPar2_lay3'] = '$\eta^{\prime\prime}_{bulk}$ [mPa s]'  
        header_Labels['VEPar1_lay3']   = 'eta\'_bulk[mPa_s]'  
        header_Labels['VEPar2_lay3']   = 'eta\'\'_bulk_[mPa_s]'  
    if Cor.SamplePars['VEtype_lay3'] == 3 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$G^{\prime}_{bulk}$ [MPa]'  
        Graph_TT_Labels['VEPar2_lay3'] = '$\eta^{\prime}_{bulk}$ [mPa s]' 
        header_Labels['VEPar1_lay3']   = 'G\'_bulk[MPa]'  
        header_Labels['VEPar2_lay3']   = 'eta\'_bulk[mPa_s]' 
    if Cor.SamplePars['VEtype_lay3'] == 4 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$|J_{bulk}|$ [MPa$^{-1}$]'  
        Graph_TT_Labels['VEPar2_lay3'] = 'tan $\delta_{bulk}$'  
        header_Labels['VEPar1_lay3']   = '|J_bulk|[MPa^-1]'  
        header_Labels['VEPar2_lay3']   = 'tan_delta_bulk'  
    if Cor.SamplePars['VEtype_lay3'] == 5 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$|G_{bulk}$| [MPa]' 
        Graph_TT_Labels['VEPar2_lay3'] = 'tan $\delta_{bulk}$'  
        header_Labels['VEPar1_lay3']   = '|G_bulk|[MPa]' 
        header_Labels['VEPar2_lay3']   = 'tan_delta_bulk'  
    if Cor.SamplePars['VEtype_lay3'] == 6 : 
        Graph_TT_Labels['VEPar1_lay3'] = '$|\eta_{bulk}$| [mPa s]'
        Graph_TT_Labels['VEPar2_lay3'] = '(tan $\delta_{bulk}$)$^{-1}$'
        header_Labels['VEPar1_lay3']   = '|eta_bulk|[mPa_s]'
        header_Labels['VEPar2_lay3']   = '(tan_delta_bulk)^-1'

def Get_Labels_TTConv_header(): 
    global Graph_TTConv_Labels,headerConv_Labels
    Graph_TTConv_Labels = dict(zip(Cor.keys,''))
    headerConv_Labels   = dict(zip(Cor.keys,''))
    Graph_TTConv_Labels['t_lay1'] = '$t_{1}$ [nm]'
    Graph_TTConv_Labels['t_lay2'] = '$t_{2}$ [nm]'
    Graph_TTConv_Labels['rho_lay3'] = '$\rho_{1}$ [g/cm$^{3}]$'
    Graph_TTConv_Labels['rho_lay1'] = '$\rho_{2}$ [g/cm$^{3}]$'
    Graph_TTConv_Labels['rho_lay1'] = '$\rho_{bulk}$ [g/cm$^{3}]$'
    Graph_TTConv_Labels['VEPar1_PLexpt_lay1'] = '$\\beta^{\prime}_{1}$'
    Graph_TTConv_Labels['VEPar2_PLexpt_lay1'] = '$\\beta^{\prime\prime}_{1}$'
    Graph_TTConv_Labels['VEPar1_PLexpt_lay2'] = '$\\beta^{\prime}_{2}$'
    Graph_TTConv_Labels['VEPar2_PLexpt_lay2'] = '$\\beta^{\prime\prime}_{2}$'
    Graph_TTConv_Labels['VEPar1_PLexpt_lay3'] = '$\\beta^{\prime}_{bulk}$'
    Graph_TTConv_Labels['VEPar2_PLexpt_lay3'] = '$\\beta^{\prime\prime}_{bulk}$'
    Graph_TTConv_Labels['VertScaleR'] = '$h_{r}$ [nm]'
    Graph_TTConv_Labels['AspRat'] = 'aspect ratio'

    headerConv_Labels['t_lay1'] = 'thickness_1[nm]'
    headerConv_Labels['t_lay2'] = 'thickness_2[nm]'
    headerConv_Labels['rho_lay3'] = 'rho_1[g/cm^3]'
    headerConv_Labels['rho_lay1'] = 'rho_2[g/cm^3]'
    headerConv_Labels['rho_lay3'] = 'rho_bulk[g/cm^3]'
    headerConv_Labels['VertScaleR'] = 'roughn_vert_scale[nm]'
    headerConv_Labels['AspRat'] = 'AspectRatio'
    headerConv_Labels['VEPar1_PLexpt_lay1'] = 'beta\'_1'
    headerConv_Labels['VEPar2_PLexpt_lay1'] = 'beta\'\'_1'
    headerConv_Labels['VEPar1_PLexpt_lay2'] = 'beta\'_2'
    headerConv_Labels['VEPar2_PLexpt_lay2'] = 'beta\'\'_2'
    headerConv_Labels['VEPar1_PLexpt_lay3'] = 'beta\'_3'
    headerConv_Labels['VEPar2_PLexpt_lay3'] = 'beta\'\'_3'

    if Cor.VEPar_Conv == 0 : 
        Graph_TTConv_Labels['VEPar1_lay1'] = '$J^{\prime}_{1}$ [MPa$^{-1}$]'  
        Graph_TTConv_Labels['VEPar2_lay1'] = '$J^{\prime\prime}_{1}$ [MPa$^{-1}$]'
        headerConv_Labels['VEPar1_lay1']   = 'J\'_1[MPa^-1]'  
        headerConv_Labels['VEPar2_lay1']   = 'J\'\'_1[MPa^-1]'
    if Cor.VEPar_Conv == 1 : 
        Graph_TTConv_Labels['VEPar1_lay1'] = '$G^{\prime}_{1}$ [MPa]'  
        Graph_TTConv_Labels['VEPar2_lay1'] = '$G^{\prime\prime}_{1}$ [MPa]'  
        headerConv_Labels['VEPar1_lay1']   = 'G\'_1[MPa]'  
        headerConv_Labels['VEPar2_lay1']   = 'G\'\'_1[MPa]'  
    if Cor.VEPar_Conv == 2 : 
        Graph_TTConv_Labels['VEPar1_lay1'] = '$\eta^{\prime}_{1}$ [mPa s]'  
        Graph_TTConv_Labels['VEPar2_lay1'] = '$\eta^{\prime\prime}_{1}$ [mPa s]'  
        headerConv_Labels['VEPar1_lay1']   = 'eta\'_1[mPa_s]'  
        headerConv_Labels['VEPar2_lay1']   = 'eta\'\'_1[mPa_s]'  
    if Cor.VEPar_Conv == 3 : 
        Graph_TTConv_Labels['VEPar1_lay1'] = '$G^{\prime}_{1}$ [MPa]'  
        Graph_TTConv_Labels['VEPar2_lay1'] = '$\eta^{\prime}_{1}$ [mPa s]' 
        headerConv_Labels['VEPar1_lay1']   = 'G\'_1[MPa]'  
        headerConv_Labels['VEPar2_lay1']   = 'eta\'_1[mPa_s]' 
    if Cor.VEPar_Conv == 4 : 
        Graph_TTConv_Labels['VEPar1_lay1'] = '$|J_{1}|$ [MPa$^{-1}$]'  
        Graph_TTConv_Labels['VEPar2_lay1'] = 'tan $\delta_{1}$'  
        headerConv_Labels['VEPar1_lay1']   = '|J_1|[MPa^-1]'  
        headerConv_Labels['VEPar2_lay1']   = 'tan_delta_1'  
    if Cor.VEPar_Conv == 5 : 
        Graph_TTConv_Labels['VEPar1_lay1'] = '$|G_{1}$| [MPa]' 
        Graph_TTConv_Labels['VEPar2_lay1'] = 'tan $\delta_{1}$'  
        headerConv_Labels['VEPar1_lay1']   = '|G_1|[MPa]' 
        headerConv_Labels['VEPar2_lay1']   = 'tan_delta_1'  
    if Cor.VEPar_Conv == 6 : 
        Graph_TTConv_Labels['VEPar1_lay1'] = '$|\eta_{1}$| [mPa s]'
        Graph_TTConv_Labels['VEPar2_lay1'] = '(tan $\delta_{1}$)$^{-1}$'
        headerConv_Labels['VEPar1_lay1']   = '|eta_1|_[mPa_s]'
        headerConv_Labels['VEPar2_lay1']   = '(tan_delta_1)^-1'
    if Cor.VEPar_Conv == 0 : 
        Graph_TTConv_Labels['VEPar1_lay2'] = '$J^{\prime}_{2}$ [MPa$^{-1}$]'  
        Graph_TTConv_Labels['VEPar2_lay2'] = '$J^{\prime\prime}_{2}$ [MPa$^{-1}$]'
        headerConv_Labels['VEPar1_lay2']   = 'J\'_2[MPa^-1]'  
        headerConv_Labels['VEPar2_lay2']   = 'J\'\'_2[MPa^-1]'
    if Cor.VEPar_Conv == 1 : 
        Graph_TTConv_Labels['VEPar1_lay2'] = '$G^{\prime}_{2}$ [MPa]'  
        Graph_TTConv_Labels['VEPar2_lay2'] = '$G^{\prime\prime}_{2}$ [MPa]'  
        headerConv_Labels['VEPar1_lay2'] = 'G\'_2 MPa]'  
        headerConv_Labels['VEPar2_lay2'] = 'G\'\'_2[MPa]'  
    if Cor.VEPar_Conv == 2 : 
        Graph_TTConv_Labels['VEPar1_lay2'] = '$\eta^{\prime}_{2}$ [mPa s]'  
        Graph_TTConv_Labels['VEPar2_lay2'] = '$\eta^{\prime\prime}_{2}$ [mPa s]'  
        headerConv_Labels['VEPar1_lay2']   = 'eta\'_2[mPa_s]'  
        headerConv_Labels['VEPar2_lay2']   = 'eta\'\'_2[mPa_s]'  
    if Cor.VEPar_Conv == 3 : 
        Graph_TTConv_Labels['VEPar1_lay2'] = '$G^{\prime}_{2}$ [MPa]'  
        Graph_TTConv_Labels['VEPar2_lay2'] = '$\eta^{\prime}_{2}$ [mPa s]' 
        headerConv_Labels['VEPar1_lay2']   = 'G\'_2[MPa]'  
        headerConv_Labels['VEPar2_lay2']   = 'eta\'_2[mPa_s]' 
    if Cor.VEPar_Conv == 4 : 
        Graph_TTConv_Labels['VEPar1_lay2'] = '$|J_{2}|$ [MPa$^{-1}$]'  
        Graph_TTConv_Labels['VEPar2_lay2'] = 'tan $\delta_{2}$'  
        headerConv_Labels['VEPar1_lay2']   = '|J_2| [MPa^-1]'  
        headerConv_Labels['VEPar2_lay2']   = 'tan_delta_2'  
    if Cor.VEPar_Conv == 5 : 
        Graph_TTConv_Labels['VEPar1_lay2'] = '$|G_{2}$| [MPa]' 
        Graph_TTConv_Labels['VEPar2_lay2'] = 'tan $\delta_{2}$'  
        headerConv_Labels['VEPar1_lay2'] = '|G_2|_[MPa]' 
        headerConv_Labels['VEPar2_lay2'] = 'tan_delta_2'  
    if Cor.VEPar_Conv == 6 : 
        Graph_TTConv_Labels['VEPar1_lay2'] = '$|\eta_{2}$| [mPa s]'
        Graph_TTConv_Labels['VEPar2_lay2'] = '(tan $\delta_{2}$)$^{-1}$'
        headerConv_Labels['VEPar1_lay2']   = '|eta_2| [mPa_s]'
        headerConv_Labels['VEPar2_lay2']   = '(tan_delta_2)^-1'

    if Cor.VEPar_Conv == 0 : 
        Graph_TTConv_Labels['VEPar1_lay3'] = '$J^{\prime}_{bulk}$ [MPa$^{-1}$]'  
        Graph_TTConv_Labels['VEPar2_lay3'] = '$J^{\prime\prime}_{bulk}$ [MPa$^{-1}$]'
        headerConv_Labels['VEPar1_lay3']   = 'J\'_bulk[MPa^-1]'  
        headerConv_Labels['VEPar2_lay3']   = 'J\'\'_bulk[MPa^-1]'
    if Cor.VEPar_Conv == 1 : 
        Graph_TTConv_Labels['VEPar1_lay3'] = '$G^{\prime}_{bulk}$ [MPa]'  
        Graph_TTConv_Labels['VEPar2_lay3'] = '$G^{\prime\prime}_{bulk}$ [MPa]'  
        headerConv_Labels['VEPar1_lay3']   = 'G\'_bulk[MPa]'  
        headerConv_Labels['VEPar2_lay3']   = 'G\'\'_bulk[MPa]'  
    if Cor.VEPar_Conv == 2 : 
        Graph_TTConv_Labels['VEPar1_lay3'] = '$\eta^{\prime}_{bulk}$ [mPa s]'  
        Graph_TTConv_Labels['VEPar2_lay3'] = '$\eta^{\prime\prime}_{bulk}$ [mPa s]'  
        headerConv_Labels['VEPar1_lay3']   = 'eta\'_bulk[mPa_s]'  
        headerConv_Labels['VEPar2_lay3']   = 'eta\'\'_bulk_[mPa_s]'  
    if Cor.VEPar_Conv == 3 : 
        Graph_TTConv_Labels['VEPar1_lay3'] = '$G^{\prime}_{bulk}$ [MPa]'  
        Graph_TTConv_Labels['VEPar2_lay3'] = '$\eta^{\prime}_{bulk}$ [mPa s]' 
        headerConv_Labels['VEPar1_lay3']   = 'G\'_bulk[MPa]'  
        headerConv_Labels['VEPar2_lay3']   = 'eta\'_bulk[mPa_s]' 
    if Cor.VEPar_Conv == 4 : 
        Graph_TTConv_Labels['VEPar1_lay3'] = '$|J_{bulk}|$ [MPa$^{-1}$]'  
        Graph_TTConv_Labels['VEPar2_lay3'] = 'tan $\delta_{bulk}$'  
        headerConv_Labels['VEPar1_lay3']   = '|J_bulk|[MPa^-1]'  
        headerConv_Labels['VEPar2_lay3']   = 'tan_delta_bulk'  
    if Cor.VEPar_Conv == 5 : 
        Graph_TTConv_Labels['VEPar1_lay3'] = '$|G_{bulk}$| [MPa]' 
        Graph_TTConv_Labels['VEPar2_lay3'] = 'tan $\delta_{bulk}$'  
        headerConv_Labels['VEPar1_lay3']   = '|G_bulk|[MPa]' 
        headerConv_Labels['VEPar2_lay3']   = 'tan_delta_bulk'  
    if Cor.VEPar_Conv == 6 : 
        Graph_TTConv_Labels['VEPar1_lay3'] = '$|\eta_{bulk}$| [mPa s]'
        Graph_TTConv_Labels['VEPar2_lay3'] = '(tan $\delta_{bulk}$)$^{-1}$'
        headerConv_Labels['VEPar1_lay3']   = '|eta_bulk|[mPa_s]'
        headerConv_Labels['VEPar2_lay3']   = '(tan_delta_bulk)^-1'

def Get_FParnames(): 
    global FParnames 
    FParnames = []
    for key in Cor.keys:
        if Cor.IncPars[key] == 1:
            name = header_Labels[key].replace('[','_')
            name = name.replace(']','')
            name = name.replace('\'','p')
            name = name.replace('|','')
            name = name.replace('(','')
            name = name.replace(')','')
            name = name.replace('^','')
            name = name.replace('-','_m')
            name = name.replace(' ','')
            FParnames.append(name)

def FPars_String():
    FPars_String = ''; iFPar = 0
    for key in Cor.keys:
        if Cor.IncPars[key] == 1:
            FPars_String += header_Labels[key] + ' '
            iFPar += 1
    return FPars_String 

def Analyze_header_line_QTZ(line):
    global Do_Import,i_cols
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms = ['df_1.','df_3.','df_5.','df_7.','df_9.','df_11.','df_13.']
    count = 0
    i_cols = np.zeros((Cor.novt),dtype=int)
    for iovt in range(Cor.novt):
        if SearchTerms[iovt] in line: 
            Do_Import[iovt] = 1
            i_cols[iovt] = 1 + 2 * count
            count += 1

def Analyze_header_line_OpenQCM(line):
    global Do_Import,i_cols
    line.split('\t')
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms = ['Frequency_0',
                   'Frequency_1',
                   'Frequency_2',
                   'Frequency_3',
                   'Frequency_4',
                   'Frequency_5',
                   'Frequency_6']
    count = 0
    i_cols = np.zeros((Cor.novt),dtype=int)
    line_splits = line.split(',')
    for iovt in range(Cor.novt):
        for icol_split,line_split in enumerate(line_splits):
            if SearchTerms[iovt] in line_split: 
                Do_Import[iovt] = 1
                i_cols[iovt] = icol_split
                count += 1

def Analyze_header_line_QCMI(line):
    global Do_Import,i_cols
    line.split('\t')
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms = ['Fundamental Frequency Variation',
                   ' 3. Overtone Variation',
                   '5. Overtone Variation',
                   '7. Overtone Variation',
                   '9. Overtone Variation',
                   '11. Overtone Variation',
                   '13. Overtone Variation']
    count = 0
    i_cols = np.zeros((Cor.novt),dtype=int)
    line_splits = line.split('\t')
    for iovt in range(Cor.novt):
        for icol_split,line_split in enumerate(line_splits):
            if SearchTerms[iovt] in line_split: 
                Do_Import[iovt] = 1
                i_cols[iovt] = icol_split
                count += 1

def Analyze_header_line_QSoft(line):
    global Do_Import,i_cols
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms1 = ['F_1:1\t','F_1:3','F_1:5','F_1:7','F_1:9','F_1:11','F_1:13']
    SearchTerms2 = ['F_2:1\t','F_2:3','F_2:5','F_2:7','F_2:9','F_2:11','F_2:13']
    SearchTerms3 = ['F_3:1\t','F_3:3','F_3:5','F_3:7','F_3:9','F_3:11','F_3:13']
    SearchTerms4 = ['F_4:1\t','F_4:3','F_4:5','F_4:7','F_4:9','F_4:11','F_4:13']
    Do_Import = np.zeros(Cor.novt,dtype = int)
    count = 0
    i_cols = np.ones((Cor.novt),dtype = int)*np.nan
    for iovt in range(Cor.novt):
        if SearchTerms1[iovt] in line or SearchTerms2[iovt] in line or \
           SearchTerms3[iovt] in line or SearchTerms4[iovt] in line:
            Do_Import[iovt] = 1
            i_cols[iovt] = 1 + 2 * count
            count += 1
    i_cols = i_cols.astype(int)

def Analyze_header_line_QSoft_new(line):
    global Do_Import_new,i_cols_new,i_cols_time
    i_cols_new  = np.ones((4,Cor.novt),dtype = int)*np.nan
    i_cols_time = np.ones((4),dtype = int)*np.nan
    Do_Import_new = np.zeros((4,Cor.novt),dtype = int)
    n_tones = np.zeros((4),dtype = int)
    SearchTerms = np.array([['f1_1','f3_1','f5_1','f7_1','f9_1','f11_1','f13_1'],\
                            ['f1_2','f3_2','f5_2','f7_2','f9_2','f11_2','f13_2'],
                            ['f1_3','f3_3','f5_3','f7_3','f9_3','f11_3','f13_3'],
                            ['f1_4','f3_4','f5_4','f7_4','f9_4','f11_4','f13_4']])
    for ichan in range(4):
        for iovt in range(Cor.novt):
            if SearchTerms[ichan,iovt] in line: Do_Import_new[ichan,iovt] = 1
    n_tones = np.sum(Do_Import_new,axis = 1)
    count = 0 
    for ichan in range(4):
        if n_tones[ichan] > 0:
            i_cols_time[ichan] = count
            for iovt in range(Cor.novt):
                i_cols_new[ichan,iovt] = count + 1 + 2 * np.sum(Do_Import_new[ichan,:iovt])
            count += 2 * n_tones[ichan] + 1
    i_cols_new  = i_cols_new.astype(int)        
    i_cols_time = i_cols_time.astype(int)
    choice_str = ''
    for j in range(4): 
        if np.sum(Do_Import_new[j,:]) > 0: choice_str += str(j+1) + ' '
    if np.sum(Do_Import_new[Cor.i_channel,:]) == 0: 
        Cor.i_channel = tk.simpledialog.askinteger('','select channel (' + choice_str + ')') - 1

def Analyze_header_line_AWSensors(line):
    global Do_Import,i_cols
    Do_Import = np.zeros(Cor.novt,dtype = int)
    SearchTerms = ['Delta_F/n_n=1_','Delta_F/n_n=3_',\
                   'Delta_F/n_n=5_','Delta_F/n_n=7_',\
                   'Delta_F/n_n=9_','Delta_F/n_n=11_','Delta_F/n_n=13_']
    count = 0
    i_cols = np.ones((Cor.novt),dtype = int)*np.nan
    for iovt in range(Cor.novt):
        if SearchTerms[iovt] in line: 
            Do_Import[iovt] = 1
            i_cols[iovt] = 1 + count
            count += 1
    i_cols = i_cols.astype(int)        

def Import_from_QTZ():
    global time_TT_in,Dfbyn_TT_in,DGbyn_TT_in
    f = open(Cor.TT_filename,"r"); lines = f.readlines(); f.close()
    Analyze_header_line_QTZ(lines[0])    
    time_TT_in  = np.ones(len( lines)          )*np.nan
    Dfbyn_TT_in = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_TT_in = np.ones((len(lines),Cor.novt))*np.nan
    n_tones = np.sum(Do_Import)
    count = 0
    for il in range(1,len(lines)):
        cols = lines[il].split()
        Line_long_enough = len(cols) >= 2 * n_tones + 1
        if Line_long_enough:
            time_TT_in[count] = float(cols[0])
            for iovt in range(Cor.novt):
                if Do_Import[iovt]: 
                    Dfbyn_TT_in[count,iovt] = float(cols[i_cols[iovt]    ])/Cor.n_arr[iovt]
                    DGbyn_TT_in[count,iovt] = float(cols[i_cols[iovt] + 1])/Cor.n_arr[iovt]
            count += 1
    time_TT_in  = time_TT_in[:count]
    Dfbyn_TT_in = Dfbyn_TT_in[:count]
    DGbyn_TT_in = DGbyn_TT_in[:count]
    
def Import_from_QCMI():
    global time_TT_in,Dfbyn_TT_in,DGbyn_TT_in
    f = open(Cor.TT_filename,"r"); lines = f.readlines(); f.close()
    Analyze_header_line_QCMI(lines[0])    
    time_TT_in  = np.ones(len( lines)          )*np.nan
    Dfbyn_TT_in = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_TT_in = np.ones((len(lines),Cor.novt))*np.nan
    n_tones = np.sum(Do_Import)
    count = 0
    for il in range(1,len(lines)):
        cols = lines[il].split()
        Line_long_enough = len(cols) >= 15 * n_tones + 1
        if Line_long_enough:
            time_TT_in[count] = float(cols[0])
            for iovt in range(Cor.novt):
                if Do_Import[iovt]: 
                    Dfbyn_TT_in[count,iovt] = float(cols[i_cols[iovt]  ])/Cor.n_arr[iovt]
                    DGbyn_TT_in[count,iovt] = float(cols[i_cols[iovt]+1])/Cor.n_arr[iovt]/2.
        count += 1
    time_TT_in  = time_TT_in[:count]
    Dfbyn_TT_in = Dfbyn_TT_in[:count]
    DGbyn_TT_in = DGbyn_TT_in[:count]

def Import_from_QSoft():
    global time_TT_in,Dfbyn_TT_in,DGbyn_TT_in
    f = open(Cor.TT_filename,"r"); lines = f.readlines(); f.close()
    Analyze_header_line_QSoft(lines[0])    
    time_TT_in  = np.ones( len(lines)          )*np.nan
    Dfbyn_TT_in = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_TT_in = np.ones((len(lines),Cor.novt))*np.nan
    n_tones = np.sum(Do_Import)
    count = 0 
    for il in range(1,len(lines)):
        line = lines[il].replace(',','.')
        cols = line.split()
        Line_long_enough = len(cols) >= 2 * n_tones + 1
        if Line_long_enough: 
            time_TT_in[count] = float(cols[0])
            for iovt in range(Cor.novt):
                if Do_Import[iovt]: 
                    Dfbyn_TT_in[count,iovt] = float(cols[i_cols[iovt]    ])                    
                    DGbyn_TT_in[count,iovt] = float(cols[i_cols[iovt] + 1]) * Cor.f_fund/2./1e6
            count += 1
    time_TT_in  = time_TT_in[ :count]
    Dfbyn_TT_in = Dfbyn_TT_in[:count]
    DGbyn_TT_in = DGbyn_TT_in[:count]

def Import_from_QSoft_new():
    global time_TT_in,Dfbyn_TT_in,DGbyn_TT_in
    f = open(Cor.TT_filename,"r"); lines = f.readlines(); f.close()
    Analyze_header_line_QSoft_new(lines[0])    
    time_TT_in  = np.ones( len(lines)          )*np.nan
    Dfbyn_TT_in = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_TT_in = np.ones((len(lines),Cor.novt))*np.nan
    count = 0
    for il in range(1,len(lines)):
        line = lines[il].replace(',','.')
        cols = line.split()
        if i_cols_time[Cor.i_channel] <= len(cols)-1:
            time_TT_in[count] = float(cols[i_cols_time[Cor.i_channel]])
            for iovt in range(Cor.novt):
                if Do_Import_new[Cor.i_channel,iovt]: 
                    Dfbyn_TT_in[count,iovt] = float(cols[i_cols_new[Cor.i_channel,iovt]    ])/Cor.n_arr[iovt]  
                    DGbyn_TT_in[count,iovt] = float(cols[i_cols_new[Cor.i_channel,iovt] + 1])*Cor.f_fund/2./1e6
            count += 1
    time_TT_in  = time_TT_in[ :count]
    Dfbyn_TT_in = Dfbyn_TT_in[:count] - Dfbyn_TT_in[0]
    DGbyn_TT_in = DGbyn_TT_in[:count] - DGbyn_TT_in[0]


def Import_from_AWSensors():
    Header1 = ['Delta_F/n_n=1_(Hz)','Delta_F/n_n=3_(Hz)',\
                'Delta_F/n_n=5_(Hz)','Delta_F/n_n=7_(Hz)',\
                'Delta_F/n_n=9_(Hz)','Delta_F/n_n=11_(Hz)','Delta_F/n_n=13_(Hz)']

    Header2 = ['Delta_D_n=1_()','Delta_D_n=3_()','Delta_D_n=5_()','Delta_D_n=7_()',\
                'Delta_D_n=9_()','Delta_D_n=11_()','Delta_D_n=13_()']


    Header3 = ['Delta_Gamma/n_n=1_(Hz)','Delta_Gamma/n_n=3_(Hz)','Delta_Gamma/n_n=5_(Hz)',\
                'Delta_Gamma/n_n=7_(Hz)','Delta_Gamma/n_n=9_(Hz)','Delta_Gamma/n_n=11_(Hz)',\
                'Delta_Gamma/n_n=13_(Hz)']

    global time_TT_in,Dfbyn_TT_in,DGbyn_TT_in

    f = open(Cor.TT_filename,"r"); lines = f.readlines(); f.close()

    #This removes the % header in some of the AWsensors exported files, but doesn't touch the files that don't have such a header 
    lindex=0
    while lines[lindex][0]=='%':
        lines.pop(lindex)

    if len(lines)<2:
        tk.messagebox.showinfo('','The file is corrupt. Try re-exporting the data from AWSensors software again.')
        return
        
    #Converting lines into dataframe using the 0th line as the header
    header=lines[0].split('\t')
    df = pd.DataFrame([sub.split('\t') for sub in header]).transpose()
    lines.pop(0)
    df = pd.DataFrame([sub.split('\t') for sub in lines], columns=header)
    
    #Initializing your arrays
    length=len(df)
    time_TT_in  = np.ones( length          )*np.nan
    Dfbyn_TT_in = np.ones((length,Cor.novt))*np.nan
    DGbyn_TT_in = np.ones((length,Cor.novt))*np.nan

    #looking for the first occurrance of the time axis (depending on the typle of file, there may be more than one)
    #this should be easy to expand to other axes, like current, electrochemistry, but let's leave this for now
    df1=df.filter(like='Time')
    if not df1.empty:
        time_TT_in=df1.iloc[:,0].to_numpy(dtype=np.float64)
    else:
        #If no time data is found, return an error
        tk.messagebox.showinfo('','File format error: cannot find the time data. Try re-exporting the data from AWSensors software again.')
        return

    #These are frequencies, they are always the same in all the exported files
    df1=df.filter(Header1)
    if not df1.empty:
        for i in range(0,7):
            df1=df.filter(like=Header1[i])
            if not df1.empty:
                Dfbyn_TT_in[:,i]=df1.iloc[:,0].to_numpy(dtype=np.float64)
    else:
        #If no frequencies found, return an error
        tk.messagebox.showinfo('','File format error: cannot find the frequency data. Try re-exporting the data from AWSensors software again.')
        return

    #Looking for dissipations
    df1 = df.filter(Header2)
    if not df1.empty:
        for i in range(0,7):
            df1=df.filter(like=Header2[i])
            if not df1.empty:
                DGbyn_TT_in[:,i]=df1.iloc[:,0].to_numpy(dtype=np.float64)
                DGbyn_TT_in[:,i]=DGbyn_TT_in[:,i]*Cor.f_fund/2
    else:
        #if no dissipations are found, looking for bandwidths...
        df1 = df.filter(Header3)
        if not df1.empty:
            for i in range(0,7):
                df1=df.filter(like=Header3[i])
                if not df1.empty:
                    DGbyn_TT_in[:,i]=df1.iloc[:,0].to_numpy(dtype=np.float64)
        else:
            #if neither dissipations nor bandwidths are found, we have a problem.
            tk.messagebox.showinfo('','File format error: cannot find either the dissipation or the bandwidth data. Try re-exporting the data from AWSensors software again.')
            return
    del df, df1


def Import_from_OpenQCM():
    global time_TT_in,Dfbyn_TT_in,DGbyn_TT_in
    f = open(Cor.TT_filename,"r"); lines = f.readlines(); f.close()
    Analyze_header_line_OpenQCM(lines[0])    
    time_TT_in  = np.ones(len( lines)          )*np.nan
    Dfbyn_TT_in = np.ones((len(lines),Cor.novt))*np.nan
    DGbyn_TT_in = np.ones((len(lines),Cor.novt))*np.nan
    count = 0
    for il in range(1,len(lines)):
        cols = lines[il].split(',')
        time_TT_in[count] = float(cols[2])  # time in line 3
        novt_loc = int((len(cols)-4)/2)
        for iovt in range(novt_loc):
            if Do_Import[iovt]: 
                cols[i_cols[iovt]].replace('\n','')
                Dfbyn_TT_in[count,iovt] = float(cols[i_cols[iovt]  ])/Cor.n_arr[iovt]
                DGbyn_TT_in[count,iovt] = float(cols[i_cols[iovt]+1])/Cor.n_arr[iovt] * Cor.f_fund/2.
        count += 1
    time_TT_in  = time_TT_in[ :count]
    Dfbyn_TT_in = Dfbyn_TT_in[:count]
    DGbyn_TT_in = DGbyn_TT_in[:count]
    
def Calc_Averages():
    global time_TT,Dfbyn_TT,DGbyn_TT
    first = True
    if Cor.n_pre_avg > 1 : 
        icount = 0
        while icount < len(time_TT_in)//Cor.n_pre_avg:
            icenter  = int((icount + 0.5)*Cor.n_pre_avg)
            sumDfbyn = np.zeros(Cor.novt)
            sumDGbyn = np.zeros(Cor.novt)
            norm = 0
            for i in range(np.max([0                ,int((icount - 1)*Cor.n_pre_avg)]),\
                           np.min([len(time_TT_in)-1,int((icount + 1)*Cor.n_pre_avg)])):
                weight = np.exp(-(i-icenter)**2/(2.*(Cor.n_pre_avg/2.)**2))
                norm += weight
                for iovt in range(Cor.novt):
                    sumDfbyn[iovt] += Dfbyn_TT_in[i,iovt] * weight
                    sumDGbyn[iovt] += DGbyn_TT_in[i,iovt] * weight
            if norm > 0 : 
                for iovt in range(Cor.novt):
                    sumDfbyn[iovt] /= norm
                    sumDGbyn[iovt] /= norm
            else :     
                for iovt in range(Cor.novt):
                    sumDfbyn[iovt] = np.nan
                    sumDGbyn[iovt] = np.nan
            if first: 
                time_TT = time_TT_in[icenter]
                Dfbyn_TT = [sumDfbyn]
                DGbyn_TT = [sumDGbyn]
                first = False
            else :     
                time_TT  = np.append(time_TT ,time_TT_in[icenter])    
                Dfbyn_TT = np.append(Dfbyn_TT,[sumDfbyn],axis = 0)    
                DGbyn_TT = np.append(DGbyn_TT,[sumDGbyn],axis = 0)
            icount += 1
    else : 
        time_TT  = time_TT_in
        Dfbyn_TT = Dfbyn_TT_in
        DGbyn_TT = DGbyn_TT_in

def Import_TT():
    global DfDGbyns,TT_FPars,TT_FParsConv 
    shutil.copyfile(Cor.TT_filename,os.getcwd()+'/tmp/SourceFile.qt2')
    if Cor.TT_IO_Format in ['from_QSoft','from_QSoft_new','from_AWSensors','from_OpenQCM','from_QCM-I']:
        Cor.TimeLabel = '[sec]'; Cor.Write_Config();

    if Cor.TT_IO_Format == 'from_QTZ'      : Import_from_QTZ()
    if Cor.TT_IO_Format == 'from_QSoft'    : Import_from_QSoft()
    if Cor.TT_IO_Format == 'from_QSoft_new': Import_from_QSoft_new()
    if Cor.TT_IO_Format == 'from_AWSensors': Import_from_AWSensors()
    if Cor.TT_IO_Format == 'from_OpenQCM'  : Import_from_OpenQCM()
    if Cor.TT_IO_Format == 'from_QCM-I'    : Import_from_QCMI()
    Calc_Averages()
    DfDGbyns = np.ones((len(Dfbyn_TT),2+4*Cor.novt))*np.nan
    for it in range(len(Dfbyn_TT)):
        DfDGbyns[it,0]=it
        DfDGbyns[it,1]=time_TT[it]
        for iovt in range(Cor.novt):
            DfDGbyns[it,2+4*iovt  ] = Dfbyn_TT[it,iovt]
            DfDGbyns[it,2+4*iovt+1] = DGbyn_TT[it,iovt]

    Cor.i_selec    = 0
    Cor.i_strt_fit = 0
    Cor.i_stop_fit = len(DfDGbyns-1) - 1 
    Cor.i_current  = 0
    Cor.i_strt_hide_TT = 0; Cor.i_stop_hide_TT = 0 
    Cor.i_strt_zoom_TT = 0; Cor.i_stop_zoom_TT = len(DfDGbyns);   
    Cor.i_strt_zoom_FP = 0; Cor.i_stop_zoom_FP = len(TT_FPars); 
    for iovt in range(Cor.novt):
        Cor.Dfbyns[iovt] = DfDGbyns[Cor.i_selec,2+4*iovt  ]
        Cor.DGbyns[iovt] = DfDGbyns[Cor.i_selec,2+4*iovt+1]
    Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns
    Cor.Fit_done = 'no'
    get_rms_noise_Dfbyn()
    # if Cor.i_stop_fit > Cor.i_strt_fit + 2:  
    #     if len(DfDGbyns) > 2: get_rms_noise_Dfbyn()
    #     else                : Cor.rms = np.nan
    # else:      
    for it in range(len(DfDGbyns)):
        if DfDGbyns[it,1] == 0: DfDGbyns[it,:] = np.nan 
    if Cor.TT_Correct_Drift == 'yes': DfDGbyns = Correct_for_Drift(DfDGbyns)
    Make_headers()
    np.savetxt(os.getcwd() + '/tmp/Shifts.qt2'           ,DfDGbyns,\
        header = header_DfDGbyns,delimiter='\t',newline = '\n')
    np.savetxt(os.getcwd() + '/tmp/Shifts_for_unhide.qt2',DfDGbyns,\
        header = header_DfDGbyns,delimiter='\t',newline = '\n')
    
    TT_FPars     = np.ones((len(DfDGbyns),2+2*Cor.nFParsmax+1))*np.nan
    SingleLayer,i_layer = Cor.Determine_Layers_IncInFits()
    TT_FParsConv = np.ones((len(DfDGbyns),2+5+1))*np.nan
    np.savetxt(os.getcwd() + '/tmp/FitPars.qt2'    ,TT_FPars,\
        header = header_FPars_TimeSer    ,delimiter='\t',newline = '\n')
    np.savetxt(os.getcwd() + '/tmp/FitParsConv.qt2',TT_FPars,\
        header = header_FParsConv_TimeSer,delimiter='\t',newline = '\n')
    Cor.i_strt_hide_TT = 0; Cor.FP_i_strt_hide_TT = 0
    Cor.i_stop_hide_TT = 0; Cor.FP_i_stop_hide_TT = 0
    for iovt in range(Cor.novt): Cor.OvtInc[iovt] = 1
    Cor.Write_Config()

def Correct_for_Drift(DfDGbyns):
    DfDGbyns_DrifC = np.ones((len(Dfbyn_TT),2+4*Cor.novt))*np.nan
    DfDGbyns_DrifC[:,0] = DfDGbyns[:,0]
    DfDGbyns_DrifC[:,1] = DfDGbyns[:,1]
    for it in range(len(DfDGbyns)-1):
        count = 0
        for iovt in range(Cor.novt):
            if not np.isnan(DfDGbyns[it,2+4*iovt  ]) and not np.isnan(DfDGbyns[it+1,2+4*iovt  ]):  
                DfDGbyns_DrifC[it,2+4*iovt  ] = DfDGbyns[it,2+4*iovt  ]-count/len(Cor.ns_inc)/Cor.n_pre_avg*\
                     (DfDGbyns[it+1,2+4*iovt]-DfDGbyns[it,2+4*iovt])
            count += 1         
        count = 0
        for iovt in range(Cor.novt):
            if not np.isnan(DfDGbyns[it,2+4*iovt+1]) and not np.isnan(DfDGbyns[it+1,2+4*iovt+1]):  
                DfDGbyns_DrifC[it,2+4*iovt+1] = DfDGbyns[it,2+4*iovt+1]-count/len(Cor.ns_inc)/Cor.n_pre_avg*\
                     (DfDGbyns[it+1,2+4*iovt+1]-DfDGbyns[it,2+4*iovt+1])
            count += 1         
    DfDGbyns = DfDGbyns_DrifC
    return DfDGbyns

def get_rms_noise_Dfbyn():
    Hadamard = np.ones((Cor.novt,len(DfDGbyns)))*np.nan
    if (Cor.i_strt_fit != 0 and Cor.i_stop_fit != 0):
        strt = Cor.i_strt_fit; stop = Cor.i_stop_fit
    elif (Cor.i_strt_avrg != 0 and Cor.i_stop_avrg != 0):
        strt = Cor.i_strt_avrg; stop = Cor.i_stop_avrg
    else: 
        strt = 0; stop = len(DfDGbyns)
    for iovt in range(Cor.novt):
        if Cor.OvtInc[iovt] == 1:
            for it in range(strt+1,np.min([stop,len(DfDGbyns)])-1):
                Hadamard[iovt,it-1] = \
               1./6. *(DfDGbyns[it-1,2+4*iovt  ] - 2.* DfDGbyns[it,2+4*iovt  ] + DfDGbyns[it+1,2+4*iovt  ])**2 
    Cor.rms_noise_Dfbyn = np.nanmean(Hadamard)**0.5
        
def Make_headers():
    global header_FPars_LogFile,header_FPars_TimeSer,header_FParsConv_TimeSer,header_DfDGbyns
    header_FPars_LogFile     = 'data_point \t time[a.u.] \t'
    header_FPars_TimeSer     = 'data_point \t time[a.u.] \t'
    header_FParsConv_TimeSer = 'data_point \t time[a.u.] \t'
    header_DfDGbyns          = 'data_point \t time[a.u.] \t'
    
    for key in Cor.keys: 
        if Cor.IncPars[key] == 1:
            header_FPars_LogFile += header_Labels[key] + '\t' + header_Labels[key]+'_StdErr \t'
            header_FPars_TimeSer += header_Labels[key] + '\t' + header_Labels[key]+'_StdErr \t'
    for iFPar in range(Cor.nFPars,Cor.nFParsmax):
            header_FPars_TimeSer += 'NotFreePar \t NotFreePar_+_StdErr \t'
    SingleLayer,i_layer = Cor.Determine_Layers_IncInFits()
    if i_layer == 1:    
        for key in Cor.keys: 
            if 'lay1' in key and not 'rho' in key and not 'VEtype' in key : 
                header_FParsConv_TimeSer += header_Labels[key] + '\t' 
    if i_layer == 2:    
        for key in Cor.keys: 
            if 'lay2' in key and not 'rho' in key and not 'VEtype' in key : 
                header_FParsConv_TimeSer += header_Labels[key] + '\t'
    if i_layer == 3:    
        for key in Cor.keys: 
            if 'lay3' in key and not 'rho' in key and not 'VEtype' in key : 
                header_FParsConv_TimeSer += header_Labels[key] + '\t' 

    header_FPars_LogFile     += 'chi^2 \t'
    header_FPars_TimeSer     += 'chi^2 \t'
    header_FParsConv_TimeSer += 'chi^2 \t'
    for iovt in range(Cor.novt):
        header_DfDGbyns += 'Dfbyn_'    + str(Cor.n_arr[iovt]) + '\t' + 'DGbyn_'    + str(Cor.n_arr[iovt]) + '\t' + \
                           'Dfbyn_fit_'+ str(Cor.n_arr[iovt]) + '\t' + 'DGbyn_fit_'+ str(Cor.n_arr[iovt]) + '\t'
    
def Initialize():
    Cor.CurrWD = os.getcwd();
    global DfDGbyns,TT_FPars,TT_FParsConv
    if os.path.isfile(os.getcwd()+'/tmp/Shifts.qt2'): DfDGbyns = np.loadtxt(os.getcwd()+'/tmp/Shifts.qt2',skiprows=1)
    else                                           : DfDGbyns = np.ones((1,4*Cor.novt+3))*np.nan
    TT_FPars = np.ones((len(DfDGbyns),2+2*Cor.nFParsmax+1))*np.nan
    if os.path.isfile(    os.getcwd()+'/tmp/FitPars.qt2'): 
        data = np.loadtxt(os.getcwd()+'/tmp/FitPars.qt2',skiprows=1)
        if data.ndim == 1: data = np.array([data])
        for it in range(len(data)):
            for j in range(len(data[0])):
                try   : TT_FPars[it,j] = data[it,j]
                except: pass
    else: TT_FPars = np.ones((len(DfDGbyns),2+2*Cor.nFParsmax+1))*np.nan
    if len(TT_FPars) < len(DfDGbyns):
        TT_FPars = np.ones((len(DfDGbyns),2+2*Cor.nFParsmax+1))*np.nan
    
    TT_FParsConv = np.ones((len(DfDGbyns),2+5+1))*np.nan
    if os.path.isfile(os.getcwd()+'/tmp/FitParsConv.qt2'): 
        data = np.loadtxt(os.getcwd()+'/tmp/FitParsConv.qt2',skiprows=1)
        if data.ndim == 1: data = np.array([data])
        for it in range(len(data)):
            for j in range(len(data[0])):
                try   : TT_FParsConv[it,j] = data[it,j]
                except: pass
    else: TT_FParsConv = np.ones((len(DfDGbyns),2+2*Cor.nFParsmax+1))*np.nan
    if len(TT_FParsConv) < len(DfDGbyns):
        TT_FParsConv = np.ones((len(DfDGbyns),2+2*Cor.nFParsmax+1))*np.nan
    get_rms_noise_Dfbyn();

def Convert_TimeSeries():
    global TT_FParsConv
    Make_headers()
    SingleLayer,i_layer = Cor.Determine_Layers_IncInFits()
    TT_FParsConv = np.ones((len(TT_FPars),2+5+1))*np.nan
    VEtype_new = Cor.VEPar_Conv
    Cor.Fit()
   
    for it in range(len(TT_FPars)):
        if not np.isnan(TT_FPars[it,0]):
            for iFPar in range(Cor.nFPars):
                Cor.FittedVals[iFPar] = TT_FPars[it,2+2*iFPar]
            Cor.FitVals_to_SamplePars(Cor.FittedVals)
            if i_layer == 1: 
                VEPar1_cen_old = Cor.SamplePars['VEPar1_lay1']
                VEPar2_cen_old = Cor.SamplePars['VEPar2_lay1']
                VEPar1_PLexpt_old = Cor.SamplePars['VEPar1_PLexpt_lay1']
                VEPar2_PLexpt_old = Cor.SamplePars['VEPar2_PLexpt_lay1']
                VEtype_old = Cor.SamplePars['VEtype_lay1']
            if i_layer == 2: 
                VEPar1_cen_old = Cor.SamplePars['VEPar1_lay2']
                VEPar2_cen_old = Cor.SamplePars['VEPar2_lay2']
                VEPar1_PLexpt_old = Cor.SamplePars['VEPar1_PLexpt_lay2']
                VEPar2_PLexpt_old = Cor.SamplePars['VEPar2_PLexpt_lay2']
                VEtype_old = Cor.SamplePars['VEtype_lay2']
            if i_layer == 3: 
                VEPar1_cen_old = Cor.SamplePars['VEPar1_lay3']
                VEPar2_cen_old = Cor.SamplePars['VEPar2_lay3']
                VEPar1_PLexpt_old = Cor.SamplePars['VEPar1_PLexpt_lay3']
                VEPar2_PLexpt_old = Cor.SamplePars['VEPar2_PLexpt_lay3']
                VEtype_old = Cor.SamplePars['VEtype_lay3']
            VEPar1_cen_new,VEPar2_cen_new,VEPar1_PLexpt_new,VEPar2_PLexpt_new = \
                Cor.VEPars_Old2New(VEPar1_cen_old,VEPar2_cen_old,VEPar1_PLexpt_old,VEPar2_PLexpt_old,\
                VEtype_old,VEtype_new)
            TT_FParsConv[it,0 ] = TT_FPars[it,0]; 
            TT_FParsConv[it,1 ] = TT_FPars[it,1]; 
            TT_FParsConv[it,-1] = TT_FPars[it,-1]
            if i_layer == 1 : TT_FParsConv[it,2] = Cor.SamplePars['t_lay1']
            if i_layer == 2 : TT_FParsConv[it,2] = Cor.SamplePars['t_lay2']
            if i_layer == 3 : TT_FParsConv[it,2] = np.nan
            TT_FParsConv[it,3] = VEPar1_cen_new; 
            TT_FParsConv[it,4] = VEPar1_PLexpt_new; 
            TT_FParsConv[it,5] = VEPar2_cen_new; 
            TT_FParsConv[it,6] = VEPar2_PLexpt_new; 
        np.savetxt(os.getcwd() + '/tmp/FitParsConv.qt2',TT_FParsConv,\
            header = header_FParsConv_TimeSer,delimiter='\t',newline = '\n')
        
def Convert_Single():
    SingleLayer,i_layer = Cor.Determine_Layers_IncInFits()
    VEtype_new = Cor.VEPar_Conv
    Converted_Vals = np.ones((6))*np.nan
    Cor.FitVals_to_SamplePars(Cor.FittedVals)
    if i_layer == 1: 
        VEPar1_cen_old = Cor.SamplePars['VEPar1_lay1']
        VEPar2_cen_old = Cor.SamplePars['VEPar2_lay1']
        VEPar1_PLexpt_old = Cor.SamplePars['VEPar1_PLexpt_lay1']
        VEPar2_PLexpt_old = Cor.SamplePars['VEPar2_PLexpt_lay1']
        VEtype_old = Cor.SamplePars['VEtype_lay1']
    if i_layer == 2: 
        VEPar1_cen_old = Cor.SamplePars['VEPar1_lay2']
        VEPar2_cen_old = Cor.SamplePars['VEPar2_lay2']
        VEPar1_PLexpt_old = Cor.SamplePars['VEPar1_PLexpt_lay2']
        VEPar2_PLexpt_old = Cor.SamplePars['VEPar2_PLexpt_lay2']
        VEtype_old = Cor.SamplePars['VEtype_lay2']
    if i_layer == 3: 
        VEPar1_cen_old = Cor.SamplePars['VEPar1_lay3']
        VEPar2_cen_old = Cor.SamplePars['VEPar2_lay3']
        VEPar1_PLexpt_old = Cor.SamplePars['VEPar1_PLexpt_lay3']
        VEPar2_PLexpt_old = Cor.SamplePars['VEPar2_PLexpt_lay3']
        VEtype_old = Cor.SamplePars['VEtype_lay3']
    VEPar1_cen_new,VEPar2_cen_new,VEPar1_PLexpt_new,VEPar2_PLexpt_new = \
        Cor.VEPars_Old2New(VEPar1_cen_old,VEPar2_cen_old,VEPar1_PLexpt_old,VEPar2_PLexpt_old,\
        VEtype_old,VEtype_new)
    if i_layer == 1 : Converted_Vals[0] = Cor.SamplePars['t_lay1']        
    if i_layer == 2 : Converted_Vals[0] = Cor.SamplePars['t_lay2'] 
    if i_layer < 3 :     
        Converted_Vals[1] = VEPar1_cen_new; 
        Converted_Vals[2] = VEPar2_cen_new; 
        Converted_Vals[3] = VEPar1_PLexpt_new; 
        Converted_Vals[4] = VEPar2_PLexpt_new; 
    if i_layer == 3 :     
        Converted_Vals[0] = VEPar1_cen_new; 
        Converted_Vals[1] = VEPar2_cen_new; 
        Converted_Vals[2] = VEPar1_PLexpt_new; 
        Converted_Vals[3] = VEPar2_PLexpt_new; 
    return Converted_Vals    
        
def Calc_IncParsConv():
    SingleLayer,i_layer = Cor.Determine_Layers_IncInFits()
    IncParsConv = {}
    for key in Cor.keys: IncParsConv[key] = Cor.IncPars[key]
    sumIncParsConv = 0
    if i_layer == 1 : 
        IncParsConv['t_lay1'] = 1
        IncParsConv['VEPar1_lay1'] = 1
        IncParsConv['VEPar2_lay1'] = 1
        IncParsConv['VEPar1_PLexpt_lay1'] = 1
        IncParsConv['VEPar2_PLexpt_lay1'] = 1
        sumIncParsConv = 5
    if i_layer == 2 : 
        IncParsConv['t_lay2'] = 1
        IncParsConv['VEPar1_lay2'] = 1
        IncParsConv['VEPar2_lay2'] = 1
        IncParsConv['VEPar1_PLexpt_lay2'] = 1
        IncParsConv['VEPar2_PLexpt_lay2'] = 1
        sumIncParsConv = 5
    if i_layer == 3 : 
        IncParsConv['VEPar1_lay3'] = 1
        IncParsConv['VEPar2_lay3'] = 1
        IncParsConv['VEPar1_PLexpt_lay3'] = 1
        IncParsConv['VEPar2_PLexpt_lay3'] = 1
        sumIncParsConv = 4
    return IncParsConv,sumIncParsConv