import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

eta_bulk = 1e-3; rho_bulk = 1e3; rho_film = 1e3
Gp_surf  = 1e5; Gpp_surf = 1e4;
f_fund = 5e6; om = 2 * np.pi * f_fund; Zq = 8.8e6; n = 1
G_bulk = 1j*om*eta_bulk
G_film = Gp_surf + 1j*Gpp_surf

PointInfl = 300e-9
WidthFac = 0.3;
Width = PointInfl*WidthFac
eta_bulk_f_fund = G_bulk /(1j*2.*np.pi*f_fund)
delta_f_fund = ((2.*eta_bulk_f_fund/(rho_bulk*2.*np.pi*f_fund))**0.5).real
zmax = PointInfl*(1+3*WidthFac)+3*delta_f_fund
zs = np.linspace(0,zmax,num=100)

def profile(z):      return 1./2.*( 1.-np.tanh((z-PointInfl)/Width)) 
def profileDeriv(z): return 1./2.*(-1./np.cosh((z-PointInfl)/Width)**2/Width)
def G(zR):           return G_bulk   + (G_film  -G_bulk  )*profile(zmax-zR) #zR: reversed
def rho(zR):         return rho_bulk + (rho_film-rho_bulk)*profile(zmax-zR) 
def GDeriv(zR):      return -(G_film-G_bulk)*profileDeriv(zmax-zR) # minus: z-scale reversed

def Disp2Deriv(zR, u_uDeriv):  # u_uDeriv : velocity and its derivative
    u, uDeriv = u_uDeriv
    return [uDeriv, -rho(zR)*om**2/G(zR)*u - GDeriv(zR)/G(zR)*uDeriv]

def Solve_ODEs():
    global Disp,Dfcbyn
    k_bulk = om/(G_bulk/rho_bulk)**0.5
    u_ini = [1 + 0*1j, 1j*k_bulk] 
    sol    = solve_ivp(Disp2Deriv,[0,zmax],u_ini,t_eval=zs,method='BDF',rtol=1e-4,atol=1e-7)
    u      = sol.y / sol.y[0,-1] # normalize, so that velocity at surface is 1
    ZL     = G(zmax)*u[1,-1] / (1j * om)
    Disp = u[0]
    Dfcbyn = f_fund*1j /(np.pi*Zq) * ZL/n

def Calc_G_rho():
    global Gs,rhos
    Gs   = G_bulk   + (G_film-G_bulk)*profile(zs)
    rhos = rho_bulk + (rho_film-rho_bulk)*profile(zs)

def Plot_Vis_Disp():
    plt.subplot(2,1,1)
    om = 2.*np.pi*f_fund            
    plt.plot(zs*1e9,( Gs/(1j*om)/1e-3).real,'-' ,color='k')
    plt.plot(zs*1e9,(-Gs/(1j*om)/1e-3).imag,'--',color='k')
    plt.ylabel('$\eta$ [mPa s]')
    plt.xticks([]); 
    plt.title('$\Delta f/n$ [Hz]'        + ' : ' + str(np.round(Dfcbyn.real,3)) + '\n' +\
                 '$\Delta\Gamma/n$ [Hz]' + ' : ' + str(np.round(Dfcbyn.imag,3)))
    
    plt.subplot(2,1,2)
    plt.plot((zmax-zs)*1e9,Disp.real,'-' ,color='k')
    plt.plot((zmax-zs)*1e9,Disp.imag,'--',color='k')
    plt.xlabel('z [nm]'); plt.ylabel('Displacement')
    plt.tight_layout(); plt.show()

Calc_G_rho(); Solve_ODEs(); Plot_Vis_Disp()      
