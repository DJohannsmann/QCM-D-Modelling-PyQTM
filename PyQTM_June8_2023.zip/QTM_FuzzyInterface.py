import tkinter as tk
import numpy as np
import QTM_Core as Cor
from scipy.integrate import solve_ivp
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg)

def profile(z):      return 1./2.*(1.-np.tanh((z-PointInfl)/Width)) 
def profileDeriv(z): return 1./2.*(-1./np.cosh((z-PointInfl)/Width)**2/Width)
def G(zR):           return G_bulk   + (G_film  -G_bulk  )*profile(zmax-zR) #zR: reversed
def rho(zR):         return rho_bulk + (rho_film-rho_bulk)*profile(zmax-zR) 
def GDeriv(zR):      return -(G_film-G_bulk)*profileDeriv(zmax-zR) # minus: z-scale reversed

def Disp2Deriv(zR, u_uDeriv):  # u_uDeriv : velocity and its derivative
    u, uDeriv = u_uDeriv
    return [uDeriv, -rho(zR)*om**2/G(zR)*u - GDeriv(zR)/G(zR)*uDeriv]
def Disp2Deriv_ref(zR, u_uDeriv):  
    u, uDeriv = u_uDeriv
    return [uDeriv, -rho_bulk*om**2/G_bulk*u]

def Solve_ODEs(n):
    k_bulk = om/(G_bulk/rho_bulk)**0.5
    u_ini = [1 + 0*1j, 1j*k_bulk] 
    sol     = solve_ivp(Disp2Deriv    , [0,zmax],u_ini,t_eval=zs,method='BDF',rtol=1e-4,atol=1e-7)
    sol_ref = solve_ivp(Disp2Deriv_ref, [0,zmax],u_ini,t_eval=zs,method='BDF')
    u      = sol.y     / sol.y[    0,-1] # normalize, so that velocity at surface is 1
    u_ref  = sol_ref.y / sol_ref.y[0,-1] 
    ZL     = G(zmax)*u[    1,-1] / (1j * om)
    ZL_ref = G_bulk *u_ref[1,-1] / (1j * om)
    Disp[iovt,iW] = u[0]
    Dfcbyns_FzI[iovt,iW] = Cor.f_fund*1j /(np.pi*Cor.Zq) * (ZL-ZL_ref)/n

def Calc_Dfcbyns_sharp():
    for iovt in range(Cor.novt):
        if Cor.OvtInc[iovt] == 1:
            Dfcbyns_Sharp[iovt] = Cor.Calc_DfcbynNoRef(Cor.SamplePars,Cor.n_arr[iovt])
            Dfcbyns_ref         = Cor.Calc_DfcbynNoRef(Cor.RefPars   ,Cor.n_arr[iovt])
            Dfcbyns_Sharp[iovt]-= Dfcbyns_ref 

def Calc_G_rho(n):
    global G_film,G_bulk,rho_film,rho_bulk
    t_lays,rho_lays,VEPar1_cen_lays,VEPar2_cen_lays,VEPar1_PLexpt_lays,VEPar2_PLexpt_lays,\
        VertScaleR,AspRat,VEtype_lays = Cor.get_layer_arrays(Cor.SamplePars)
    J_lays = Cor.Calc_J_SI_all_layers(VEPar1_cen_lays,VEPar2_cen_lays,
                         VEPar1_PLexpt_lays,VEPar2_PLexpt_lays,VEtype_lays,n)
    G_film = 1/J_lays[0]; rho_film = rho_lays[0]
    G_bulk = 1/J_lays[2]; rho_bulk = rho_lays[2]
    Gs[iovt,iW] = G_bulk + (G_film-G_bulk)*profile(zs)

def Plot_Dfcbyns(cntr):
    Calc_Dfcbyns_sharp()
    for widget in cntr.winfo_children(): widget.destroy()    
    fig = Figure(figsize = (6.,4.5))
    axis = fig.add_subplot(2,1,1)
    for iovt in range(Cor.novt):
        if Cor.OvtInc[iovt] == 1:
            axis.plot(WidthFacs,Dfcbyns_FzI[iovt].real,'.-',color=Cor.Colors[iovt],\
                      label = Cor.Ovt_Labels[iovt])
            axis.plot(WidthFacs/10.,np.ones(len(WidthFacs))*Dfcbyns_Sharp[iovt].real,\
                      '--',color=Cor.Colors[iovt])
            axis.plot(np.ones(2)*WidthFacs[Cor.i_selec_FzI],\
                   np.linspace(np.nanmin(Dfcbyns_FzI[:,Cor.i_selec_FzI]),\
                               np.nanmax(Dfcbyns_FzI[:,Cor.i_selec_FzI]),2),\
                       color='lightsteelblue')
                
    if np.sum(Cor.OvtInc) > 0: axis.legend(loc = 'upper right')
    axis.axes.xaxis.set_ticklabels([])
    axis.tick_params(direction='in')
    axis.set_ylabel('$\Delta f/n$ [Hz]')
    
    axis = fig.add_subplot(2,1,2)
    for iovt in range(Cor.novt):
        if Cor.OvtInc[iovt] == 1:
            if Cor.DD_DGbyn == 'DGbyn': 
                yvals = Dfcbyns_FzI[iovt].imag
                yvals_sharp = np.ones(len(WidthFacs))*Dfcbyns_Sharp[iovt].imag
            if Cor.DD_DGbyn == 'DD'   : 
                yvals = Dfcbyns_FzI[iovt].imag                                /Cor.f_fund*2./1e-6 
                yvals_sharp = np.ones(len(WidthFacs))*Dfcbyns_Sharp[iovt].imag/Cor.f_fund*2./1e-6 
            axis.plot(WidthFacs    ,yvals      ,'.-',color=Cor.Colors[iovt])
            axis.plot(WidthFacs/10.,yvals_sharp,'--',color=Cor.Colors[iovt])
            axis.plot(np.ones(2)*WidthFacs[Cor.i_selec_FzI],\
              np.linspace(np.nanmin(yvals),np.nanmax(yvals),2),color='lightsteelblue')
    axis.set_xlabel('Interface Width / Thickness')
    if Cor.DD_DGbyn == 'DGbyn': axis.set_ylabel('$\Delta\Gamma/n$ [Hz]'   )
    if Cor.DD_DGbyn == 'DD'   : axis.set_ylabel('\u0394D [10\u207B\u2076]')
    axis.tick_params(direction='in')
    fig.tight_layout(); fig.savefig('FuzzyInf_Dfcbyns.png')    
    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); canvas.get_tk_widget().pack() 
    fig.canvas.mpl_connect('button_press_event',onclick_FzI)
    
def Plot_Vis_Disp(cntr):
    for widget in cntr.winfo_children(): widget.destroy()    
    fig = Figure(figsize = (3.,4.5))
    
    axis = fig.add_subplot(2,1,1)
    for iovt in range(Cor.novt):
        omL = 2.*np.pi*Cor.n_arr[iovt]*Cor.f_fund            
        if Cor.OvtInc[iovt] == 1:
            axis.plot(zs*1e9,( Gs[iovt,Cor.i_selec_FzI]/(1j*omL)/1e-3).real,'-' ,color=Cor.Colors[iovt])
            axis.plot(zs*1e9,(-Gs[iovt,Cor.i_selec_FzI]/(1j*omL)/1e-3).imag,'--',color=Cor.Colors[iovt])
    axis.set_ylabel('$\eta$ [mPa s]')
    axis.axes.xaxis.set_ticklabels([]); axis.tick_params(direction='in')

    axis = fig.add_subplot(2,1,2)
    for iovt in range(Cor.novt):
        if Cor.OvtInc[iovt] == 1:
            axis.plot((zmax-zs)*1e9,Disp[iovt,Cor.i_selec_FzI].real,'-' ,color=Cor.Colors[iovt])
            axis.plot((zmax-zs)*1e9,Disp[iovt,Cor.i_selec_FzI].imag,'--',color=Cor.Colors[iovt])
    axis.set_xlabel('z [nm]'); axis.set_ylabel('Displacement')
    axis.tick_params(direction='in')
    
    fig.tight_layout(); fig.savefig('Wave.png')    
    canvas = FigureCanvasTkAgg(fig,cntr);canvas.draw();canvas.get_tk_widget().pack()

def Vary_InterfaceWidth():
    global iW,Width,iovt,om
    for iW,Width in enumerate(Widths):
        for iovt,n in enumerate(Cor.n_arr):
            om = 2.*np.pi*Cor.n_arr[iovt]*Cor.f_fund            
            if Cor.OvtInc[iovt] == 1: Calc_G_rho(n); Solve_ODEs(n);
    Plot_Dfcbyns(Frame2); Plot_Vis_Disp(Frame3)        
        
def onclick_FzI(event):
    if event.xdata != None:
        Cor.i_selec_FzI = int(np.nanargmin(np.abs(event.xdata-WidthFacs)))
        Cor.Write_Config(); Plot_Dfcbyns(Frame2); Plot_Vis_Disp(Frame3)

def FuzzyInterface_Start():
    global Frame2,Frame3,FuzzyInterfaceRoot,zmax,zs,Gs,PointInfl,WidthFacs,Widths,Disp,Dfcbyns_FzI,Dfcbyns_Sharp
    if Cor.Show_lay1 != 'yes' and Cor.Show_lay2 != 'no' and Cor.Show_lay1 != 'yes':
        tk.messagebox ('requires one layer + bulk'); return
    WidthFacs = np.linspace(0.03,0.5,num=10)
    PointInfl = Cor.SamplePars['t_lay1']*1e-9
    t_lays,rho_lays,VEPar1_cen_lays,VEPar2_cen_lays,VEPar1_PLexpt_lays,VEPar2_PLexpt_lays,\
        VertScaleR,AspRat,VEtype_lays = Cor.get_layer_arrays(Cor.SamplePars)
    J_lays = Cor.Calc_J_SI_all_layers(VEPar1_cen_lays,VEPar2_cen_lays,
                         VEPar1_PLexpt_lays,VEPar2_PLexpt_lays,VEtype_lays,1)
    G_bulk = 1/J_lays[2]; rho_bulk = rho_lays[2]; eta_bulk_f_fund = G_bulk /(1j*2.*np.pi*Cor.f_fund)
    delta_f_fund = ((2.*eta_bulk_f_fund/(rho_bulk*2.*np.pi*Cor.f_fund))**0.5).real
    zmax = PointInfl*(1+3*WidthFacs[-1])+3*delta_f_fund
    zs = np.linspace(0,zmax,num=100)
    Widths = PointInfl*WidthFacs
    if Cor.i_selec_FzI > len(WidthFacs)-1: Cor.i_selec_FzI = 0; Cor.Write_Config()
    Dfcbyns_FzI = np.ones((Cor.novt,len(Widths))        ,dtype = np.complex128)*np.nan
    Dfcbyns_Sharp=np.ones((Cor.novt            )        ,dtype = np.complex128)*np.nan
    Gs          = np.ones((Cor.novt,len(Widths),len(zs)),dtype = np.complex128)*np.nan
    Disp        = np.ones((Cor.novt,len(Widths),len(zs)),dtype = np.complex128)*np.nan

    FuzzyInterfaceRoot = tk.tix.Tk(); FuzzyInterfaceRoot.title('Fuzzy Interface')
    Frame2 = tk.LabelFrame(FuzzyInterfaceRoot); Frame2.grid(row=1,column=0,sticky = 'NW') 
    Frame3 = tk.LabelFrame(FuzzyInterfaceRoot); Frame3.grid(row=1,column=1,sticky = 'NW') 
    Vary_InterfaceWidth()
    FuzzyInterfaceRoot.iconbitmap("QTM.ico")
    FuzzyInterfaceRoot.mainloop()