import numpy as np
import tkinter as tk
from tkinter import Toplevel
import QTM_Core as Cor
import QTM_Limits as Limits
import QTM_TT_IO as TT
import QTM_chi2_Landscape as chi2_Landscape
import QTM_Bootstrap as Bootstrap
import QTM_FuzzyInterface as FuzzyInterface

from matplotlib.backends.backend_tkagg import(FigureCanvasTkAgg)
from matplotlib.figure import Figure
from tkinter import filedialog as fd
import shutil
import os
import datetime
import pandas as pd
 
def Set_FitRange():  Cor.ready_state = 'FitRange';      Root.config(cursor='hand2')
def Hide_1_TT():     Cor.ready_state = 'Hide_1_TT';     Root.config(cursor='hand2')
def Hide_1_FP():     Cor.ready_state = 'Hide_1_FP';     Root.config(cursor='hand2')
def Hide_Range_TT(): Cor.ready_state = 'Hide_Range_TT'; Root.config(cursor='hand2')
def Hide_Range_FP(): Cor.ready_state = 'Hide_Range_FP'; Root.config(cursor='hand2')
def Zoom_TT():       Cor.ready_state = 'Zoom_TT';       Root.config(cursor='hand2')
def Zoom_FP():       Cor.ready_state = 'Zoom_FP';       Root.config(cursor='hand2')
def Avrg():          Cor.ready_state = 'Average';       Root.config(cursor='hand2')
def UnZoom_TT(): Cor.i_strt_zoom_TT = 0; Cor.i_stop_zoom_TT = len(TT.DfDGbyns); PlotDfDGbyns(PlotDfDGbynsFrame)
def UnZoom_FP(): Cor.i_strt_zoom_FP = 0; Cor.i_stop_zoom_FP = len(TT.TT_FPars); PlotFPars(PlotFParsFrame)
    
def UnHide_TT():
    Cor.i_strt_hide_TT = 0
    Cor.i_stop_hide_TT = 0
    TT.DfDGbyns = np.loadtxt('~tmp_for_unhide.qtf',skiprows=1)
    PlotDfDGbyns(PlotDfDGbynsFrame)
    MakeTT_IOFrame(TT_IOFrame)
    Cor.Write_Config()

def Unhide_FP():
    Cor.i_strt_hide_FP = 0
    Cor.i_stop_hide_FP = 0
    data = np.loadtxt('~tmp_for_unhide.qtd',skiprows=1)
    if data.ndim == 1: data = np.array([data])
    for it in range(len(data)):
        for j in range(len(data[0])):
            try: TT.TT_FPars[it,j] = data[it,j]
            except: pass
    TT.Make_headers()
    np.savetxt('~tmp.qtd',TT.TT_FPars,header=TT.header_FPars_qtd,delimiter='\t',newline='\n')
    PlotFPars(PlotFParsFrame)
    Cor.Write_Config()

def onclick_TT(event):
    if Cor.ready_state == 'Select' and event.xdata != None:
        Cor.i_selec = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x])))
        Cor.i_strt_avrg = 0
        Cor.i_stop_avrg = 0
        for iovt in range(Cor.novt):
            Cor.Dfbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt  ]
            Cor.DGbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt+1]
        Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns
        Cor.Write_Config()
        PlotSingle(PlotSingleFrame)
        PlotDfDGbyns(PlotDfDGbynsFrame)
        MakeDfcbynsFrame(DfcbynsFrame)
    if Cor.ready_state == 'FitRange': 
        Cor.i_strt_fit= int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x]))) 
        Cor.i_current = Cor.i_strt_fit
    if Cor.ready_state == 'Hide_Range_TT': Cor.i_strt_hide_TT = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x]))) 
    if Cor.ready_state == 'Zoom_TT':       Cor.i_strt_zoom_TT = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x])))
    if Cor.ready_state == 'Average':       Cor.i_strt_avrg    = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x]))) 
    if Cor.ready_state == 'Hide_1_TT':
        Root.config(cursor='arrow'); Cor.ready_state == 'Select'
        i_Hide_1 = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x])))
        TT.DfDGbyns[i_Hide_1,:] = np.nan
        TT.Make_headers()            
        np.savetxt('~tmp.qtf',TT.DfDGbyns,header=TT.header_DfDGbyns,delimiter='\t',newline='\n')
        PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)  
        MakeTT_IOFrame(TT_IOFrame)
   
def onclick_FP(event):
    if Cor.ready_state == 'Hide_Range_FP': Cor.i_strt_hide_FP = int(np.nanargmin(np.abs(event.xdata-TT.TT_FPars[:,Cor.i_col_x]))) 
    
    if Cor.ready_state == 'Zoom_FP': Cor.i_strt_zoom_FP = int(np.nanargmin(np.abs(event.xdata-TT.TT_FPars[:,Cor.i_col_x]))) 
    if Cor.ready_state == 'Hide_1_FP':
        Root.config(cursor='arrow'); Cor.ready_state == 'Select'
        i_Hide_1_FP = int(np.nanargmin(np.abs(event.xdata-TT.TT_FPars[:,Cor.i_col_x])))
        TT.TT_FPars[i_Hide_1_FP,:] = np.nan
        np.savetxt('~tmp.qtd',TT.TT_FPars,header=TT.header_FPars_qtd,delimiter='\t',newline='\n')
        PlotFPars(PlotFParsFrame) 
        MakeTT_IOFrame(TT_IOFrame)

def onrelease_TT(event):
    if Cor.ready_state == 'FitRange':
        Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
        Cor.i_stop_fit = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x])))
        if Cor.i_stop_fit < Cor.i_strt_fit: 
            istop_fit_temp = Cor.i_stop_fit
            Cor.i_stop_fit = Cor.i_strt_fit
            Cor.i_strt_fit = istop_fit_temp
            Cor.i_current  = Cor.i_strt_fit
        Cor.Write_Config()
        MakeTT_IOFrame(TT_IOFrame)
        PlotDfDGbyns(PlotDfDGbynsFrame)

    if Cor.ready_state == 'Hide_Range_TT':
        Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
        Cor.i_stop_hide_TT = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x]))) 
        if Cor.i_strt_hide_TT >= Cor.i_stop_hide_TT:
            strt_buffer = Cor.i_stop_hide_TT
            Cor.i_stop_hide_TT = Cor.i_strt_hide_TT
            Cor.i_strt_hide_TT = strt_buffer
        for it in range(Cor.i_strt_hide_TT,Cor.i_stop_hide_TT+1):
            TT.DfDGbyns[it,0] = np.nan
            for j in range(2,2+4*Cor.novt): TT.DfDGbyns[it,j] = np.nan
        TT.Make_headers()            
        np.savetxt('~tmp.qtf',TT.DfDGbyns,header=TT.header_DfDGbyns,delimiter='\t',newline='\n')
        if All_NaNs_in_Dfcs(): 
            Cor.i_selec = 0
            while All_NaNs_in_Dfcs() and Cor.i_selec < len(TT.DfDGbyns) - 1:
                Cor.i_selec += 1
        for iovt in range(Cor.novt):
            Cor.Dfbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt  ]
            Cor.DGbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt+1]
        Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns 
        Cor.Write_Config()
        PlotSingle(PlotSingleFrame)
        PlotDfDGbyns(PlotDfDGbynsFrame)
        MakeDfcbynsFrame(DfcbynsFrame)
        MakeTT_IOFrame(TT_IOFrame)

    if Cor.ready_state == 'Zoom_TT':
        Root.config(cursor='arrow'); Cor.ready_state = 'Select'
        Cor.i_stop_zoom_TT = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x]))) 
        if Cor.i_strt_zoom_TT >= Cor.i_stop_zoom_TT:
            strt_buffer = Cor.i_stop_zoom_TT
            Cor.i_stop_zoom_TT = Cor.i_strt_zoom_TT
            Cor.i_strt_zoom_TT = strt_buffer
        Cor.Write_Config()
        PlotDfDGbyns(PlotDfDGbynsFrame)
    if Cor.ready_state == 'Average':
        Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
        Cor.i_stop_avrg = int(np.nanargmin(np.abs(event.xdata-TT.DfDGbyns[:,Cor.i_col_x]))) 
        if Cor.i_strt_avrg >= Cor.i_stop_avrg:
            strt_buffer = Cor.i_stop_avrg
            Cor.i_stop_avrg = Cor.i_strt_avrg
            Cor.i_strt_avrg = strt_buffer
        for iovt in range(Cor.novt):
            Cor.Dfbyns[iovt] = np.nanmean(TT.DfDGbyns[Cor.i_strt_avrg:Cor.i_stop_avrg,2+4*iovt  ])
            Cor.DGbyns[iovt] = np.nanmean(TT.DfDGbyns[Cor.i_strt_avrg:Cor.i_stop_avrg,2+4*iovt+1])
        Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns 
        Cor.Write_Config()
        PlotSingle(PlotSingleFrame)
        MakeDfcbynsFrame(DfcbynsFrame)

def onrelease_FP(event):
    if Cor.ready_state == 'Hide_Range_FP':
        Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
        TT.Make_headers()            
        Cor.i_stop_hide_FP = int(np.nanargmin(np.abs(event.xdata-TT.TT_FPars[:,Cor.i_col_x]))) 
        if Cor.i_strt_hide_FP <= Cor.i_stop_hide_FP:   
            for it in range(Cor.i_strt_hide_FP,Cor.i_stop_hide_FP+1):
                for j in range(2,2+2*Cor.nFParsmax+1): TT.TT_FPars[it,j] = np.nan
                TT.TT_FPars[it,-1] = np.nan
        if Cor.i_strt_hide_FP >= Cor.i_stop_hide_FP:    
            for it in range(Cor.i_stop_hide_FP,Cor.i_strt_hide_FP+1):
                for j in range(2,2+2*Cor.nFParsmax+1): TT.TT_FPars[it,j] = np.nan
                TT.TT_FPars[it,-1] = np.nan
        np.savetxt('~tmp.qtd',TT.TT_FPars,header=TT.header_FPars_qtd,delimiter='\t',newline='\n')
        PlotFPars(PlotFParsFrame) 

    if Cor.ready_state == 'Zoom_FP':
        Root.config(cursor='arrow'); Cor.ready_state = 'Select' 
        Cor.i_stop_zoom_FP = int(np.nanargmin(np.abs(event.xdata-TT.TT_FPars[:,Cor.i_col_x]))) 
        if Cor.i_strt_zoom_FP >= Cor.i_stop_zoom_FP:
            strt_buffer = Cor.i_stop_zoom_FP
            Cor.i_stop_zoom_FP = Cor.i_strt_zoom_FP
            Cor.i_strt_zoom_FP = strt_buffer
        PlotFPars(PlotFParsFrame) 

def Undo():
    if os.path.isfile('~tmp_Backup.qtm'): 
        shutil.copyfile('~tmp_Backup.qtm','~tmp.qtm')
        Cor.Read_Config(); TT.Initialize('~tmp.qtf','~tmp.qtd')
        Update_User_Interface()

def Clear_Fits():
    for iovt in range(Cor.novt):
        TT.DfDGbyns[:,2+4*iovt+2] = np.nan
        TT.DfDGbyns[:,2+4*iovt+3] = np.nan
    for j in range(len(TT.TT_FPars[0])):
        TT.TT_FPars[:,j] = np.nan
    TT.Make_headers()
    np.savetxt('~tmp.qtf',TT.DfDGbyns  ,header=TT.header_DfDGbyns,delimiter='\t',newline='\n')
    np.savetxt('~tmp.qtd',TT.TT_FPars,header=TT.header_FPars_qtd,delimiter ='\t',newline='\n')
    PlotDfDGbyns(PlotDfDGbynsFrame) 
    PlotFPars(   PlotFParsFrame)
    TT.Make_headers()            
    np.savetxt('~tmp_for_unhide.qtd',TT.TT_FPars,header=TT.header_FPars_qtd,delimiter='\t')

def Calc_nFPars():
    Cor.nFPars = 0
    for key in Cor.keys: 
        if Cor.IncPars[key] == 1: Cor.nFPars += 1

def Fit():
    shutil.copyfile('~tmp.qtm','~tmp_Backup.qtm')
    Check_for_NaNs_in_Dfcs()
    Calc_nFPars()
    if 2*np.sum(Cor.OvtInc) < Cor.nFPars: 
        tk.messagebox.showinfo('','number of fit parameters > 2 * number of active overtones'); return
    if Cor.nFPars == 0: 
        tk.messagebox.showinfo('','no active fit parameters'); return
    if Cor.Use_eq_thickness_at_xMHz == 'yes' and Cor.SamplePars['t_lay1'] >  0 and Cor.SamplePars['t_lay2'] == 0 and \
       Cor.RefPars['t_lay1'] == 0 and Cor.RefPars['t_lay2'] == 0:
        fac_to_0MHz = Cor.Calc_fac_to_0MHz()
        Cor.SamplePars['t_lay1']    *= fac_to_0MHz 
        Cor.SampleStdErrs['t_lay1'] *= fac_to_0MHz 
    Cor.Fit(); Cor.FitVals_to_SamplePars(Cor.FittedVals)
    if Cor.Use_eq_thickness_at_xMHz == 'yes' and Cor.SamplePars['t_lay1'] >  0 and Cor.SamplePars['t_lay2'] == 0 and \
           Cor.RefPars['t_lay1'] == 0 and Cor.RefPars['t_lay2'] == 0:
        fac_to_xMHz = Cor.Calc_fac_to_xMHz()
        Cor.SamplePars['t_lay1']    *= fac_to_xMHz
        Cor.SampleStdErrs['t_lay1'] *= fac_to_xMHz
    Cor.Fit_done = 'yes' 
    Cor.Write_Config()
    PlotSingle(PlotSingleFrame)
    MakeSampleParsFrame(SampleParsFrame)
    TT.Make_headers()
    f = open('~tmp.qtr','a')
    now = datetime.datetime.now()
    f.write(now.strftime("%Y-%m-%d %H:%M:%S") + '\n')
    f.write(Cor.TT_filename + ' Data_Point '+ str(Cor.i_selec) + '\n')
    f.write(TT.header_FPars_qtr + '\n' )
    outputline = ''
    for iFPar in range(Cor.nFPars):
        outputline += "{:.5e}".format(Cor.FittedVals[iFPar]) + '\t' +"{:.5e}".format(Cor.StdErrs[iFPar]) + '\t'
    outputline += "{:.5e}".format(Cor.chi2) + '\n'
    f.write(outputline)
    f.close()
    MakeFitFrame(FitFrame)

def ConfLims_lmfit_2_Console(): Cor.ConfLims_lmfit_2_Console()

def Check_for_NaNs_in_Dfcs():
    OvtInc_Changed = False
    OvtInc_old = np.copy(Cor.OvtInc)
    for iovt in range(Cor.novt): 
        if np.isnan(Cor.Dfbyns[iovt]) or np.isnan(Cor.DGbyns[iovt]):
            Cor.OvtInc[iovt] = 0
            if OvtInc_old[iovt] != Cor.OvtInc[iovt]: OvtInc_Changed = True
    if OvtInc_Changed: 
        Cor.Write_Config()
        MakeDfcbynsFrame(DfcbynsFrame)

def All_NaNs_in_Dfcs():
    All_NaNs = True
    for iovt in range(Cor.novt): 
        if not np.isnan(TT.DfDGbyns[Cor.i_selec,2+4*iovt]) or \
           not np.isnan(TT.DfDGbyns[Cor.i_selec,2+4*iovt]): All_NaNs = False
    return All_NaNs    

def All_NaNs_in_array(array):
    All_NaNs = True
    for i in range(len(array)): 
        if not np.isnan(array[i]): All_NaNs = False
    return All_NaNs    

def PlotSingle(cntr):
    Cor.ns_inc_Dfcbyns_inc(); Cor.Simulate() 
    for widget in cntr.winfo_children(): widget.destroy()
    fig = Figure(figsize = (2.0,2.2),dpi=100) 
    axis = fig.add_subplot(211)
    if np.sum(Cor.OvtInc) > 0: 
        axis.plot(Cor.ns_inc*Cor.f_fund/1e6,Cor.Dfcbyns_inc.real,'x',color='r',label='\u0394f/n [Hz]')
    axis.plot(    Cor.n_sims*Cor.f_fund/1e6,Cor.Dfcbyns_sim.real,'-',color='r')
    if Cor.Use_eq_thickness_at_xMHz == 'yes' and Cor.SamplePars['t_lay1'] >  0 and Cor.SamplePars['t_lay2'] == 0 and \
           Cor.RefPars['t_lay1'] == 0 and Cor.RefPars['t_lay2'] == 0:
        axis.plot(np.ones(5)*Cor.freq_MHz_for_eq_thick,\
           np.linspace(np.nanmin(Cor.Dfcbyns_sim.real),np.nanmax(Cor.Dfcbyns_sim.real),5),'-',color='grey')
    axis.tick_params(labelsize=7,direction='in')
    axis.axes.xaxis.set_ticklabels([])
    axis.set_ylabel('\u0394f/n [Hz]',fontsize=9)
    axis = fig.add_subplot(212)
    if Cor.DD_DGbyn == 'DD':
        if np.sum(Cor.OvtInc) > 0: 
            axis.plot(Cor.ns_inc*Cor.f_fund/1e6,Cor.Dfcbyns_inc.imag/Cor.f_fund*2./1e-6,'x',color='b')
        axis.plot(    Cor.n_sims*Cor.f_fund/1e6,Cor.Dfcbyns_sim.imag/Cor.f_fund*2./1e-6,'-',color='b')
    if Cor.DD_DGbyn == 'DGbyn': 
        if np.sum(Cor.OvtInc) > 0: 
            axis.plot(Cor.ns_inc*Cor.f_fund/1e6,Cor.Dfcbyns_inc.imag,'x',color='b')
        axis.plot(    Cor.n_sims*Cor.f_fund/1e6,Cor.Dfcbyns_sim.imag,'-',color='b')
    axis.tick_params(labelsize=7,direction='in')
    axis.set_xlabel('f [MHz]',fontsize=9)
    if Cor.DD_DGbyn == 'DD'   : axis.set_ylabel('\u0394D [10\u207B\u2076]',fontsize=9)
    if Cor.DD_DGbyn == 'DGbyn': axis.set_ylabel('\u0394\u0393/n [Hz]',fontsize=9)
    fig.tight_layout(); fig.savefig('Single.png',dpi=200)
    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw() 
    canvas.get_tk_widget().grid(row=0,column=0,sticky='NW')
    Cor.Calc_chi2()
    if not np.isnan(Cor.chi2):
        if Cor.chi2 < 1e9: 
            tk.Label(FitFrame,width=9,text='\u03c7\u00b2 ' + str(np.round(Cor.chi2,2)),fg='blue').grid(row=1,column=2,columnspan=2,sticky='W')
        else: tk.Label(FitFrame,width=9,text='\u03c7\u00b2 ').grid(row=1,column=2,columnspan=2,sticky='W')
    else:    
        tk.Label(FitFrame,width=9,text='\u03c7\u00b2 ').grid(row=1,column=2,columnspan=2,sticky='W')
    DfDGbyn_sim = [Cor.n_sims*Cor.f_fund/1e6]
    DfDGbyn_sim = np.append(DfDGbyn_sim,[Cor.Dfcbyns_sim.real],axis=0)
    if Cor.DD_DGbyn == 'DGbyn':
        header = 'f[MHz] \t Dfbyn[Hz] \t DGbyn[Hz]'
        DfDGbyn_sim = np.append(DfDGbyn_sim,[Cor.Dfcbyns_sim.imag],axis=0)
    if Cor.DD_DGbyn == 'DD':
        header = 'f[MHz] \t Dfbyn[Hz] \t DD[10^-6]'
        DfDGbyn_sim = np.append(DfDGbyn_sim,[Cor.Dfcbyns_sim.imag/Cor.f_fund*2./1e-6],axis=0)
    np.savetxt('Simulated_Dfcbyn.txt',np.transpose(DfDGbyn_sim),header=header,delimiter='\t')    
    if np.sum(Cor.OvtInc) > 0:
        DfDGbyn_Exp = [Cor.ns_inc*Cor.f_fund/1e6]
        DfDGbyn_Exp = np.append(DfDGbyn_Exp,[Cor.Dfcbyns_inc.real],axis=0)
        if Cor.DD_DGbyn == 'DGbyn':
            header='f[MHz] \t Dfbyn[Hz] \t DGbyn[Hz]'
            DfDGbyn_Exp = np.append(DfDGbyn_Exp,[Cor.Dfcbyns_inc.imag],axis=0)
        if Cor.DD_DGbyn == 'DD':
            header = 'f[MHz] \t Dfbyn[Hz] \t DD[10^-6]'
            DfDGbyn_Exp = np.append(DfDGbyn_Exp,[Cor.Dfcbyns_inc.imag/Cor.f_fund*2./1e-6],axis=0)
        np.savetxt('Experimental_Dfcbyn.txt',np.transpose(DfDGbyn_Exp),header = header,delimiter='\t')    

def PlotDfDGbyns(cntr):
    Cor.i_strt_zoom_TT = np.min([Cor.i_strt_zoom_TT,len(TT.DfDGbyns)-1])
    Cor.i_stop_zoom_TT = np.min([Cor.i_stop_zoom_TT,len(TT.DfDGbyns)-1])

    Check_for_NaNs_in_Dfcs()
    for widget in cntr.winfo_children(): widget.destroy()
    fig = Figure(figsize = (4.8,4.9),dpi=100)
    axis = fig.add_subplot(211)
    if np.ndim(TT.DfDGbyns) == 1: TT.DfDGbyns = np.array([TT.DfDGbyns]) 
    for iovt in range(Cor.novt):
        if Cor.OvtInc[iovt] == 1:
            axis.plot(TT.DfDGbyns[:,Cor.i_col_x],TT.DfDGbyns[:,2+4*iovt  ],'.',color=Cor.Colors[iovt],label = Cor.Ovt_Labels[iovt],
                      markersize = 2.)
            axis.plot(TT.DfDGbyns[:,Cor.i_col_x],TT.DfDGbyns[:,2+4*iovt+2],'-',color=Cor.Colors[iovt])
            if not All_NaNs_in_array(TT.DfDGbyns[:,2+4*iovt]):
                if np.nanmax(TT.DfDGbyns[:,2+4*iovt]) > np.nanmin(TT.DfDGbyns[:,2+4*iovt]) and \
                   Cor.i_selec < len(TT.DfDGbyns) and Cor.i_strt_fit < len(TT.DfDGbyns) and Cor.i_stop_fit < len(TT.DfDGbyns) \
                       and Cor.i_current < len(TT.DfDGbyns): 
                    axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_selec,Cor.i_col_x],\
                              np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt]),np.nanmax(TT.DfDGbyns[:,2+4*iovt]),5),'-',color='lightsteelblue')
                    axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_strt_fit,Cor.i_col_x],\
                              np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt]),np.nanmax(TT.DfDGbyns[:,2+4*iovt]),5),'-',color='grey')
                    axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_stop_fit,Cor.i_col_x],\
                              np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt]),np.nanmax(TT.DfDGbyns[:,2+4*iovt]),5),'-',color='olive')
                    axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_current,Cor.i_col_x],\
                              np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt]),np.nanmax(TT.DfDGbyns[:,2+4*iovt]),5),'-',color='fuchsia')
    if Cor.i_stop_zoom_TT > len(TT.DfDGbyns)-1:
        Cor.i_stop_zoom_TT = len(TT.DfDGbyns)-1; Cor.Write_Config()
    if not np.isnan(TT.DfDGbyns[Cor.i_strt_zoom_TT,Cor.i_col_x]) and not np.isnan(TT.DfDGbyns[Cor.i_stop_zoom_TT,Cor.i_col_x]):
        itmin = np.nanargmin(TT.DfDGbyns[:,0])
        itmax = np.nanargmax(TT.DfDGbyns[:,0])
        tmin  = np.nanmax([TT.DfDGbyns[Cor.i_strt_zoom_TT,Cor.i_col_x],TT.DfDGbyns[itmin,Cor.i_col_x]])        
        tmax  = np.nanmin([TT.DfDGbyns[Cor.i_stop_zoom_TT,Cor.i_col_x],TT.DfDGbyns[itmax,Cor.i_col_x]])
        if tmax > tmin:
            leftlim  = tmin - 0.05*(tmax-tmin)
            rightlim = tmax + 0.05*(tmax-tmin)
            axis.set_xlim(left = leftlim,right=rightlim)
    axis.set_ylabel('$\Delta f/n$ [Hz]',fontsize=9)
    axis.axes.xaxis.set_ticklabels([])
    axis.tick_params(direction='in',labelsize =8)
    if np.sum(Cor.OvtInc) > 0: axis.legend(fontsize=7)
    if Cor.TT_IO_Format == 'from_QSoft_new': axis.set_title(os.path.basename(Cor.TT_filename)[:45] + ' chan ' + str(Cor.i_channel+1),fontsize=9)
    else                                   : axis.set_title(os.path.basename(Cor.TT_filename)[:55],fontsize=9)
    
    axis = fig.add_subplot(212)
    for iovt in range(Cor.novt):
        if Cor.OvtInc[iovt] == 1:
            if Cor.DD_DGbyn == 'DD':
                axis.plot(TT.DfDGbyns[:,Cor.i_col_x],TT.DfDGbyns[:,2+4*iovt+1]/Cor.f_fund*2./1e-6,'.',color=Cor.Colors[iovt],\
                          label = Cor.Ovt_Labels[iovt],markersize = 2.)
                axis.plot(TT.DfDGbyns[:,Cor.i_col_x],TT.DfDGbyns[:,2+4*iovt+3]/Cor.f_fund*2./1e-6,'-',color=Cor.Colors[iovt])
                if not All_NaNs_in_array(TT.DfDGbyns[:,2+4*iovt+1]):
                    if np.nanmax(TT.DfDGbyns[:,2+4*iovt]) > np.nanmin(TT.DfDGbyns[:,2+4*iovt]) and \
                       Cor.i_selec < len(TT.DfDGbyns) and Cor.i_strt_fit < len(TT.DfDGbyns) and Cor.i_stop_fit < len(TT.DfDGbyns): 
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_selec,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5)/Cor.f_fund*2./1e-6,'-',color='lightsteelblue')
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_strt_fit,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5)/Cor.f_fund*2./1e-6,'-',color='grey')
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_stop_fit,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5)/Cor.f_fund*2./1e-6,'-',color='olive')
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_current,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5)/Cor.f_fund*2./1e-6,'-',color='fuchsia')
            if Cor.DD_DGbyn == 'DGbyn':
                axis.plot(TT.DfDGbyns[:,Cor.i_col_x],TT.DfDGbyns[:,2+4*iovt+1],'.',color=Cor.Colors[iovt],\
                          label = Cor.Ovt_Labels[iovt],markersize = 2.)
                axis.plot(TT.DfDGbyns[:,Cor.i_col_x],TT.DfDGbyns[:,2+4*iovt+3],'-',color=Cor.Colors[iovt])
                if not All_NaNs_in_array(TT.DfDGbyns[:,2+4*iovt+1]):
                    if np.nanmax(TT.DfDGbyns[:,2+4*iovt]) > np.nanmin(TT.DfDGbyns[:,2+4*iovt]) and \
                       Cor.i_selec < len(TT.DfDGbyns) and Cor.i_strt_fit < len(TT.DfDGbyns) and Cor.i_stop_fit < len(TT.DfDGbyns): 
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_selec,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5),'-',color='lightsteelblue')
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_strt_fit,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5),'-',color='grey')
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_stop_fit,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5),'-',color='olive')
                        axis.plot(np.ones(5)*TT.DfDGbyns[Cor.i_current,Cor.i_col_x],\
                                  np.linspace(np.nanmin(TT.DfDGbyns[:,2+4*iovt+1]),np.nanmax(TT.DfDGbyns[:,2+4*iovt+1]),5),'-',color='fuchsia')
            if not np.isnan(TT.DfDGbyns[Cor.i_strt_zoom_TT,Cor.i_col_x]) and not np.isnan(TT.DfDGbyns[Cor.i_stop_zoom_TT,Cor.i_col_x]):
                if tmax > tmin:
                    axis.set_xlim(left = leftlim,right=rightlim)
    if Cor.vs_time_datapoint == 'time'      : axis.set_xlabel('time [a.u.]',fontsize=9)
    if Cor.vs_time_datapoint == 'datapoint' : axis.set_xlabel('number',fontsize=9)
    if Cor.DD_DGbyn == 'DD'   : axis.set_ylabel('\u0394D [10\u207B\u2076]',fontsize=9)
    if Cor.DD_DGbyn == 'DGbyn': axis.set_ylabel('$\Delta\Gamma/n$ [Hz]'   ,fontsize=9)
    axis.set_title(Cor.InfoString,fontsize=9)
    axis.tick_params(direction='in',labelsize=8)
    fig.tight_layout(); fig.savefig('All_DfDGbyns.png',dpi=200)

    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); canvas.get_tk_widget().pack() 
    fig.canvas.mpl_connect('button_press_event'  ,onclick_TT)
    fig.canvas.mpl_connect('button_release_event',onrelease_TT)

def PlotFPars(cntr):
    TT.Get_Labels_TT_header()
    for widget in cntr.winfo_children(): widget.destroy()
    fig = Figure(figsize = (3.5,6.1),dpi=100)
    iFPar = 0         
    for key in Cor.keys:
        if Cor.IncPars[key] == 1:
            axis = fig.add_subplot(Cor.nFPars+1,1,1+iFPar)
            StdErrs = np.zeros(len(TT.TT_FPars))
            for i in range(0,len(StdErrs),Cor.Update_Inval): StdErrs[i] = TT.TT_FPars[i,2+2*iFPar+1]
            if Cor.i_PlotErrBars == 1:
                axis.errorbar(TT.TT_FPars[:,Cor.i_col_x],TT.TT_FPars[:,2+2*iFPar],StdErrs,color='r')
            else:
                axis.plot(TT.TT_FPars[:,Cor.i_col_x],TT.TT_FPars[:,2+2*iFPar],color='r')
            if not np.isnan(TT.TT_FPars[Cor.i_strt_zoom_FP,Cor.i_col_x]) and not np.isnan(TT.TT_FPars[Cor.i_stop_zoom_FP,Cor.i_col_x]):
                axis.set_xlim(left = TT.TT_FPars[Cor.i_strt_zoom_FP,Cor.i_col_x],right=TT.TT_FPars[Cor.i_stop_zoom_FP,Cor.i_col_x])
            axis.tick_params(labelsize=7,direction='in')
            axis.axes.xaxis.set_ticklabels([])
            axis.set_ylabel(TT.Graph_TT_Labels[key],fontsize=9)
            if iFPar == 0: axis.set_title(Cor.InfoString,fontsize=9)
            iFPar += 1
    axis = fig.add_subplot(Cor.nFPars+1,1,1+iFPar)
    axis.plot(TT.TT_FPars[:,Cor.i_col_x],TT.TT_FPars[:,-1],'x-',color='r')
    axis.tick_params(labelsize=7,direction='in')
    if Cor.vs_time_datapoint == 'time'      : axis.set_xlabel('time [a.u.]',fontsize=9)
    if Cor.vs_time_datapoint == 'datapoint' : axis.set_xlabel('number',fontsize=9)
    axis.set_ylabel('$\chi^{2}$' ,fontsize=9)
    fig.tight_layout(); fig.savefig('All_FPars.png',dpi=200)

    canvas = FigureCanvasTkAgg(fig,cntr); canvas.draw(); canvas.get_tk_widget().pack()
    fig.canvas.mpl_connect('button_press_event'  ,onclick_FP)
    fig.canvas.mpl_connect('button_release_event',onrelease_FP)

def openLimits(): Limits.Limits_Start()
def openchi2_Landscape(): chi2_Landscape.chi2_Landscape_Start()
def openBootstrap(): Bootstrap.Bootstrap_Start()
def openFuzzyInterface(): FuzzyInterface.FuzzyInterface_Start()


def AboutMessage(): 
    tk.messagebox.showinfo('','QTM was written by Diethelm Johannsmann and Philipp Sievers' + \
        '  https://www.pc.tu-clausthal.de \n' + 'Feedback is appreciated')

def Update_Previous_Filenames():
    Root.title('PyQTM:    ' + os.path.basename(Cor.filename) + '   /   ' + os.path.basename(Cor.TT_filename))
    for j in range(Cor.n_previous-1,0,-1):Cor.Previous_Filenames[j] = Cor.Previous_Filenames[j-1]
    Cor.Previous_Filenames[0] = Cor.filename
    Cor.Write_QTM_cfg(); Make_Menu()

def MakeSampleParsFrame(cntr):
    global VE_Choices
    for widget in cntr.winfo_children(): widget.destroy() 
    VE_Choices = ['J\',J\'\'','G\',G\'\'','\u03B7\',\u03B7\'\'','G\',\u03B7\'',\
                  '|J|,tan(\u03B4)','|G|,tan(\u03B4)','|\u03B7|,tan(\u03B4)\u207B\u00B9']
    if Cor.Model == 'Thin_Film_Jpp1 small' and \
        (Cor.Show_lay1 != 'yes' or Cor.Show_lay2 != 'no' or Cor.Show_bulk != 'yes' or \
         Cor.SamplePars['VEtype_lay3'] != 3 or Cor.SamplePars['VEPar2_lay3'] > Cor.LimitsMinPars['VEPar2_lay3']):
        tk.messagebox.showinfo('','Conditions for Model Thin Film J\'\'_1 small not met \n Model was changed')
        Cor.Model = 'Multilayer_Formalism'
        Cor.Write_Config(); MakeFitFrame(FitFrame)
    if Cor.Show_lay1 == 'yes': i_Show_lay1_IV = tk.IntVar(cntr,1)
    if Cor.Show_lay1 == 'no' : i_Show_lay1_IV = tk.IntVar(cntr,0)
    if Cor.Show_lay2 == 'yes': i_Show_lay2_IV = tk.IntVar(cntr,1)
    if Cor.Show_lay2 == 'no' : i_Show_lay2_IV = tk.IntVar(cntr,0)
    if Cor.Show_bulk == 'yes': i_Show_bulk_IV = tk.IntVar(cntr,1)
    if Cor.Show_bulk == 'no' : i_Show_bulk_IV = tk.IntVar(cntr,0)


    def Enter_Stuff_Pars(event,key):
        for key in Cor.keys:
            if key != 'VEtype_lay1' and key != 'VEtype_lay2' and key != 'VEtype_lay3': 
                string = SamplePars_SVs[key].get(); string.strip()
                if '\u00b1' in string: 
                    index = string.find('\u00b1'); string = string[:index]
                try: Cor.SamplePars[key] = np.float64(string)
                except: print(key,string)
        Cor.adjust_Pars_to_Limits()
        Cor.Fit_done = 'no'; Cor.Write_Config()
        MakeSampleParsFrame(SampleParsFrame)
        PlotSingle(PlotSingleFrame)
    
    def incdec(val,pm):
        if pm=='+':
            if val>0 : val*=1.5
            if abs(val) <= 1e-7: val+=1.
            if val<0 : val/=1.5
        elif pm=='-':
            if val>0 : val/=1.5
            if abs(val) <= 1e-7: val-=1.
            if val<0 : val*=1.5
        else: 
            try: val = np.float64(pm)
            except: pass
        return val  
    
    def FPars_to_Clpbd():
        if Cor.Fit_done == 'yes':
            c_names=['Name','Value','Error']
            tempdf = pd.DataFrame({},columns = c_names)
            tempdf['Value'] = pd.DataFrame(Cor.FittedVals)
            tempdH = TT.header_FPars_qtr.split()   
            for iFPar in range(Cor.nFPars):
                errbar = Cor.StdErrs[iFPar] 
                tempdf.at[iFPar,'Name'] = tempdH[2+2*iFPar]
                tempdf.at[iFPar,'Error'] = errbar
            tempdf.to_clipboard(excel=True,sep=None,index=False,header=None)
        else: tk.messagebox.showinfo('','Do fit first')     

    def Make_Reference():
        for key in Cor.keys: Cor.RefPars[key] = Cor.SamplePars[key]
        Cor.Write_Config() 
        Update_User_Interface() 
        PlotSingle(PlotSingleFrame)
        OpenRef()
         
    def incdec_t_lay1(): 
        Cor.SamplePars['t_lay1'] = incdec(Cor.SamplePars['t_lay1'],SamplePars_SVs['t_lay1'].get())
        Cor.Fit_done = 'no'; Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); MakeFitFrame(FitFrame); PlotSingle(PlotSingleFrame)
    def incdec_rho_lay1(): 
        Cor.SamplePars['rho_lay1'] = incdec(Cor.SamplePars['rho_lay1'],SamplePars_SVs['rho_lay1'].get())
        Cor.Fit_done = 'no'; Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar1_lay1(): 
        Cor.SamplePars['VEPar1_lay1'] = incdec(Cor.SamplePars['VEPar1_lay1'],SamplePars_SVs['VEPar1_lay1'].get())
        Cor.Fit_done = 'no'; Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame) 
    def incdec_VEPar2_lay1(): 
        Cor.SamplePars['VEPar2_lay1'] = incdec(Cor.SamplePars['VEPar2_lay1'],SamplePars_SVs['VEPar2_lay1'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar1_PLexpt_lay1(): 
        Cor.SamplePars['VEPar1_PLexpt_lay1'] = incdec(Cor.SamplePars['VEPar1_PLexpt_lay1'],SamplePars_SVs['VEPar1_PLexpt_lay1'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar2_PLexpt_lay1(): 
        Cor.SamplePars['VEPar2_PLexpt_lay1'] = incdec(Cor.SamplePars['VEPar2_PLexpt_lay1'],SamplePars_SVs['VEPar2_PLexpt_lay1'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_t_lay2(): 
        Cor.SamplePars['t_lay2'] = incdec(Cor.SamplePars['t_lay2'],SamplePars_SVs['t_lay2'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); MakeFitFrame(FitFrame); PlotSingle(PlotSingleFrame)
    def incdec_rho_lay2(): 
        Cor.SamplePars['rho_lay2'] = incdec(Cor.SamplePars['rho_lay2'],SamplePars_SVs['rho_lay2'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar1_lay2(): 
        Cor.SamplePars['VEPar1_lay2'] = incdec(Cor.SamplePars['VEPar1_lay2'],SamplePars_SVs['VEPar1_lay2'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar2_lay2(): 
        Cor.SamplePars['VEPar2_lay2'] = incdec(Cor.SamplePars['VEPar2_lay2'],SamplePars_SVs['VEPar2_lay2'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar1_PLexpt_lay2(): 
        Cor.SamplePars['VEPar1_PLexpt_lay2'] = incdec(Cor.SamplePars['VEPar1_PLexpt_lay2'],SamplePars_SVs['VEPar1_PLexpt_lay2'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar2_PLexpt_lay2(): 
        Cor.SamplePars['VEPar2_PLexpt_lay2'] = incdec(Cor.SamplePars['VEPar2_PLexpt_lay2'],SamplePars_SVs['VEPar2_PLexpt_lay2'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_rho_lay3(): 
        Cor.SamplePars['rho_lay3'] = incdec(Cor.SamplePars['rho_lay3'],SamplePars_SVs['rho_lay3'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar1_lay3(): 
        Cor.SamplePars['VEPar1_lay3'] = incdec(Cor.SamplePars['VEPar1_lay3'],SamplePars_SVs['VEPar1_lay3'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar2_lay3(): 
        Cor.SamplePars['VEPar2_lay3'] = incdec(Cor.SamplePars['VEPar2_lay3'],SamplePars_SVs['VEPar2_lay3'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar1_PLexpt_lay3(): 
        Cor.SamplePars['VEPar1_PLexpt_lay3'] = incdec(Cor.SamplePars['VEPar1_PLexpt_lay3'],SamplePars_SVs['VEPar1_PLexpt_lay3'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VEPar2_PLexpt_lay3(): 
        Cor.SamplePars['VEPar2_PLexpt_lay3'] = incdec(Cor.SamplePars['VEPar2_PLexpt_lay3'],SamplePars_SVs['VEPar2_PLexpt_lay3'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_VertScaleR(): 
        Cor.SamplePars['VertScaleR'] = incdec(Cor.SamplePars['VertScaleR'],SamplePars_SVs['VertScaleR'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)
    def incdec_AspRat(): 
        Cor.SamplePars['AspRat'] = incdec(Cor.SamplePars['AspRat'],SamplePars_SVs['AspRat'].get())
        Cor.Fit_done = 'no';Cor.adjust_Pars_to_Limits(); Cor.Write_Config()
        MakeSampleParsFrame(cntr); PlotSingle(PlotSingleFrame)

    def enter_VEPar_lay1(event): 
        VEPar = event.widget.get()
        VEtype_old = Cor.SamplePars['VEtype_lay1']
        for i,VEPar_Choice in enumerate(VE_Choices):
            if VEPar == VEPar_Choice: 
                Cor.SamplePars['VEtype_lay1'] = i
                VEtype_new = Cor.SamplePars['VEtype_lay1']
                VEPar1_old = Cor.SamplePars['VEPar1_lay1']
                VEPar2_old = Cor.SamplePars['VEPar2_lay1']
                VEPar1_PLexpt_old = Cor.SamplePars['VEPar1_PLexpt_lay1']
                VEPar2_PLexpt_old = Cor.SamplePars['VEPar2_PLexpt_lay1']
                Cor.SamplePars['VEPar1_lay1'],Cor.SamplePars['VEPar2_lay1'],Cor.SamplePars['VEPar1_PLexpt_lay1'],\
                    Cor.SamplePars['VEPar2_PLexpt_lay1'] = \
                    Cor.VEPars_Old2New(VEPar1_old,VEPar2_old,VEPar1_PLexpt_old,VEPar2_PLexpt_old,VEtype_old,VEtype_new)
        Cor.Fit_done = 'no'; Cor.Write_Config() 
        PlotSingle(PlotSingleFrame)
        Limits.Set_Defaults()
        MakeSampleParsFrame(cntr)

    def enter_VEPar_lay2(event):    
        VEPar = event.widget.get()
        VEtype_old = Cor.SamplePars['VEtype_lay2']
        for i,VEPar_Choice in enumerate(VE_Choices):
            if VEPar == VEPar_Choice: 
                Cor.SamplePars['VEtype_lay2'] = i
                VEtype_new = Cor.SamplePars['VEtype_lay2']
                VEPar1_old = Cor.SamplePars['VEPar1_lay2']
                VEPar2_old = Cor.SamplePars['VEPar2_lay2']
                VEPar1_PLexpt_old = Cor.SamplePars['VEPar1_PLexpt_lay2']
                VEPar2_PLexpt_old = Cor.SamplePars['VEPar2_PLexpt_lay2']
                Cor.SamplePars['VEPar1_lay2'],Cor.SamplePars['VEPar2_lay2'],Cor.SamplePars['VEPar1_PLexpt_lay2'],\
                    Cor.SamplePars['VEPar2_PLexpt_lay2'] = \
                    Cor.VEPars_Old2New(VEPar1_old,VEPar2_old,VEPar1_PLexpt_old,VEPar2_PLexpt_old,VEtype_old,VEtype_new)
        Cor.Fit_done = 'no'; Cor.Write_Config()
        PlotSingle(PlotSingleFrame) 
        Limits.Set_Defaults()
        MakeSampleParsFrame(cntr)        

    def enter_VEPar_lay3(event): 
        VEPar = event.widget.get()
        VEtype_old = Cor.SamplePars['VEtype_lay3']
        for i,VEPar_Choice in enumerate(VE_Choices):
            if VEPar == VEPar_Choice: 
                Cor.SamplePars['VEtype_lay3'] = i
                VEtype_new = Cor.SamplePars['VEtype_lay3']
                VEPar1_old = Cor.SamplePars['VEPar1_lay3']
                VEPar2_old = Cor.SamplePars['VEPar2_lay3']
                VEPar1_PLexpt_old = Cor.SamplePars['VEPar1_PLexpt_lay3']
                VEPar2_PLexpt_old = Cor.SamplePars['VEPar2_PLexpt_lay3']
                Cor.SamplePars['VEPar1_lay3'],Cor.SamplePars['VEPar2_lay3'],Cor.SamplePars['VEPar1_PLexpt_lay3'],\
                    Cor.SamplePars['VEPar2_PLexpt_lay3'] = \
                    Cor.VEPars_Old2New(VEPar1_old,VEPar2_old,VEPar1_PLexpt_old,VEPar2_PLexpt_old,VEtype_old,VEtype_new)
        Cor.Fit_done = 'no'; Cor.Write_Config()
        PlotSingle(PlotSingleFrame) 
        Limits.Set_Defaults()
        MakeSampleParsFrame(cntr)        

    def Check_lay1(): 
        if int(i_Show_lay1_IV.get()) == 1: Cor.Show_lay1 = 'yes'
        if int(i_Show_lay1_IV.get()) == 0: Cor.Show_lay1 = 'no'
        Cor.Check_Show_IncInFit()
        Cor.Write_Config()
        PlotSingle(PlotSingleFrame)
        MakeSampleParsFrame(cntr)
        
    def Check_lay2(): 
        if int(i_Show_lay2_IV.get()) == 1: Cor.Show_lay2 = 'yes'
        if int(i_Show_lay2_IV.get()) == 0: Cor.Show_lay2 = 'no'
        Cor.Check_Show_IncInFit()
        Cor.Write_Config()
        PlotSingle(PlotSingleFrame)
        MakeSampleParsFrame(cntr)
        MakeFitFrame(FitFrame)
        
    def Check_bulk(): 
        if int(i_Show_bulk_IV.get()) == 1: Cor.Show_bulk = 'yes'
        if int(i_Show_bulk_IV.get()) == 0: Cor.Show_bulk = 'no'
        Cor.Check_Show_IncInFit()
        Cor.Write_Config()
        PlotSingle(PlotSingleFrame)
        MakeSampleParsFrame(cntr)
        
    def Check_t_lay1():
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['t_lay1'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['t_lay1'].set(0) 
        else: Cor.IncPars['t_lay1']=int(IncPars_IVs['t_lay1'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VEPar1_lay1():      
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar1_lay1'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar1_lay1'].set(0) 
        else: Cor.IncPars['VEPar1_lay1']      = int(IncPars_IVs['VEPar1_lay1'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VEPar2_lay1():     
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar2_lay1'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar2_lay1'].set(0) 
        else: Cor.IncPars['VEPar2_lay1']     = int(IncPars_IVs['VEPar2_lay1'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VEPar1_PLexpt_lay1():  
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar1_PLexpt_lay1'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar1_PLexpt_lay1'].set(0) 
        else: Cor.IncPars['VEPar1_PLexpt_lay1']  = int(IncPars_IVs['VEPar1_PLexpt_lay1'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VEPar2_PLexpt_lay1(): 
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar2_PLexpt_lay1'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar2_PLexpt_lay1'].set(0) 
        else: Cor.IncPars['VEPar2_PLexpt_lay1'] = int(IncPars_IVs['VEPar2_PLexpt_lay1'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_t_lay2():       
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['t_lay2'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['t_lay2'].set(0) 
        else: Cor.IncPars['t_lay2'] = int(IncPars_IVs['t_lay2'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VEPar1_lay2():      
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar1_lay2'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar1_lay2'].set(0) 
        else: Cor.IncPars['VEPar1_lay2'] = int(IncPars_IVs['VEPar1_lay2'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VEPar2_lay2():     
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar2_lay2'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar2_lay2'].set(0) 
        else: Cor.IncPars['VEPar2_lay2'] = int(IncPars_IVs['VEPar2_lay2'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VEPar1_PLexpt_lay2():  
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar1_PLexpt_lay2'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar1_PLexpt_lay2'].set(0) 
        else: Cor.IncPars['VEPar1_PLexpt_lay2']  = int(IncPars_IVs['VEPar1_PLexpt_lay2'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VEPar2_PLexpt_lay2(): 
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar2_PLexpt_lay2'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar2_PLexpt_lay2'].set(0) 
        else: Cor.IncPars['VEPar2_PLexpt_lay2'] = int(IncPars_IVs['VEPar2_PLexpt_lay2'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VEPar1_lay3():      
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar1_lay3'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar1_lay3'].set(0) 
        else: Cor.IncPars['VEPar1_lay3']      = int(IncPars_IVs['VEPar1_lay3'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VEPar2_lay3():     
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar2_lay3'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar2_lay3'].set(0) 
        else: Cor.IncPars['VEPar2_lay3']     = int(IncPars_IVs['VEPar2_lay3'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VEPar1_PLexpt_lay3():  
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar1_PLexpt_lay3'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar1_PLexpt_lay3'].set(0) 
        else: Cor.IncPars['VEPar1_PLexpt_lay3']  = int(IncPars_IVs['VEPar1_PLexpt_lay3'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VEPar2_PLexpt_lay3(): 
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VEPar2_PLexpt_lay3'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VEPar2_PLexpt_lay3'].set(0) 
        else: Cor.IncPars['VEPar2_PLexpt_lay3'] = int(IncPars_IVs['VEPar2_PLexpt_lay3'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_VertScaleR():      
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['VertScaleR'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['VertScaleR'].set(0) 
        else: Cor.IncPars['VertScaleR'] = int(IncPars_IVs['VertScaleR'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
    def Check_AspRat():    
        Calc_nFPars() 
        if Cor.nFPars >= Cor.nFParsmax and int(IncPars_IVs['AspRat'].get()) == 1: 
            tk.messagebox.showinfo('','Reduce number of fit parameters to \u2264 6') 
            IncPars_IVs['AspRat'].set(0) 
        else: Cor.IncPars['AspRat']    = int(IncPars_IVs['AspRat'].get()); Cor.Fit_done = 'no'; Cor.Write_Config()
        
    SamplePars_SVs_List = []; IncPars_IVs_List = [] 
    
    for key in Cor.keys:
        if not key in ['VEtype_lay1','VEtype_lay2','VEtype_lay3']:
            if not np.isnan(Cor.SampleStdErrs[key]) and Cor.Fit_done == 'yes' and Cor.IncPars[key] == 1:
                SamplePars_SVs_List.append(tk.StringVar(cntr,str(np.round(Cor.SamplePars[key],3))+ '\u00b1' + \
                          str(np.round(Cor.SampleStdErrs[key],5))))
            if np.isnan(Cor.SampleStdErrs[key]) or Cor.Fit_done == 'no' or Cor.IncPars[key] == 0:
                SamplePars_SVs_List.append(tk.StringVar(cntr,np.round(Cor.SamplePars[key],3)))
        else :  SamplePars_SVs_List.append(tk.StringVar(cntr,Cor.SamplePars[key]))       
        IncPars_IVs_List.append(           tk.IntVar(   cntr,Cor.IncPars[key]))
    SamplePars_SVs = dict(zip(Cor.keys,SamplePars_SVs_List))
    IncPars_IVs    = dict(zip(Cor.keys,IncPars_IVs_List))
    f_width=12
    if Cor.Show_lay1 == 'yes':
        tk.Label(cntr,text='Thickness [nm]'      ,width=f_width                   ).grid(row=0,column=1)
        tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]',width=f_width-3                 ).grid(row=0,column=3)
        tk.Label(cntr,text=Cor.VE_Labels1[Cor.SamplePars['VEtype_lay1']],width=f_width).grid(row=0,column=4)
        tk.Label(cntr,text=Cor.VE_Labels2[Cor.SamplePars['VEtype_lay1']],width=f_width).grid(row=0,column=8)
        tk.Label(cntr,text=u'\u03B2\''           ,width=f_width-3                 ).grid(row=0,column=6)
        tk.Label(cntr,text=u'\u03B2\'\''         ,width=f_width-3                 ).grid(row=0,column=10)
        tk.Label(cntr,text='Viscoelastic Par''s' ,width=f_width+1                 ).grid(row=0,column=12)

    if Cor.Show_lay2 == 'yes':
        tk.Label(cntr,text='Thickness [nm]'      ,width=f_width                   ).grid(row=2,column=1)
        tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]',width=f_width-3                 ).grid(row=2,column=3)
        tk.Label(cntr,text=Cor.VE_Labels1[Cor.SamplePars['VEtype_lay2']],width=f_width).grid(row=2,column=4)
        tk.Label(cntr,text=Cor.VE_Labels2[Cor.SamplePars['VEtype_lay2']],width=f_width).grid(row=2,column=8)
        tk.Label(cntr,text=u'\u03B2\''           ,width=f_width                   ).grid(row=2,column=6)
        tk.Label(cntr,text=u'\u03B2\'\''         ,width=f_width-3                 ).grid(row=2,column=10)
        tk.Label(cntr,text='Viscoelastic Par''s' ,width=f_width+1                 ).grid(row=2,column=12)

    if Cor.Show_bulk == 'yes':
        tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]',width=f_width-3                 ).grid(row=4,column=3)
        tk.Label(cntr,text=Cor.VE_Labels1[Cor.SamplePars['VEtype_lay3']],width=f_width).grid(row=4,column=4)
        tk.Label(cntr,text=Cor.VE_Labels2[Cor.SamplePars['VEtype_lay3']],width=f_width).grid(row=4,column=8)
        tk.Label(cntr,text=u'\u03B2\''           ,width=f_width-3                 ).grid(row=4,column=6)
        tk.Label(cntr,text=u'\u03B2\'\''         ,width=f_width-3                 ).grid(row=4,column=10)
        tk.Label(cntr,text='Viscoelastic Par''s' ,width=f_width+1                 ).grid(row=4,column=12)
        tk.Label(cntr,text='Roughness [nm]'      ,width=f_width                   ).grid(row=0,column=13)
        if Cor.SamplePars['VertScaleR'] > 0:
            tk.Label(cntr,text='Aspect Ratio',width=f_width                       ).grid(row=2,column=13)

    tk.Checkbutton(cntr,text='1',   variable=i_Show_lay1_IV,command=Check_lay1).grid(row=1,column=0)
    tk.Checkbutton(cntr,text='2',   variable=i_Show_lay2_IV,command=Check_lay2).grid(row=3,column=0)
    tk.Checkbutton(cntr,text='bulk',variable=i_Show_bulk_IV,command=Check_bulk).grid(row=5,column=2)

    tk.Button(cntr,text ='Make Reference',command=Make_Reference,anchor='w').grid(row=5,column=13,columnspan=2,sticky='E')
    tk.Button(cntr,text ='FPars \u2192 Clpbd',command=FPars_to_Clpbd,anchor='w').grid(row=5,column=1,columnspan=1,sticky='E')
    
    if Cor.Show_lay1 == 'yes':
        vals=(SamplePars_SVs['t_lay1'].get(),'+','-')
        t_1_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['t_lay1'],wrap=True,width=12,values=vals,command=incdec_t_lay1)
        t_1_Entry.grid(row=1,column=1)
        t_1_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'t_lay1'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['t_lay1'],command=Check_t_lay1).grid(row=1,column=2,sticky='W')
        vals=(SamplePars_SVs['rho_lay1'].get(),'+','-')
        rho_1_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['rho_lay1'],wrap=True,width=12-3,values=vals,command=incdec_rho_lay1)
        rho_1_Entry.grid(row=1,column=3)
        rho_1_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'rho_lay1'))
        vals=(SamplePars_SVs['VEPar1_lay1'].get(),'+','-')
        Jp_1_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar1_lay1'],wrap=True,width=12,values=vals,command=incdec_VEPar1_lay1)
        Jp_1_Entry.grid(row=1,column=4)
        Jp_1_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar1_lay1'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar1_lay1'],command=Check_VEPar1_lay1).grid(row=1,column=5)
        vals=(SamplePars_SVs['VEPar2_lay1'].get(),'+','-')
        Jpp_1_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar2_lay1'],wrap=True,width=12,values=vals,command=incdec_VEPar2_lay1)
        Jpp_1_Entry.grid(row=1,column=8)
        Jpp_1_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar2_lay1'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar2_lay1'],command=Check_VEPar2_lay1 ).grid(row=1,column=9)
        vals=(SamplePars_SVs['VEPar1_PLexpt_lay1'].get(),'+','-')
        Jp_PLexpt_1_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar1_PLexpt_lay1'],wrap=True,width=12-3,values=vals,command=incdec_VEPar1_PLexpt_lay1)
        Jp_PLexpt_1_Entry.grid(row=1,column=6)
        Jp_PLexpt_1_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar1_PLexpt_lay1'))
        
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar1_PLexpt_lay1'],command=Check_VEPar1_PLexpt_lay1).grid(row=1,column=7)
        vals=(SamplePars_SVs['VEPar2_PLexpt_lay1'].get(),'+','-')
        Jpp_PLexpt_1_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar2_PLexpt_lay1'],wrap=True,width=12-3,values=vals,command=incdec_VEPar2_PLexpt_lay1)
        Jpp_PLexpt_1_Entry.grid(row=1,column=10)
        Jpp_PLexpt_1_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar2_PLexpt_lay1'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar2_PLexpt_lay1'],command=Check_VEPar2_PLexpt_lay1).grid(row=1,column=11)
    
        VEPar_cb_1 = tk.ttk.Combobox(cntr,state='readonly',width=f_width-1,textvariable=SamplePars_SVs['VEtype_lay1'],values=VE_Choices)
        VEPar_cb_1.grid(row=1,column=12)
        VEPar_cb_1.current(Cor.SamplePars['VEtype_lay1'])
        VEPar_cb_1.bind('<<ComboboxSelected>>',enter_VEPar_lay1)

    if Cor.Show_lay2 == 'yes':
        vals=(SamplePars_SVs['t_lay2'].get(),'+','-')
        t_2_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['t_lay2'],wrap=True,width=12,values=vals,command=incdec_t_lay2)
        t_2_Entry.grid(row=3,column=1)
        t_2_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'t_lay2'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['t_lay2'],command=Check_t_lay2).grid(row=3,column=2,sticky='W')
        vals=(SamplePars_SVs['rho_lay2'].get(),'+','-')
        rho_2_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['rho_lay2'],wrap=True,width=12-3,values=vals,command=incdec_rho_lay2)
        rho_2_Entry.grid(row=3,column=3)
        rho_2_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'rho_lay2'))
        vals=(SamplePars_SVs['VEPar1_lay2'].get(),'+','-')
        Jp_2_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar1_lay2'],wrap=True,width=12,values=vals,command=incdec_VEPar1_lay2)
        Jp_2_Entry.grid(row=3,column=4)
        Jp_2_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar1_lay2'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar1_lay2'],command=Check_VEPar1_lay2).grid(row=3,column=5)
        vals=(SamplePars_SVs['VEPar2_lay2'].get(),'+','-')
        Jpp_2_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar2_lay2'],wrap=True,width=12,values=vals,command=incdec_VEPar2_lay2)
        Jpp_2_Entry.grid(row=3,column=8)
        Jpp_2_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar2_lay2'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar2_lay2'],command=Check_VEPar2_lay2).grid(row=3,column=9)
        vals=(SamplePars_SVs['VEPar1_PLexpt_lay2'].get(),'+','-')
        Jp_PLexpt_2_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar1_PLexpt_lay2'],wrap=True,width=12-3,values=vals,command=incdec_VEPar1_PLexpt_lay2)
        Jp_PLexpt_2_Entry.grid(row=3,column=6)
        Jp_PLexpt_2_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar1_PLexpt_lay2'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar1_PLexpt_lay2'],command=Check_VEPar1_PLexpt_lay2).grid(row=3,column=7)
        vals=(SamplePars_SVs['VEPar2_PLexpt_lay2'].get(),'+','-')
        Jpp_PLexpt_2_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar2_PLexpt_lay2'],wrap=True,width=12-3,values=vals,command=incdec_VEPar2_PLexpt_lay2)
        Jpp_PLexpt_2_Entry.grid(row=3,column=10)
        Jpp_PLexpt_2_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar2_PLexpt_lay2'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar2_PLexpt_lay2'],command=Check_VEPar2_PLexpt_lay2                                ).grid(row=3,column=11)
        VEPar_cb_2 = tk.ttk.Combobox(cntr,state='readonly',width=f_width-1,textvariable=SamplePars_SVs['VEtype_lay2'],values=VE_Choices)
        VEPar_cb_2.grid(row=3,column=12)
        VEPar_cb_2.current(Cor.SamplePars['VEtype_lay2'])
        VEPar_cb_2.bind('<<ComboboxSelected>>',enter_VEPar_lay2)
    
    if Cor.Show_bulk == 'yes':
        vals=(SamplePars_SVs['rho_lay3'].get(),'+','-')
        rho_3_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['rho_lay3'],wrap=True,width=12-3,values=vals,command=incdec_rho_lay3)
        rho_3_Entry.grid(row=5,column=3)
        rho_3_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'rho_lay3'))
        vals=(SamplePars_SVs['VEPar1_lay3'].get(),'+','-')
        Jp_3_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar1_lay3'],wrap=True,width=12,values=vals,command=incdec_VEPar1_lay3)
        Jp_3_Entry.grid(row=5,column=4)
        Jp_3_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar1_lay3'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar1_lay3'],command=Check_VEPar1_lay3).grid(row=5,column=5)
        vals=(SamplePars_SVs['VEPar2_lay3'].get(),'+','-')
        Jpp_3_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar2_lay3'],wrap=True,width=12,values=vals,command=incdec_VEPar2_lay3)
        Jpp_3_Entry.grid(row=5,column=8)
        Jpp_3_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar2_lay3'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar2_lay3'],command=Check_VEPar2_lay3).grid(row=5,column=9)
        vals=(SamplePars_SVs['VEPar1_PLexpt_lay3'].get(),'+','-')
        Jp_PLexpt_3_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar1_PLexpt_lay3'],wrap=True,width=12-3,values=vals,command=incdec_VEPar1_PLexpt_lay3)
        Jp_PLexpt_3_Entry.grid(row=5,column=6)
        Jp_PLexpt_3_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar1_PLexpt_lay3'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar1_PLexpt_lay3'],command=Check_VEPar1_PLexpt_lay3).grid(row=5,column=7)
        vals=(SamplePars_SVs['VEPar2_PLexpt_lay3'].get(),'+','-')
        Jpp_PLexpt_3_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VEPar2_PLexpt_lay3'],wrap=True,width=12-3,values=vals,command=incdec_VEPar2_PLexpt_lay3)
        Jpp_PLexpt_3_Entry.grid(row=5,column=10)
        Jpp_PLexpt_3_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VEPar2_PLexpt_lay3'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VEPar2_PLexpt_lay3'],command=Check_VEPar2_PLexpt_lay3).grid(row=5,column=11)
        vals=(SamplePars_SVs['VertScaleR'].get(),'+','-')
        VertScaleR_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['VertScaleR'],wrap=True,width=12,values=vals,command=incdec_VertScaleR)
        VertScaleR_Entry.grid(row=1,column=13)
        VertScaleR_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'VertScaleR'))
        tk.Checkbutton(cntr,variable=IncPars_IVs['VertScaleR'],command=Check_VertScaleR).grid(row=1,column=14,sticky='W')
        if Cor.SamplePars['VertScaleR'] > 0:
            vals=(SamplePars_SVs['AspRat'].get(),'+','-')
            AspRat_Entry = tk.Spinbox(cntr,textvariable=SamplePars_SVs['AspRat'],wrap=True,width=12,values=vals,command=incdec_AspRat)
            AspRat_Entry.grid(row=3,column=13)
            AspRat_Entry.bind('<Return>',lambda event: Enter_Stuff_Pars(event,'AspRat'))
            tk.Checkbutton(cntr,variable=IncPars_IVs['AspRat'],command=Check_AspRat).grid(row=3,column=14,sticky='W')
        else: 
            Cor.IncPars['AspRat'] = 0; IncPars_IVs['AspRat'].set(0); Cor.Write_Config()
        VEPar_cb_3 = tk.ttk.Combobox(cntr,state='readonly',width=f_width-1,textvariable=SamplePars_SVs['VEtype_lay3'],values=VE_Choices)
        VEPar_cb_3.grid(row=5,column=12)
        VEPar_cb_3.current(Cor.SamplePars['VEtype_lay3'])
        VEPar_cb_3.bind('<<ComboboxSelected>>',enter_VEPar_lay3)
    SoftnessEstimator = Cor.Calc_SoftnessEstimator()
    if Cor.Model == 'Thin_Film_Jpp1 small':
        tk.Label(cntr,text = 'J\'\'_1 \u03c9\u03b7\u2032_bulk: ' + str(np.round(SoftnessEstimator,3)))\
            .grid(row=4,column=13,columnspan=3,sticky='E')

def MakeDfcbynsFrame(cntr):
    for widget in cntr.winfo_children(): widget.destroy()
    f_fund_SV      = tk.StringVar(cntr,np.round(Cor.f_fund/1e6,2))
    Zq_SV          = tk.StringVar(cntr,np.round(Cor.Zq    /1e6,2))
    f_cen_SV       = tk.StringVar(cntr,np.round(Cor.f_cen /1e6,2))
    DD_DGbyn_Labels = ['\u0394\u0393/n','\u0394D']
    
    def enter_DD_DGbyn(event):
        DD_DGbyn = event.widget.get()
        for i,DD_DGbyn_Label in enumerate(DD_DGbyn_Labels):
            if DD_DGbyn == DD_DGbyn_Label: Cor.DD_DGbyn = Cor.DD_DGbyn_strings[i]
        Cor.Write_Config()
        Make_Menu()
        MakeDfcbynsFrame(DfcbynsFrame)
        PlotDfDGbyns(PlotDfDGbynsFrame)
        PlotSingle(PlotSingleFrame)

    def ImportFromClipboard():
        cliptext = Root.clipboard_get()
        lines = cliptext.splitlines()
        for iovt in range(Cor.novt):
            Cor.Dfbyns[iovt] = np.nan
            Cor.DGbyns[iovt] = np.nan
        for j in range(len(lines)):
            try: 
                nL = int(lines[j].split()[0])
                DfbynL = float(lines[j].split()[1])
                DGbynOrDDL = float(lines[j].split()[2])
                for iovtt,n in enumerate(Cor.n_arr):
                    if nL == n:
                        iovt = iovtt
                        Cor.Dfbyns[iovt] = DfbynL
                        if Cor.DD_DGbyn == 'DGbyn': Cor.DGbyns[iovt] = DGbynOrDDL
                        if Cor.DD_DGbyn == 'DD':    Cor.DGbyns[iovt] = DGbynOrDDL/2*Cor.f_fund*1e-6
            except: pass
        for iovt in range(Cor.novt): 
            if not np.isnan(Cor.Dfbyns[iovt]) and not np.isnan(Cor.DGbyns[iovt]):
                Cor.OvtInc[iovt] = 1
            else: Cor.OvtInc[iovt] = 0 
        Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns     

        Cor.Fit_done = 'no'    
        Cor.Write_Config()
        PlotSingle(PlotSingleFrame)
        MakeDfcbynsFrame(DfcbynsFrame)    

    def NewBLine():
        if os.path.isfile('~tmp_for_unhide.qtf'): DfDGbyns_for_Unhide = np.loadtxt('~tmp_for_unhide.qtf',skiprows=1)
        else                                    : DfDGbyns_for_Unhide = np.ones((1,4*Cor.novt+3))*np.nan
        for iovt in range(Cor.novt):
            DfDGbyns_for_Unhide[:,2+4*iovt  ] -= Cor.Dfcbyns[iovt].real
            DfDGbyns_for_Unhide[:,2+4*iovt+1] -= Cor.Dfcbyns[iovt].imag
            DfDGbyns_for_Unhide[:,2+4*iovt+2] -= Cor.Dfcbyns[iovt].real
            DfDGbyns_for_Unhide[:,2+4*iovt+3] -= Cor.Dfcbyns[iovt].imag
        np.savetxt('~tmp_for_unhide.qtf',DfDGbyns_for_Unhide,header=TT.header_DfDGbyns,delimiter='\t',newline='\n')

        for iovt in range(Cor.novt):
            TT.DfDGbyns[:,2+4*iovt  ] -= Cor.Dfcbyns[iovt].real
            TT.DfDGbyns[:,2+4*iovt+1] -= Cor.Dfcbyns[iovt].imag
            TT.DfDGbyns[:,2+4*iovt+2] -= Cor.Dfcbyns[iovt].real
            TT.DfDGbyns[:,2+4*iovt+3] -= Cor.Dfcbyns[iovt].imag
            Cor.Dfbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt  ]
            Cor.DGbyns[iovt] = TT.DfDGbyns[Cor.i_selec,2+4*iovt+1]
        Cor.Dfcbyns = Cor.Dfbyns + 1j * Cor.DGbyns; MakeDfcbynsFrame(DfcbynsFrame)
        TT.Make_headers(); np.savetxt('~tmp.qtf',TT.DfDGbyns,header=TT.header_DfDGbyns,delimiter='\t',newline='\n')
        PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
        Cor.i_strt_avg = 0; Cor.i_stop_avg = 0;
        Cor.Write_Config()

    def Enter_Stuff_Dfcbyns(event,iovt,WhichStuffStr,key):
        if WhichStuffStr == 'Df':
            string = Df_SVs[iovt].get(); string.strip()
            try: Cor.Dfbyns[iovt] = np.float64(string);
            except: pass
        if WhichStuffStr == 'DG': 
            string = DG_SVs[iovt].get(); string.strip()
            try: Cor.DGbyns[iovt] = np.float64(string)
            except: pass
        if WhichStuffStr == 'f_fund': 
            string = f_fund_SV.get(); string.strip()
            try: Cor.f_fund = np.float64(string)*1e6
            except: pass    
        if WhichStuffStr == 'Zq': 
            string = Zq_SV.get(); string.strip()
            try: Cor.Zq = np.float64(string)*1e6
            except: pass    
        if WhichStuffStr == 'f_cen': 
            string = f_cen_SV.get(); string.strip()
            try: Cor.f_cen = np.float64(string)*1e6
            except: pass
        Cor.Fit_done = 'no' 
        Cor.Dfcbyns.real = Cor.Dfbyns
        Cor.Dfcbyns.imag = Cor.DGbyns
        Cor.Write_Config() 
        PlotSingle(PlotSingleFrame) 
        MakeDfcbynsFrame(DfcbynsFrame)

    Df_SVs = []; DG_SVs = []; OvtInc_IVs = []
    if Cor.i_current < Cor.i_strt_fit: Cor.i_current = Cor.i_strt_fit 
    if Cor.i_current > Cor.i_stop_fit: Cor.i_current = Cor.i_stop_fit 
    for iovt in range(Cor.novt):  
        if np.isnan(Cor.Dfbyns[iovt]): Df_SVs.append(tk.StringVar(cntr,''))
        else: Df_SVs.append(tk.StringVar(cntr,np.round(Cor.Dfbyns[iovt],2)))
        if np.isnan(Cor.DGbyns[iovt]): DG_SVs.append(tk.StringVar(cntr,''))
        else:     
            if Cor.DD_DGbyn == 'DD': 
                DG_SVs.append(tk.StringVar(cntr,np.round(Cor.DGbyns[iovt]/Cor.f_fund*2./1e-6,2)))
            if Cor.DD_DGbyn == 'DGbyn': 
                DG_SVs.append(tk.StringVar(cntr,np.round(Cor.DGbyns[iovt],2)))
        OvtInc_IVs.append(tk.IntVar(cntr,int(Cor.OvtInc[iovt])))
    if Cor.i_selec > 0 and Cor.i_selec < len(TT.DfDGbyns) and Cor.i_stop_avrg == Cor.i_strt_avrg :     
        tk.Label(cntr,text=str(np.round(TT.DfDGbyns[Cor.i_selec,Cor.i_col_x],1))).grid(row=0,column=0)
    if Cor.i_stop_avrg > Cor.i_strt_avrg and Cor.i_strt_avrg < len(TT.DfDGbyns) and Cor.i_stop_avrg < len(TT.DfDGbyns):  
        tk.Label(cntr,text=str(np.round(TT.DfDGbyns[Cor.i_strt_avrg,Cor.i_col_x],1))+'-'+\
                           str(np.round(TT.DfDGbyns[Cor.i_stop_avrg,Cor.i_col_x],1))   ).grid(row=0,column=0)
    tk.Label(cntr,text='\u0394f/n [Hz]').grid(row=0,column=1)
    if Cor.DD_DGbyn == 'DD'   : tk.Label(cntr,text='\u0394D [10\u207B\u2076]').grid(row=0,column=2)
    if Cor.DD_DGbyn == 'DGbyn': tk.Label(cntr,text='\u0394\u0393/n [Hz]').grid(row=0,column=2)
    
    entriesDf = []; entriesDG = []
    for iovt,n in enumerate(Cor.n_arr):
        tk.Label(cntr,width=6,text=str(round(n*Cor.f_fund/1e6)) + ' MHz',anchor='e').grid(row=iovt+1,column=0,sticky='E')
        entriesDf.append(tk.Entry(cntr,width=7,textvariable=Df_SVs[iovt]))
        entriesDf[iovt].grid(row=iovt+1,column=1)
        if iovt == 0: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,0,'Df',''))
        if iovt == 1: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,1,'Df',''))
        if iovt == 2: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,2,'Df',''))
        if iovt == 3: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,3,'Df',''))
        if iovt == 4: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,4,'Df',''))
        if iovt == 5: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,5,'Df',''))
        if iovt == 6: entriesDf[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,6,'Df',''))
        entriesDG.append(tk.Entry(cntr,width=7,textvariable=DG_SVs[iovt]))
        entriesDG[iovt].grid(row=iovt+1,column=2)
        if iovt == 0: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,0,'DG',''))
        if iovt == 1: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,1,'DG',''))
        if iovt == 2: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,2,'DG',''))
        if iovt == 3: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,3,'DG',''))
        if iovt == 4: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,4,'DG',''))
        if iovt == 5: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,5,'DG',''))
        if iovt == 6: entriesDG[iovt].bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,6,'DG',''))

    def Check_ovt1():
        Cor.OvtInc[0] = int(OvtInc_IVs[0].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    def Check_ovt2():
        Cor.OvtInc[1] = int(OvtInc_IVs[1].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    def Check_ovt3():
        Cor.OvtInc[2] = int(OvtInc_IVs[2].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    def Check_ovt4():
        Cor.OvtInc[3] = int(OvtInc_IVs[3].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    def Check_ovt5():
        Cor.OvtInc[4] = int(OvtInc_IVs[4].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    def Check_ovt6():
        Cor.OvtInc[5] = int(OvtInc_IVs[5].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    def Check_ovt7():
        Cor.OvtInc[6] = int(OvtInc_IVs[6].get()); Cor.Write_Config(); PlotSingle(PlotSingleFrame); PlotDfDGbyns(PlotDfDGbynsFrame)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[0],command=Check_ovt1).grid(row=1,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[1],command=Check_ovt2).grid(row=2,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[2],command=Check_ovt3).grid(row=3,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[3],command=Check_ovt4).grid(row=4,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[4],command=Check_ovt5).grid(row=5,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[5],command=Check_ovt6).grid(row=6,column=3)
    tk.Checkbutton(cntr,anchor='w',variable=OvtInc_IVs[6],command=Check_ovt7).grid(row=7,column=3)

    tk.Label(cntr,width=11,text='f\u2080 [MHz]'             ,anchor='e').grid(row=9 ,column=0,columnspan=2,sticky='E')
    tk.Label(cntr,width=13,text='Z_q [10\u2076 kg/m\u00B2s]',anchor='e').grid(row=10,column=0,columnspan=2,sticky='E')
    tk.Label(cntr,width=11,text='f_cen [MHz]'               ,anchor='e',fg='blue').grid(row=11,column=0,columnspan=2,sticky='E')
    f_fund_Entry = tk.Entry(cntr,width=5,textvariable=f_fund_SV      )
    f_fund_Entry.grid(row=9,column=2,sticky='W')
    f_fund_Entry.bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,0,'f_fund',''))
    Zq_Entry = tk.Entry(cntr,width=5,textvariable=Zq_SV                   )
    Zq_Entry.grid(row=10,column=2,sticky='W')
    Zq_Entry.bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,0,'Zq',''))
    f_cen_Entry = tk.Entry(cntr,width=5,textvariable=f_cen_SV)
    f_cen_Entry.grid(row=11,column=2,sticky='W')
    f_cen_Entry.bind('<Return>',lambda event: Enter_Stuff_Dfcbyns(event,0,'f_cen',''))
    tk.Button(cntr,text='\u2190 Clipboard',command=ImportFromClipboard,anchor='e').grid(row=8,column=0,columnspan=2,sticky='W')
    tk.Button(cntr,text='\u2192 New BLine',command=NewBLine,anchor='e').grid(row=8,column=2,columnspan=2,sticky='W')
    if Cor.DD_DGbyn == 'DGbyn':
        DD_DGbyn_cb = tk.ttk.Combobox(cntr,state='readonly',width=5,textvariable=DD_DGbyn_Labels[0],values=DD_DGbyn_Labels); DD_DGbyn_cb.current(0)
    if Cor.DD_DGbyn == 'DD':
        DD_DGbyn_cb = tk.ttk.Combobox(cntr,state='readonly',width=5,textvariable=DD_DGbyn_Labels[1],values=DD_DGbyn_Labels); DD_DGbyn_cb.current(1)
    DD_DGbyn_cb.grid(row=9,column=0,sticky='W')
    DD_DGbyn_cb.bind('<<ComboboxSelected>>',enter_DD_DGbyn)

def MakeFitFrame(cntr):
    for widget in cntr.winfo_children(): widget.destroy()
    Model_Labels = ['Multilayer Formalism','3rd Order Perturbation','5th Order Perturbation','Thin Film J\'\'_1 small']
    weight_Labels = ['~n^-1','~n^-0.5','flat','~n^0.5','~n^1']
    RelWeight_DfDG_SV = tk.StringVar(cntr,Cor.RelWeight_DfDG)
    ErrDfbyn_SV = tk.StringVar(cntr,Cor.ErrDfbyn)
    freq_MHz_for_eq_thick_SV = tk.StringVar(cntr,Cor.freq_MHz_for_eq_thick)

    def Enter_Stuff_Fit(event,WhichStuffStr):
        if WhichStuffStr == 'ErrDfbyn': 
            string = ErrDfbyn_SV.get(); string.strip()
            try: 
                Cor.ErrDfbyn = np.float64(string)
                MakeFitFrame(cntr);
                Cor.Write_Config()
            except: pass    
        if WhichStuffStr == 'freq_MHz_for_eq_thick': 
            string = freq_MHz_for_eq_thick_SV.get(); string.strip()
            try: 
                Cor.freq_MHz_for_eq_thick = np.float64(string)
                PlotSingle(PlotSingleFrame)
                Cor.Fit_done = 'no' 
                Cor.Write_Config()
                MakeSampleParsFrame(SampleParsFrame)
                PlotSingle()
            except: pass    
        if WhichStuffStr == 'RelWeight_DfDG':
            string = RelWeight_DfDG_SV.get(); string.strip()
            try: 
                Cor.RelWeight_DfDG = np.float64(string)
                Cor.Fit_done = 'no' 
                Cor.Write_Config()
            except: pass 
        MakeFitFrame(FitFrame)

    def enter_i_Model(event):    
        Model = event.widget.get()
        if Model == 'Thin_Film_Jpp1 small' and \
            (Cor.Show_lay1 != 'yes' or Cor.Show_lay2 != 'no' or Cor.Show_bulk != 'yes' or \
             Cor.SamplePars['VEtype_lay3'] != 3 or Cor.SamplePars['VEPar2_lay3'] > Cor.LimitsMinPars['VEPar2_lay3']):
            tk.messagebox.showinfo('','requires single film in Newtonian liquid')
            return
        for i,Model_Label in enumerate(Model_Labels):
            if Model == Model_Label: Cor.Model = Cor.Model_strings[i]
        Cor.Fit_done = 'no'; Cor.Write_Config()
        PlotSingle(PlotSingleFrame)
        MakeSampleParsFrame(SampleParsFrame)
        
    def enter_stat_weight(event):    
        weight = event.widget.get()
        for i,weight_Label in enumerate(weight_Labels):
            if weight == weight_Label: Cor.stat_weight = Cor.stat_weight_strings[i]
        Cor.Fit_done = 'no'; Cor.Write_Config()
        MakeSampleParsFrame(SampleParsFrame)

    def Check_i_xMHz():
        if int(i_xMHz_IV.get()) == 0: Cor.Use_eq_thickness_at_xMHz = 'no'
        if int(i_xMHz_IV.get()) == 1: Cor.Use_eq_thickness_at_xMHz = 'yes'
        Cor.Fit_done = 'no'; Cor.Write_Config() 
        PlotSingle(PlotSingleFrame)
        MakeSampleParsFrame(SampleParsFrame)
        
    def checkPlotErrBars():
        Cor.i_PlotErrBars = i_PlotErrBars_IV.get(); Cor.Write_Config()
        PlotFPars(PlotFParsFrame)
    
    if Cor.Model == 'Multilayer_Formalism':
        Model_cb = tk.ttk.Combobox(cntr,state='readonly',width=20,textvariable=Model_Labels[0],values=Model_Labels); Model_cb.current(0)
    if Cor.Model == '3rd-Order_Perturbation':
        Model_cb = tk.ttk.Combobox(cntr,state='readonly',width=20,textvariable=Model_Labels[1],values=Model_Labels); Model_cb.current(1)
    if Cor.Model == '5th-Order_Perturbation':
        Model_cb = tk.ttk.Combobox(cntr,state='readonly',width=20,textvariable=Model_Labels[2],values=Model_Labels); Model_cb.current(2)
    if Cor.Model == 'Thin_Film_Jpp1 small':
        Model_cb = tk.ttk.Combobox(cntr,state='readonly',width=20,textvariable=Model_Labels[3],values=Model_Labels); Model_cb.current(3)
    Model_cb.grid(row=0,column=0,columnspan=2,sticky='W')
    Model_cb.bind('<<ComboboxSelected>>',enter_i_Model)

    tk.Button(cntr,text ='Fit',command=Fit,fg='red').grid(row=0,column=2,sticky='W')
    Undo_Btn = tk.Button(cntr,text ='\u2190',command=Undo)
    Undo_Btn.grid(row=0,column=3,sticky='W')
    Undo_Tooltip = tk.tix.Balloon(Root)
    Undo_Tooltip.bind_widget(Undo_Btn,balloonmsg='Undo Fit')

    tk.Label(cntr,text='(\u03b4f/n)_err[Hz]',anchor='e').grid(row=1,column=0,sticky='W')
    ErrDfbyn_Entry = tk.Entry(cntr,width=3,textvariable=ErrDfbyn_SV)
    ErrDfbyn_Entry.grid(row=1,column=1,sticky='W')
    ErrDfbyn_Entry.bind('<Return>',lambda event: Enter_Stuff_Fit(event,'ErrDfbyn'))
    Cor.Calc_chi2()
    if Cor.chi2 < 1e9: 
        tk.Label(cntr,width=9,text='\u03c7\u00b2 ' + str(np.round(Cor.chi2,2)),fg='blue').grid(row=1,column=2,columnspan=2,sticky='W')
    else:    
        tk.Label(cntr,width=9,text='\u03c7\u00b2 ').grid(row=1,column=2,columnspan=2,sticky='W')

    weight_label = tk.Label(cntr,text='Statistical Weight',anchor='e')
    weight_label.grid(row=2,column=0,sticky='E')
    if Cor.stat_weight == 'n^-1':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,textvariable=weight_Labels[0],values=weight_Labels); weight_cb.current(0)
    if Cor.stat_weight == 'n^-(0.5)':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,textvariable=weight_Labels[1],values=weight_Labels); weight_cb.current(1)
    if Cor.stat_weight == 'flat':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,textvariable=weight_Labels[2],values=weight_Labels); weight_cb.current(2)
    if Cor.stat_weight == 'n^(0.5)':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,textvariable=weight_Labels[3],values=weight_Labels); weight_cb.current(3)
    if Cor.stat_weight == 'n^1':
        weight_cb = tk.ttk.Combobox(cntr,state='readonly',width=7,textvariable=weight_Labels[4],values=weight_Labels); weight_cb.current(4)
    weight_cb.grid(row=2,column=1,columnspan=2,sticky='W')
    weight_cb.bind('<<ComboboxSelected>>',enter_stat_weight)
    weight_cb_Tooltip = tk.tix.Balloon(Root)
    weight_cb_Tooltip.bind_widget(weight_cb,balloonmsg='Choose weight different from \' flat\' if there is a systematic dependence of the noise on the overtone order')
    weight_cb_Tooltip2 = tk.tix.Balloon(Root)
    weight_cb_Tooltip2.bind_widget(weight_label,balloonmsg='Choose weight different from \' flat\' if there is a systematic dependence of the noise on the overtone order')

    RelWeight_DfDG_label = tk.Label(cntr,text='Rel Weight \u0394\u0393 ,\u0394f',anchor='e')
    RelWeight_DfDG_label.grid(row=3,column=0,sticky='E')
    RelWeight_DfDG_SV_Entry = tk.Entry(cntr,width=5,textvariable=RelWeight_DfDG_SV)
    RelWeight_DfDG_SV_Entry.grid(row=3,column=1,sticky='W')
    RelWeight_DfDG_SV_Entry.bind('<Return>',lambda event: Enter_Stuff_Fit(event,'RelWeight_DfDG'))

    RelWeight_DfDG_Tooltip  = tk.tix.Balloon(Root)
    RelWeight_DfDG_Tooltip2 = tk.tix.Balloon(Root)
    RelWeight_DfDG_Tooltip.bind_widget(RelWeight_DfDG_label    ,balloonmsg='Make weight of \u0394\u0393 large if \u0394\u0393 << -\u0394f')
    RelWeight_DfDG_Tooltip2.bind_widget(RelWeight_DfDG_SV_Entry,balloonmsg='Make weight of \u0394\u0393 large if \u0394\u0393 << -\u0394f')


    if Cor.Use_eq_thickness_at_xMHz == 'yes': i_xMHz_IV  = tk.IntVar(cntr,1)
    if Cor.Use_eq_thickness_at_xMHz == 'no' : i_xMHz_IV  = tk.IntVar(cntr,0)
    if Cor.SamplePars['t_lay1'] >  1e-8 and Cor.SamplePars['t_lay2'] < 1e-8 and \
           Cor.RefPars['t_lay1'] < 1e-8 and Cor.RefPars['t_lay2'] < 1e-8:
        Useeq_Btn = tk.Checkbutton(cntr,anchor='w',variable=i_xMHz_IV,text = 'Eq Thickn @ x MHz',command=Check_i_xMHz)
        Useeq_Btn.grid(row=4,column=0,columnspan=2,sticky='E')
        freq_MHz_for_eq_thick_SV_Entry = tk.Entry(cntr,width=5,textvariable=freq_MHz_for_eq_thick_SV)
        freq_MHz_for_eq_thick_SV_Entry.grid(row=4,column=2,sticky='W')
        freq_MHz_for_eq_thick_SV_Entry.bind('<Return>',lambda event: Enter_Stuff_Fit(event,'freq_MHz_for_eq_thick'))
    else: 
        Cor.Use_eq_thickness_at_xMHz = 'no'; Cor.Write_Config()     

    tk.Button(cntr,text ='ConfLimits\u2192Console',command=ConfLims_lmfit_2_Console).grid(row=5,column=0,columnspan=3,sticky='W')

    if Cor.i_PlotErrBars == 1 : i_PlotErrBars_IV = tk.IntVar(cntr,1)
    if Cor.i_PlotErrBars == 0 : i_PlotErrBars_IV = tk.IntVar(cntr,0)
    tk.Checkbutton(cntr,anchor='w',text='ErrBars',variable=i_PlotErrBars_IV,command=checkPlotErrBars).grid(row=5,column=2,columnspan=2)

def MakeTT_IOFrame(cntr):
    for widget in cntr.winfo_children(): widget.destroy()  
    n_pre_avg_SV       = tk.StringVar(cntr,Cor.n_pre_avg)

    def Enter_Stuff_TT_IO(event,iovt,WhichStuffStr,key):
        if WhichStuffStr == 'n_pre_avg': 
            string = n_pre_avg_SV.get(); string.strip()
            try: Cor.n_pre_avg = int(string)
            except: pass    
        MakeTT_IOFrame(TT_IOFrame)
        Cor.Write_Config()
        if WhichStuffStr == 'Update_Inval': PlotFPars(PlotFParsFrame)

    IO_Format_Labels    = ['from QTZ','from QSoft','from QSoft New','from AWSensors','Recognize from Header']
    Channel_Labels      = ['Channel 1','Channel 2','Channel 3','Channel 4']
    Default_Prev_Labels = ['Guess: Default','Guess: Previous']
    vs_time_datapoint_Labels = ['x: time','x: i']
           
    def Import_TT():
        filetypes = (('text files','*.txt'),('data files','*.dat'))
        f = fd.askopenfile(filetypes=filetypes)
        if not os.path.isfile(f.name): return
        if len(f.name) == 0: return
        Import_Btn['state'] = 'disabled'
        Root.update()
        Cor.Write_Config()
        Clear_Fits()
        Clear()
        Cor.TT_filename = f.name
        TT.Import_TT() 
        Import_Btn['state'] = 'normal'
        PlotDfDGbyns(PlotDfDGbynsFrame); PlotFPars(PlotFParsFrame) 
        MakeDfcbynsFrame(DfcbynsFrame); PlotSingle(PlotSingleFrame)
        MakeSampleParsFrame(SampleParsFrame)
        MakeTT_IOFrame(TT_IOFrame)
        f = open('~tmp.qtr','w'); f.close()
        Root.title('PyQTM:    ' + os.path.basename(Cor.filename) + '   /   ' + os.path.basename(Cor.TT_filename))
        
    def enter_i_IO_Format_TT(event): 
        IO_Format = event.widget.get()
        for i,IO_Format_Label in enumerate(IO_Format_Labels):
            if IO_Format == IO_Format_Label: Cor.TT_IO_Format = Cor.TT_IO_Format_strings[i]
        MakeTT_IOFrame(TT_IOFrame)
        Cor.Write_Config()
       
    def enter_i_channel_TT(event):
        Channel = event.widget.get()
        for i,Channel_Label in enumerate(Channel_Labels):
            if Channel == Channel_Label: Cor.i_channel = i
        Cor.Write_Config()
        
    def enter_Default_Prev(event):
        Default_Prev = event.widget.get()
        for i,Default_Prev_Label in enumerate(Default_Prev_Labels):
            if Default_Prev == Default_Prev_Label: Cor.Default_Prev = Cor.Default_Previous_strings[i]
        Cor.Write_QTM_cfg()
        
    def enter_vs_time_datapoint(event):    
        vs_time_datapoint = event.widget.get()
        for i,vs_time_datapoint_Label in enumerate(vs_time_datapoint_Labels):
            if vs_time_datapoint == vs_time_datapoint_Label: Cor.vs_time_datapoint = Cor.vs_time_datapoint_strings[i]
        if Cor. vs_time_datapoint == 'time': Cor.i_col_x = 1
        else :                               Cor.i_col_x = 0 
        Cor.Write_Config()
        PlotDfDGbyns(PlotDfDGbynsFrame)
        PlotFPars(PlotFParsFrame)

    def Check_TT_Correct_Drift():
        if int(TT_Correct_Drift_IV.get()) == 0: Cor.TT_Correct_Drift = 'no'
        if int(TT_Correct_Drift_IV.get()) == 1: Cor.TT_Correct_Drift = 'yes'
        Cor.Write_Config()

    Import_Btn = tk.Button(cntr,text ='Import',command=Import_TT,anchor='w',fg='blue')
    Import_Btn.grid(row=0,column=0,sticky='E')
    if Cor.TT_IO_Format =='from_QSoft':
        IO_Format_cb = tk.ttk.Combobox(cntr,state='readonly',width=19,textvariable=IO_Format_Labels[1],values=IO_Format_Labels); IO_Format_cb.current(1)
    elif Cor.TT_IO_Format =='from_QSoft_new':
        IO_Format_cb = tk.ttk.Combobox(cntr,state='readonly',width=19,textvariable=IO_Format_Labels[2],values=IO_Format_Labels); IO_Format_cb.current(2)
    elif Cor.TT_IO_Format =='from_AWSensors':
        IO_Format_cb = tk.ttk.Combobox(cntr,state='readonly',width=19,textvariable=IO_Format_Labels[3],values=IO_Format_Labels); IO_Format_cb.current(3)
    elif Cor.TT_IO_Format =='Automatic':
        IO_Format_cb = tk.ttk.Combobox(cntr,state='readonly',width=19,textvariable=IO_Format_Labels[4],values=IO_Format_Labels); IO_Format_cb.current(4)
    else:
        IO_Format_cb = tk.ttk.Combobox(cntr,state='readonly',width=19,textvariable=IO_Format_Labels[0],values=IO_Format_Labels); IO_Format_cb.current(0)
    IO_Format_cb.grid(row=0,column=1,columnspan=3,sticky='W')
    IO_Format_cb.bind('<<ComboboxSelected>>',enter_i_IO_Format_TT)
    tk.Label(cntr,text='Avg').grid(row=1,column=0,sticky='E')
    n_pre_avg_Entry = tk.Entry(cntr,textvariable=n_pre_avg_SV,width=4)
    n_pre_avg_Entry.grid(row=1,column=1,sticky='W')
    n_pre_avg_Entry.bind('<Return>',lambda event: Enter_Stuff_TT_IO(event,0,'n_pre_avg',''))

    if Cor.TT_IO_Format == 'from_QSoft_new':
        Channel_cb = tk.ttk.Combobox(cntr,state='readonly',width=10,textvariable=Channel_Labels[Cor.i_channel],values=Channel_Labels)
        Channel_cb.grid(row=1,column=2,columnspan=3,sticky='W')
        Channel_cb.current(Cor.i_channel)
        Channel_cb.bind('<<ComboboxSelected>>',enter_i_channel_TT)


    TT.get_rms_noise()
    if not np.isnan(Cor.rms_noise):
        noise_label = tk.Label(cntr,text='(\u03b4f/n)_rms [mHz] '+ str(np.round(Cor.rms_noise*1e3,1)),anchor='w')
        noise_label.grid(row=7,column=0,columnspan=3,sticky='W')
        noise_label_Tooltip = tk.tix.Balloon(Root) 
        noise_label_Tooltip.bind_widget(noise_label,balloonmsg='Calculated as (<(\u0394f_(i+1)/n - 2\u0394f_i/n +\u0394f_(i-1)/n)\u00B2>/6)^(1/2),data in fit range')

    if Cor.Default_Prev == 'Start_from_Default':
        Default_Prev_cb = tk.ttk.Combobox(cntr,state='readonly',width=14,textvariable=Default_Prev_Labels[0],values=Default_Prev_Labels); Default_Prev_cb.current(0)
    else:
        Default_Prev_cb = tk.ttk.Combobox(cntr,state='readonly',width=14,textvariable=Default_Prev_Labels[1],values=Default_Prev_Labels); Default_Prev_cb.current(1)
    Default_Prev_cb.grid(row=8,column=0,columnspan=3,sticky='W')
    Default_Prev_cb.bind('<<ComboboxSelected>>',enter_Default_Prev)
    
    if Cor.TT_Correct_Drift == 'yes': TT_Correct_Drift_IV = tk.IntVar(cntr,1)
    if Cor.TT_Correct_Drift == 'no' : TT_Correct_Drift_IV = tk.IntVar(cntr,0)
    TT_Correct_Drift_CBtn = tk.Checkbutton(cntr,text='Import: Comp Drift',variable=TT_Correct_Drift_IV,command=Check_TT_Correct_Drift)
    TT_Correct_Drift_CBtn.grid(row=9,column=0,columnspan=3,sticky='W')

    if Cor.vs_time_datapoint == 'time':
        vs_time_datapoint_cb = tk.ttk.Combobox(cntr,state='readonly',width=9,textvariable=vs_time_datapoint_Labels[0],values=vs_time_datapoint_Labels); vs_time_datapoint_cb.current(0)
    if Cor.vs_time_datapoint == 'datapoint':
        vs_time_datapoint_cb = tk.ttk.Combobox(cntr,state='readonly',width=9,textvariable=vs_time_datapoint_Labels[1],values=vs_time_datapoint_Labels); vs_time_datapoint_cb.current(1)
    vs_time_datapoint_cb.grid(row=8,column=2,columnspan=3,sticky='W')
    vs_time_datapoint_cb.bind('<<ComboboxSelected>>',enter_vs_time_datapoint)

def MakeFit_AllFrame(cntr):
    for widget in cntr.winfo_children(): widget.destroy()  
    Update_Inval_SV  = tk.StringVar(cntr,Cor.Update_Inval)
    ConfLim_Inval_SV = tk.StringVar(cntr,Cor.ConfLim_Inval)
    InfoString_SV     = tk.StringVar(cntr,Cor.InfoString)
    TT_fit_from_Labels  = ['Guess \u2190 Prev Result','Guess \u2190 ParsPanel']
    TT_direc_Labels     = ['\u2192','\u2190']

    def Enter_Stuff_Fit_All(event,WhichStuffStr):
        if WhichStuffStr == 'InfoString':
            string = InfoString_SV.get(); string.strip()
            try: 
                Cor.InfoString = string; Cor.Write_Config()
                PlotDfDGbyns(PlotDfDGbynsFrame)
                PlotFPars(   PlotFParsFrame)
            except: pass 
        if WhichStuffStr == 'Update_Inval': 
            string = Update_Inval_SV.get(); string.strip()
            try: Cor.Update_Inval = int(string); Cor.Write_Config()
            except: pass
        if WhichStuffStr == 'ConfLim_Inval': 
            string = ConfLim_Inval_SV.get(); string.strip()
            try: Cor.ConfLim_Inval = int(string); Cor.Write_Config()
            except: pass
        MakeFit_AllFrame(Fit_AllFrame)
        Cor.Write_Config()
        if WhichStuffStr == 'Update_Inval': PlotFPars(PlotFParsFrame)

    TT_fit_from_Labels  = ['Guess \u2190 Prev Result','Guess \u2190 ParsPanel']
    TT_direc_Labels     = ['\u2192','\u2190']
           
    def Fit_All():
        def Save_Display_FPars():
            TT.Make_headers()
            np.savetxt('~tmp.qtd',TT.TT_FPars,header=TT.header_FPars_qtd,delimiter='\t',newline='\n')
            np.savetxt('~tmp.qtf',TT.DfDGbyns,header=TT.header_DfDGbyns ,delimiter='\t',newline='\n')
            PlotDfDGbyns(PlotDfDGbynsFrame)   
            PlotFPars(PlotFParsFrame) 
            np.savetxt('~tmp_for_unhide.qtd',TT.TT_FPars,header=TT.header_FPars_qtd,delimiter='\t',newline='\n')
        
        if Cor.Abort_Enabled: Cor.Abort = True; return
        Cor.Abort = False; Cor.Abort_Enabled = True; Fit_All_Btn['text'] = 'Abort'; Root.update()
        Calc_nFPars()
        if Cor.nFPars == 0: tk.messagebox.showinfo('','no active fit parameters') 
        else:     
            if Cor.ConfLim_Inval > 0: 
                if os.path.isfile('ConfLims.txt') : os.remove(('ConfLims.txt'))
            Cor.Pars_to_Vals()
            if Cor.TT_direc == 'start_to_stop':
                TT_strt = Cor.i_strt_fit; TT_stop = Cor.i_stop_fit;  TT_step = 1
            else:
                TT_strt = Cor.i_stop_fit;  TT_stop = Cor.i_strt_fit; TT_step = -1
            for it in range(TT_strt,TT_stop,TT_step):
                if Cor.Abort: 
                    Save_Display_FPars()
                    Cor.Abort_Enabled = False; Cor.Abort = False
                    Fit_All_Btn['text'] = 'Fit All'; Root.update()
                    return
                Cor.i_current = it
                for iovt in range(Cor.novt): 
                    Cor.Dfbyns[iovt] = TT.DfDGbyns[it,2+4*iovt  ]
                    Cor.DGbyns[iovt] = TT.DfDGbyns[it,2+4*iovt+1]
                Cor.Dfcbyns = Cor.Dfbyns + 1j*Cor.DGbyns
                Not_NaNs = True
                for iovt in range(Cor.novt): 
                    if Cor.OvtInc[iovt] and np.isnan(Cor.Dfcbyns[iovt]): Not_NaNs = False
                if Not_NaNs:     
                    if Cor.Use_eq_thickness_at_xMHz == 'yes' and Cor.SamplePars['t_lay1'] >  0 and Cor.SamplePars['t_lay2'] == 0 and \
                       Cor.RefPars['t_lay1'] == 0 and Cor.RefPars['t_lay2'] == 0:
                        fac_to_0MHz = Cor.Calc_fac_to_0MHz()
                        Cor.SamplePars['t_lay1'] *= fac_to_0MHz 
                    Cor.Fit()
                    Cor.Dfcbyns_fit = Cor.Calc_Dfcbyns_from_FitVals(Cor.FittedVals)
                  
                    if (it-Cor.i_strt_fit)%Cor.Update_Inval == 0: 
                        Cor.FitVals_to_SamplePars(Cor.FittedVals)
                        Cor.Write_Config()
                        MakeSampleParsFrame(SampleParsFrame)
                        MakeDfcbynsFrame(DfcbynsFrame)
                        PlotSingle(PlotSingleFrame)
                        PlotDfDGbyns(PlotDfDGbynsFrame)
                        PlotFPars(PlotFParsFrame)
                        Root.update()
                    if Cor.ConfLim_Inval > 0 :     
                        if (it-Cor.i_strt_fit)%Cor.ConfLim_Inval == 0 : 
                            ConfLim_header,Textline = Cor.ConfLims_lmfit_2_Textline()
                            if not os.path.isfile('ConfLims.txt'):
                                f = open('ConfLims.txt','a'); f.write(ConfLim_header); f.write(Textline); f.close();
                            else:
                                f = open('ConfLims.txt','a'); f.write(Textline); f.close();
                    if Cor.Use_eq_thickness_at_xMHz == 'yes' and Cor.SamplePars['t_lay1'] >  0 and Cor.SamplePars['t_lay2'] == 0 and \
                           Cor.RefPars['t_lay1'] == 0 and Cor.RefPars['t_lay2'] == 0:
                        fac_to_xMHz = Cor.Calc_fac_to_xMHz()
                        Cor.SamplePars['t_lay1']           *= fac_to_xMHz
                        Cor.SampleStdErrs['t_lay1']        *= fac_to_xMHz
                        count = 0
                        for key in Cor.keys:
                            if Cor.IncPars[key] == 1:
                                if key == 't_lay1': Cor.FittedVals[count] *= fac_to_xMHz
                            count += 1    
                    if Cor.TT_guess_from == 'from_previous_fit': Cor.GuessVals = Cor.FittedVals
                TT.TT_FPars[it,0] = it
                TT.TT_FPars[it,1] = TT.DfDGbyns[it,1]
                for iFPar in range(Cor.nFPars): 
                    TT.TT_FPars[it,2+2*iFPar  ] = Cor.FittedVals[iFPar]
                    TT.TT_FPars[it,2+2*iFPar+1] = Cor.StdErrs[iFPar]
                for iovt in range(Cor.novt):
                    TT.DfDGbyns[it,2+4*iovt+2] = Cor.Dfcbyns_fit_n_arr[iovt].real
                    TT.DfDGbyns[it,2+4*iovt+3] = Cor.Dfcbyns_fit_n_arr[iovt].imag
                Cor.Calc_chi2(); TT.TT_FPars[it,-1] = Cor.chi2
        Save_Display_FPars()
        PlotDfDGbyns(PlotDfDGbynsFrame)   
        Fit_All_Btn['text'] = 'Fit All'
        Cor.Abort_Enabled = False
            
    def enter_i_TT_fit_from(event):    
        TT_fit_from = event.widget.get()
        for i,TT_fit_from_Label in enumerate(TT_fit_from_Labels):
            if TT_fit_from == TT_fit_from_Label: Cor.TT_guess_from = Cor.TT_guess_from_strings[i]
        Cor.Write_Config()
        MakeTT_IOFrame(TT_IOFrame)

    def enter_i_TT_direc(event):    
        TT_direc = event.widget.get()
        for i,TT_direc_Label in enumerate(TT_direc_Labels):
            if TT_direc == TT_direc_Label: Cor.TT_direc = Cor.TT_direc_strings[i]
        Cor.Write_Config()
        
    Fit_All_Btn = tk.Button(cntr,text ='Fit All',command=Fit_All,fg='red')
    Fit_All_Btn.grid(row=0,column=0,sticky='W')
    tk.Button(cntr,text ='Clear',command=Clear_Fits).grid(row=0,column=1,sticky='W')
    FitRange_Btn = tk.Button(cntr,text ='Fit Range',command=Set_FitRange)
    FitRange_Btn.grid(row=0,column=2,sticky='W',columnspan=2)
    FitRange_Btn_Tooltip = tk.tix.Balloon(Root)
    FitRange_Btn_Tooltip.bind_widget(FitRange_Btn,balloonmsg='Drag over graph to select fit range')
    
    tk.Label(cntr,text='Updt Inval').grid(row=1,column=0,columnspan=1,sticky='E')
    Update_Inval_Entry = tk.Entry(cntr,width=4,textvariable=Update_Inval_SV)
    Update_Inval_Entry.grid(row=1,column=1,sticky='W')
    Update_Inval_Entry.bind('<Return>',lambda event: Enter_Stuff_Fit_All(event,'Update_Inval'))

    tk.Label(cntr,text='ConfLim Inval').grid(row=1,column=2,sticky='E')
    ConfLim_Inval_Entry = tk.Entry(cntr,width=4,textvariable=ConfLim_Inval_SV)
    ConfLim_Inval_Entry.grid(row=1,column=3,columnspan=2,sticky='W')
    ConfLim_Inval_Entry.bind('<Return>',lambda event: Enter_Stuff_Fit_All(event,'ConfLim_Inval'))

    if Cor.TT_guess_from == 'from_previous_fit':
        TT_guess_from_cb = tk.ttk.Combobox(cntr,state='readonly',width=18,textvariable=TT_fit_from_Labels[0],values=TT_fit_from_Labels); TT_guess_from_cb.current(0)
    if Cor.TT_guess_from == 'from_Parameters_at_Top':
        TT_guess_from_cb = tk.ttk.Combobox(cntr,state='readonly',width=18,textvariable=TT_fit_from_Labels[1],values=TT_fit_from_Labels); TT_guess_from_cb.current(1)
    TT_guess_from_cb.grid(row=2,column=0,columnspan=3,sticky='W')
    TT_guess_from_cb.bind('<<ComboboxSelected>>',enter_i_TT_fit_from)

    if Cor.TT_guess_from == 'from_previous_fit':
        if Cor.TT_direc == 'start_to_stop': 
            TT_direc_cb = tk.ttk.Combobox(cntr,state='readonly',width=3,textvariable=TT_direc_Labels[0],values=TT_direc_Labels); TT_direc_cb.current(0)
        else: 
            TT_direc_cb = tk.ttk.Combobox(cntr,state='readonly',width=3,textvariable=TT_direc_Labels[1],values=TT_direc_Labels); TT_direc_cb.current(1)
        TT_direc_cb.grid(row=2,column=3,columnspan=1,sticky='W')
        TT_direc_cb.bind('<<ComboboxSelected>>',enter_i_TT_direc)
        TT_direc_Tooltip = tk.tix.Balloon(Root)
        TT_direc_Tooltip.bind_widget(TT_direc_cb,balloonmsg='start to Stop  or  Stop to start')
    tk.Label(cntr,text='Info').grid(row=3,column=0,sticky='W')
    InfoString_Entry = tk.Entry(cntr,textvariable=InfoString_SV,width=22)
    InfoString_Entry.grid(row=3,column=1,columnspan=3,sticky='W')
    InfoString_Entry.bind('<Return>',lambda event: Enter_Stuff_Fit_All(event,'InfoString'))

def MakeGraphsFrame(cntr):
    for widget in cntr.winfo_children(): widget.destroy()    
    
    tk.Label(cntr,text='Expt').grid(row=1,column=0,sticky='W')
    Hide_1_Btn = tk.Button(cntr,text ='Hide 1',command=Hide_1_TT)
    Hide_1_Btn.grid(row=1,column=1,sticky='W')
    Hide_1_Btn_Tooltip = tk.tix.Balloon(Root)
    Hide_1_Btn_Tooltip.bind_widget(Hide_1_Btn,balloonmsg='Click on data graph to hide data point')
    Hide_Btn = tk.Button(cntr,text ='Hide',command=Hide_Range_TT)
    Hide_Btn.grid(row=1,column=2,columnspan=1,sticky='W')
    Hide_Btn_Tooltip = tk.tix.Balloon(Root)
    Hide_Btn_Tooltip.bind_widget(Hide_Btn,balloonmsg='Drag over data graph to hide data')
    tk.Button(cntr,text ='Unhide',command=UnHide_TT).grid(row=1,column=3,sticky='W')
    Avrg_Btn = tk.Button(cntr,text ='Avrg',command=Avrg)
    Avrg_Btn.grid(row=2,column=1,sticky='W')
    Avrg_Btn_Tooltip = tk.tix.Balloon(Root)
    Avrg_Btn_Tooltip.bind_widget(Avrg_Btn,balloonmsg='Drag over graph to set range for averaging')
    Zoom_Btn = tk.Button(cntr,text ='Zoom',command=Zoom_TT)
    Zoom_Btn.grid(row=2,column=2,sticky='W')
    Zoom_Btn_Tooltip = tk.tix.Balloon(Root)
    Zoom_Btn_Tooltip.bind_widget(Zoom_Btn,balloonmsg='Drag over graph')
    UnZoom_Btn = tk.Button(cntr,text ='Unzoom',command=UnZoom_TT)
    UnZoom_Btn.grid(row=2,column=3,columnspan=1,sticky='W')

    tk.Label(cntr,text='FPars').grid(row=3,column=0,sticky='W')
    FPs_Hide_1_Btn = tk.Button(cntr,text ='Hide 1',command=Hide_1_FP)
    FPs_Hide_1_Btn.grid(row=3,column=1,sticky='W')
    FPs_Hide_1_Btn_Tooltip = tk.tix.Balloon(Root)
    FPs_Hide_1_Btn_Tooltip.bind_widget(FPs_Hide_1_Btn,balloonmsg='Click on FPars graph to hide data point')
    FPs_Hide_Btn = tk.Button(cntr,text ='Hide',command=Hide_Range_FP)
    FPs_Hide_Btn.grid(row=3,column=2,sticky='W')
    FPs_Hide_Btn_Tooltip = tk.tix.Balloon(Root)
    FPs_Hide_Btn_Tooltip.bind_widget(FPs_Hide_Btn,balloonmsg='Drag over FPars graph to hide fitted parameters')
    tk.Button(cntr,text ='Unhide',command=Unhide_FP).grid(row=3,column=3,sticky='W')

    FPs_Zoom_Btn = tk.Button(cntr,text ='Zoom',command=Zoom_FP)
    FPs_Zoom_Btn.grid(row=4,column=2,sticky='W')
    FPs_UnZoom_Btn = tk.Button(cntr,text ='Unzoom',command=UnZoom_FP)
    FPs_UnZoom_Btn.grid(row=4,column=3,sticky='W')

def NewFile():
    try:
       os.remove('~tmp.qtm') 
       if os.path.isfile('~tmp.qtf'): os.remove('~tmp.qtf') 
       if os.path.isfile('~tmp.qtd'): os.remove('~tmp.qtd')
    except: pass
    if os.path.isfile('Defaults.qtm'): shutil.copyfile('Defaults.qtm','~tmp.qtm')
    Clear() 
    Cor.Read_Config(); Limits.Set_Defaults()
    TT.Initialize('~tmp.qtf','~tmp.qtd')
    Update_User_Interface()
    
def OpenPrevious(i): Cor.filename = Cor.Previous_Filenames[i]; Cor.Write_Config(); Open()
    
def OpenFile():
    filetypes = (('qtm files','*.qtm'),('all','*.*'))
    f = fd.askopenfile(filetypes=filetypes)
    Cor.filename = f.name; Cor.Write_Config() 
    Update_Previous_Filenames() 
    Open()

def Open():
    Clear()
    if os.path.isfile(Cor.filename) : shutil.copyfile(Cor.filename,'~tmp.qtm')
    else : tk.messagebox.showinfo('','file not found'); return
    if os.path.isfile(Cor.filename.replace('.qtm','.qtf')): shutil.copyfile(Cor.filename.replace('.qtm','.qtf'),'~tmp.qtf')
    if os.path.isfile(Cor.filename.replace('.qtm','.qtd')): shutil.copyfile(Cor.filename.replace('.qtm','.qtd'),'~tmp.qtd')
    Cor.Read_Config(); Limits.Set_Defaults(); TT.Initialize('~tmp.qtf','~tmp.qtd')
    Update_User_Interface()

def Save_All():
    if os.path.isfile('~tmp.qtm'): shutil.copyfile('~tmp.qtm',Cor.filename)
    if os.path.isfile('~tmp.qtr'): shutil.copyfile('~tmp.qtr',Cor.filename.replace('.qtm','.qtr'))
    TT.Make_headers()
    OnlyNaNs = True
    for it in range(len(TT.DfDGbyns)):
        for iovt in range(Cor.novt):
            if not np.isnan(TT.DfDGbyns[it,2+4*iovt]) or not np.isnan(TT.DfDGbyns[it,2+4*iovt+1]):
                OnlyNaNs = False
    if not OnlyNaNs:
        DfDGbyns_out = TT.DfDGbyns.copy()
        np.savetxt(Cor.filename.replace('.qtm','.qtf'),DfDGbyns_out,header=TT.header_DfDGbyns,delimiter='\t',newline='\n')
    OnlyNaNs = True
    for it in range(len(TT.TT_FPars)):
        for j in range(len(TT.TT_FPars[it])-2):
            if not np.isnan(TT.TT_FPars[it,j+2]):
                OnlyNaNs = False
    if not OnlyNaNs:
        TT_FPars_out = TT.TT_FPars.copy()
        np.savetxt(Cor.filename.replace('.qtm','.qtd'),TT_FPars_out,header=TT.header_FPars_qtd,delimiter='\t',newline='\n')

def Save():
    if os.path.isfile('~tmp.qtm'): shutil.copyfile('~tmp.qtm',Cor.folder+'\\'+Cor.filename+'.qtm')
    if os.path.isfile('~tmp.qtr'): shutil.copyfile('~tmp.qtr',Cor.folder+'\\'+Cor.filename+'.qtr')
    if os.path.isfile('~tmp.qtd'): shutil.copyfile('~tmp.qtd',Cor.folder+'\\'+Cor.filename+'.qtd')
    if os.path.isfile('~tmp.qtf'): shutil.copyfile('~tmp.qtf',Cor.folder+'\\'+Cor.filename+'.qtf')
    if os.path.isfile('~tmp_Backup.qtm')           : shutil.copyfile('~tmp_Backup.qtm'           ,Cor.folder+'\\'+Cor.filename+'_Backup.qtd')
    if os.path.isfile('~tmp_for_unhide.qtf')       : shutil.copyfile('~tmp_for_unhide.qtf'       ,Cor.folder+'\\'+Cor.filename+'_for_unhide.qtf')
    if os.path.isfile('~tmp_for_unhide.qtd')       : shutil.copyfile('~tmp_for_unhide.qtd'       ,Cor.folder+'\\'+Cor.filename+'_for_unhide.qtd')
    if os.path.isfile('Single.png')                : shutil.copyfile('Single.png'                ,Cor.folder+'\\'+Cor.filename+'_Single.png')
    if os.path.isfile('All_FPars.png')             : shutil.copyfile('All_FPars.png'             ,Cor.folder+'\\'+Cor.filename+'_All_FPars.png')
    if os.path.isfile('All_DfDGbyns.png')          : shutil.copyfile('All_DfDGbyns.png'          ,Cor.folder+'\\'+Cor.filename+'_All_DfDGbyns.png')
    if os.path.isfile('Simulated_Dfcbyn.txt')      : shutil.copyfile('Simulated_Dfcbyn.txt'      ,Cor.folder+'\\'+Cor.filename+'_Simulated_Dfcbyn.txt')
    if os.path.isfile('Experimental_Dfcbyn.txt')   : shutil.copyfile('Experimental_Dfcbyn.txt'   ,Cor.folder+'\\'+Cor.filename+'_Experimental_Dfcbyn.txt')
    if os.path.isfile('ConfLims.txt')              : shutil.copyfile('ConfLims.txt'              ,Cor.folder+'\\'+Cor.filename+'_ConfLims.txt')
    if os.path.isfile('chi2LS_CrossCors.txt')      : shutil.copyfile('chi2LS_CrossCors.txt'      ,Cor.folder+'\\'+Cor.filename+'_chi2LS_CrossCors.txt')
    if os.path.isfile('chi2LS_Chi2s.txt')          : shutil.copyfile('chi2LS_Chi2s.txt'          ,Cor.folder+'\\'+Cor.filename+'_chi2LS_Chi2s.txt')
    if os.path.isfile('chi2LS_All_chi2.png')       : shutil.copyfile('chi2LS_All_chi2.png'       ,Cor.folder+'\\'+Cor.filename+'_chi2LS_All_chi2.png')
    if os.path.isfile('chi2LS_2D.png')             : shutil.copyfile('chi2LS_2D.png'             ,Cor.folder+'\\'+Cor.filename+'_chi2LS_2D.png')
    if os.path.isfile('chi2LS_Single_Par.png')     : shutil.copyfile('chi2LS_Single_Par.png'     ,Cor.folder+'\\'+Cor.filename+'_chi2LS_Single_Par.png')   
    if os.path.isfile('Bootstrap_correlations.png'): shutil.copyfile('Bootstrap_correlations.png',Cor.folder+'\\'+Cor.filename+'_Bootstrap_correlations.png')   
    if os.path.isfile('Bootstrap_Histograms.png')  : shutil.copyfile('Bootstrap_Histograms.png'  ,Cor.folder+'\\'+Cor.filename+'_Bootstrap_Histograms.png')   

    if not os.path.isfile(Cor.folder+'\\'+os.path.basename(Cor.TT_filename)):
        if os.path.isfile(Cor.TT_filename)      : shutil.copyfile(Cor.TT_filename,Cor.folder+'\\'+os.path.basename(Cor.TT_filename))

def Save_As():
    filetypes = (('qtm files','*.qtm'),('all files','*.*'))
    filename_loc = fd.asksaveasfilename(filetypes=filetypes)
    if '.qtm' in filename_loc: filename_loc = filename_loc[:-4]
    Cor.folder   = os.path.dirname(filename_loc)
    Cor.filename = os.path.basename(filename_loc)
    Cor.Write_Config(); Update_Previous_Filenames()
    Save()

def Clear():
    if os.path.isfile('~tmp.qtr'): os.remove('~tmp.qtr')
    if os.path.isfile('~tmp.qtd'): os.remove('~tmp.qtd')
    if os.path.isfile('~tmp.qtf'): os.remove('~tmp.qtf')
    if os.path.isfile('~tmp_Backup.qtm')           : os.remove('~tmp_Backup.qtm')
    if os.path.isfile('~tmp_for_unhide.qtf')       : os.remove('~tmp_for_unhide.qtf')
    if os.path.isfile('~tmp_for_unhide.qtd')       : os.remove('~tmp_for_unhide.qtd')
    if os.path.isfile('Single.png')                : os.remove('Single.png')
    if os.path.isfile('All_FPars.png')             : os.remove('All_FPars.png')
    if os.path.isfile('All_DfDGbyns.png')          : os.remove('All_DfDGbyns.png')
    if os.path.isfile('Simulated_Dfcbyn.txt')      : os.remove('Simulated_Dfcbyn.txt')
    if os.path.isfile('Experimental_Dfcbyn.txt')   : os.remove('Experimental_Dfcbyn.txt')
    if os.path.isfile('ConfLims.txt')              : os.remove('ConfLims.txt')
    if os.path.isfile('chi2LS_CrossCors.txt')      : os.remove('chi2LS_CrossCors.txt')
    if os.path.isfile('chi2LS_Chi2s.txt')          : os.remove('chi2LS_Chi2s.txt')
    if os.path.isfile('chi2LS_Single_Par.png')     : os.remove('chi2LS_Single_Par.png')   
    if os.path.isfile('chi2LS_All_chi2.png')       : os.remove('chi2LS_All_chi2.png')
    if os.path.isfile('chi2LS_2D.png')             : os.remove('chi2LS_2D.png')
    if os.path.isfile('Bootstrap_Histograms.png')  : os.remove('Bootstrap_Histograms.png')
    if os.path.isfile('Bootstrap_correlations.png'): os.remove('Bootstrap_correlations.png')

def Update_User_Interface():
    MakeSampleParsFrame(SampleParsFrame)
    MakeFitFrame(       FitFrame)
    MakeDfcbynsFrame(   DfcbynsFrame)
    MakeTT_IOFrame(     TT_IOFrame)
    MakeFit_AllFrame(   Fit_AllFrame)
    MakeGraphsFrame(    GraphsFrame)
    PlotDfDGbyns(PlotDfDGbynsFrame)
    PlotSingle(  PlotSingleFrame)
    PlotFPars(   PlotFParsFrame)
    Root.title('PyQTM:    ' + os.path.basename(Cor.filename) + '   /   ' + os.path.basename(Cor.TT_filename))

def onCloseRefPanel():
    menubar.entryconfig('Reference State',state="normal")
    try : Ref_Panel.destroy()
    except : pass
    
def OpenRef(): 
    global Ref_Panel
    Ref_Panel = Toplevel(Root); 
    Ref_Panel.title("Reference State"); Ref_Panel.iconbitmap("QTM.ico"); 
    Ref_Panel.attributes('-topmost',True)
    def evaluate():
        for key in Cor.keys:
            if key != 'VEtype_lay1' and key != 'VEtype_lay2' and key != 'VEtype_lay3': 
                string = RefPars_SVs[key].get(); string.strip()
                try: Cor.RefPars[key] = np.float64(string)
                except: print(key,string)
                if Cor.RefPars[key] > Cor.LimitsMaxPars[key]: Cor.RefPars[key] = Cor.LimitsMaxPars[key]
                if Cor.RefPars[key] < Cor.LimitsMinPars[key]: Cor.RefPars[key] = Cor.LimitsMinPars[key]
        if Cor.RefPars['t_lay1'] > 0 or Cor.RefPars['t_lay2'] > 0: Cor.Use_eq_thickness_at_xMHz == 'no' 
        Cor.Write_Config()
        MakeRefParsFrame(RefParsFrame)
        PlotSingle(PlotSingleFrame) 

    RefParsFrame = tk.LabelFrame(Ref_Panel)
    RefParsFrame.grid(row=0,column=0,sticky='W')
    MakeRefParsFrame(RefParsFrame)
    evaluate = Ref_Panel.register(evaluate)
    Ref_Panel.bind_all("<Return>",evaluate)
    menubar.entryconfig('Reference State',state="disabled")
    Ref_Panel.protocol("WM_DELETE_WINDOW",onCloseRefPanel)

def MakeRefParsFrame(cntr):
    for widget in cntr.winfo_children(): widget.destroy()    
    global RefPars_SVs
    def enter_VEPar_e(event): 
        VEPar = event.widget.get()
        for i,VEPar_Choice in enumerate(VEPar_Choices):
            if VEPar == VEPar_Choice: Cor.RefPars['VEtype_lay1'] = i
        MakeRefParsFrame(cntr)        
    def enter_VEPar_f(event):    
        VEPar = event.widget.get()
        for i,VEPar_Choice in enumerate(VEPar_Choices):
            if VEPar == VEPar_Choice: Cor.RefPars['VEtype_lay2'] = i
        MakeRefParsFrame(cntr)        
    def enter_VEPar_b(event):    
        VEPar = event.widget.get()
        for i,VEPar_Choice in enumerate(VEPar_Choices):
            if VEPar == VEPar_Choice: Cor.RefPars['VEtype_lay3'] = i
        MakeRefParsFrame(cntr)        

    VEPar_Choices = ['J\',J\'\'','G\',G\'\'','\u03B7\',\u03B7\'\'','G\',\u03B7\'',\
                     '|J|,tan(\u03B4)','|G|,tan(\u03B4)','|\u03B7|,tan(\u03B4)\u207B\u00B9']
    RefPars_SVs_List = [] 
    for key in Cor.keys:
        RefPars_SVs_List.append(tk.StringVar(cntr,np.round(Cor.RefPars[key],4)))
    RefPars_SVs = dict(zip(Cor.keys,RefPars_SVs_List))
    
    f_w=11
    tk.Label(cntr,text='thickness [nm]'      ,width=f_w                   ).grid(row=0,column=1)
    tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]',width=f_w                   ).grid(row=0,column=3)
    tk.Label(cntr,text=Cor.VE_Labels1[Cor.RefPars['VEtype_lay1']],width=f_w).grid(row=0,column=4)
    tk.Label(cntr,text=Cor.VE_Labels2[Cor.RefPars['VEtype_lay1']],width=f_w).grid(row=0,column=6)
    tk.Label(cntr,text=u'\u03B2\''           ,width=f_w                   ).grid(row=0,column=8)
    tk.Label(cntr,text=u'\u03B2\'\''         ,width=f_w                   ).grid(row=0,column=10)
    tk.Label(cntr,text='Viscoelastic Par''s' ,width=f_w+1                 ).grid(row=0,column=12)

    tk.Label(cntr,text='thickness [nm]'      ,width=f_w                   ).grid(row=2,column=1)
    tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]',width=f_w                   ).grid(row=2,column=3)
    tk.Label(cntr,text=Cor.VE_Labels1[Cor.RefPars['VEtype_lay2']],width=f_w).grid(row=2,column=4)
    tk.Label(cntr,text=Cor.VE_Labels2[Cor.RefPars['VEtype_lay2']],width=f_w).grid(row=2,column=6)
    tk.Label(cntr,text=u'\u03B2\'',       width=f_w                       ).grid(row=2,column=8)
    tk.Label(cntr,text=u'\u03B2\'\'',     width=f_w                       ).grid(row=2,column=10)
    tk.Label(cntr,text='Viscoelastic Par''s',width=f_w+1                  ).grid(row=2,column=12)

    tk.Label(cntr,text=u'\u03C1 [g/cm\u00b3]'                   ,width=f_w  ).grid(row=4,column=3)
    tk.Label(cntr,text=Cor.VE_Labels1[Cor.RefPars['VEtype_lay3']],width=f_w  ).grid(row=4,column=4)
    tk.Label(cntr,text=Cor.VE_Labels2[Cor.RefPars['VEtype_lay3']],width=f_w  ).grid(row=4,column=6)
    tk.Label(cntr,text=u'\u03B2\''                              ,width=f_w  ).grid(row=4,column=8)
    tk.Label(cntr,text=u'\u03B2\'\''                            ,width=f_w  ).grid(row=4,column=10)
    tk.Label(cntr,text='Viscoelastic Par''s'                    ,width=f_w+1).grid(row=4,column=12)
    tk.Label(cntr,text='Roughn [nm]'                            ,width=f_w+5).grid(row=0,column=13)
    tk.Label(cntr,text='Aspect Ratio'                           ,width=f_w+5).grid(row=2,column=13)
    tk.Label(cntr,text='1'   ).grid(row=1,column=0,sticky='E')
    tk.Label(cntr,text='2'   ).grid(row=3,column=0,sticky='E')
    tk.Label(cntr,text='bulk').grid(row=5,column=0,sticky='E')

    tk.Entry(cntr,textvariable=RefPars_SVs['t_lay1'            ],width=f_w-1).grid(row=1,column=1)
    tk.Entry(cntr,textvariable=RefPars_SVs['rho_lay1'          ],width=f_w-1).grid(row=1,column=3)
    tk.Entry(cntr,textvariable=RefPars_SVs['VEPar1_lay1'       ],width=f_w-1).grid(row=1,column=4)
    tk.Entry(cntr,textvariable=RefPars_SVs['VEPar2_lay1'       ],width=f_w-1).grid(row=1,column=6)
    tk.Entry(cntr,textvariable=RefPars_SVs['VEPar1_PLexpt_lay1'],width=f_w-1).grid(row=1,column=8)
    tk.Entry(cntr,textvariable=RefPars_SVs['VEPar2_PLexpt_lay1'],width=f_w-1).grid(row=1,column=10)
    
    VEPar_cb_1 = tk.ttk.Combobox(cntr,width=f_w-1,textvariable=RefPars_SVs['VEtype_lay1'],values=VEPar_Choices)
    VEPar_cb_1.grid(row=1,column=12)
    VEPar_cb_1.current(Cor.RefPars['VEtype_lay1'])
    VEPar_cb_1.bind("<<ComboboxSelected>>",enter_VEPar_e)

    tk.Entry(cntr,textvariable=RefPars_SVs['t_lay2'            ],width=f_w-1).grid(row=3,column=1)
    tk.Entry(cntr,textvariable=RefPars_SVs['rho_lay2'          ],width=f_w-1).grid(row=3,column=3)
    tk.Entry(cntr,textvariable=RefPars_SVs['VEPar1_lay2'       ],width=f_w-1).grid(row=3,column=4)
    tk.Entry(cntr,textvariable=RefPars_SVs['VEPar2_lay2'       ],width=f_w-1).grid(row=3,column=6)
    tk.Entry(cntr,textvariable=RefPars_SVs['VEPar1_PLexpt_lay2'],width=f_w-1).grid(row=3,column=8)
    tk.Entry(cntr,textvariable=RefPars_SVs['VEPar2_PLexpt_lay2'],width=f_w-1).grid(row=3,column=10)

    VEPar_cb_2 = tk.ttk.Combobox(cntr,width=f_w-1,textvariable=RefPars_SVs['VEtype_lay2'],values=VEPar_Choices)
    VEPar_cb_2.grid(row=3,column=12)
    VEPar_cb_2.current(Cor.RefPars['VEtype_lay2'])
    VEPar_cb_2.bind("<<ComboboxSelected>>",enter_VEPar_f)
    
    tk.Entry(cntr,textvariable=RefPars_SVs['rho_lay3'          ],width=f_w-1).grid(row=5,column=3)
    tk.Entry(cntr,textvariable=RefPars_SVs['VEPar1_lay3'       ],width=f_w-1).grid(row=5,column=4)
    tk.Entry(cntr,textvariable=RefPars_SVs['VEPar2_lay3'       ],width=f_w-1).grid(row=5,column=6)
    tk.Entry(cntr,textvariable=RefPars_SVs['VEPar1_PLexpt_lay3'],width=f_w-1).grid(row=5,column=8)
    tk.Entry(cntr,textvariable=RefPars_SVs['VEPar2_PLexpt_lay3'],width=f_w-1).grid(row=5,column=10)
    tk.Entry(cntr,textvariable=RefPars_SVs['VertScaleR'        ],width=f_w-1).grid(row=1,column=13)
    tk.Entry(cntr,textvariable=RefPars_SVs['AspRat'            ],width=f_w-1).grid(row=3,column=13)

    VEPar_cb_b = tk.ttk.Combobox(cntr,width=f_w-1,textvariable=RefPars_SVs['VEtype_lay3'],values=VEPar_Choices)
    VEPar_cb_b.grid(row=5,column=12)
    VEPar_cb_b.current(Cor.RefPars['VEtype_lay3'])
    VEPar_cb_b.bind("<<ComboboxSelected>>",enter_VEPar_b)
    
def Make_Menu():
    global menubar
    menubar = tk.Menu(Root); Root.config(menu=menubar) 
    file_menu = tk.Menu(menubar)
    menubar.add_cascade(label='File',menu=file_menu)
    file_menu.add_command(label='New' ,command=NewFile)
    file_menu.add_command(label='Open',command=OpenFile)
    sub_menu = tk.Menu(file_menu,tearoff=0)
    sub_menu.add_command(label=Cor.Previous_Filenames[0],command=lambda: OpenPrevious(0))
    sub_menu.add_command(label=Cor.Previous_Filenames[1],command=lambda: OpenPrevious(1))
    sub_menu.add_command(label=Cor.Previous_Filenames[2],command=lambda: OpenPrevious(2))
    sub_menu.add_command(label=Cor.Previous_Filenames[3],command=lambda: OpenPrevious(3))
    sub_menu.add_command(label=Cor.Previous_Filenames[4],command=lambda: OpenPrevious(4))
    sub_menu.add_command(label=Cor.Previous_Filenames[5],command=lambda: OpenPrevious(5))
    sub_menu.add_command(label=Cor.Previous_Filenames[6],command=lambda: OpenPrevious(6))
    sub_menu.add_command(label=Cor.Previous_Filenames[7],command=lambda: OpenPrevious(7))
    sub_menu.add_command(label=Cor.Previous_Filenames[8],command=lambda: OpenPrevious(8))
    sub_menu.add_command(label=Cor.Previous_Filenames[9],command=lambda: OpenPrevious(9))
    file_menu.add_cascade(label='Open recent',menu = sub_menu)
    file_menu.add_command(label='Save'                ,command=Save)
    file_menu.add_command(label='Save as...'          ,command=Save_As)
    menubar.add_command(label='Reference State'       ,command=OpenRef)
    menubar.add_command(label='Limits'                ,command=openLimits)
    menubar.add_command(label='\u03c7\u00b2 Landscape',command=openchi2_Landscape)
    menubar.add_command(label='Bootstrapping'         ,command=openBootstrap)
    menubar.add_command(label='Fuzzy Interface'       ,command=openFuzzyInterface)
    menubar.add_command(label='About'                 ,command=AboutMessage)

def onClose():
    try: FuzzyInterface.FuzzyInterfaceRoot.destroy() 
    except: pass
    try: chi2_Landscape.chi2_LandscapeRoot.destroy() 
    except: pass
    try: Bootstrap.BootstrapRoot.destroy()
    except: pass
    try: Limits.LimitsRoot.destroy()
    except: pass
    try: Root.destroy()
    except: pass

Cor.Read_QTM_cfg(); Cor.Get_Labels(); Cor.Read_Config(); Limits.Set_Defaults(); TT.Initialize('~tmp.qtf','~tmp.qtd') 
Cor.Fit_done = 'no'
Root = tk.tix.Tk(); Root.geometry('+0+0'); Root.protocol("WM_DELETE_WINDOW",onClose); Root.iconbitmap("QTM.ico")
SampleParsFrame   = tk.LabelFrame(Root); SampleParsFrame.grid(  row=0,column=0,columnspan=3,sticky='NW')
DfcbynsFrame      = tk.LabelFrame(Root); DfcbynsFrame.grid(     row=1,column=0,rowspan=2,sticky='NW')
TT_IOFrame        = tk.LabelFrame(Root); TT_IOFrame.grid(       row=3,column=0,sticky='NW')
Fit_AllFrame      = tk.LabelFrame(Root); Fit_AllFrame.grid(     row=4,column=1,sticky='NW')
FitFrame          = tk.LabelFrame(Root); FitFrame.grid(         row=2,column=1,rowspan=2,sticky='NW')
GraphsFrame       = tk.LabelFrame(Root); GraphsFrame.grid(      row=4,column=0,sticky='NW')
PlotSingleFrame   = tk.LabelFrame(Root); PlotSingleFrame.grid(  row=1,column=1,sticky='NW')
PlotDfDGbynsFrame = tk.LabelFrame(Root); PlotDfDGbynsFrame.grid(row=1,column=2,rowspan=5,sticky='NW')
PlotFParsFrame    = tk.LabelFrame(Root); PlotFParsFrame.grid(   row=0,column=3,rowspan=6,sticky='NW')

Make_Menu()
if (Cor.Default_Prev == 'Start_from_Default'): NewFile()
else: Update_User_Interface()


Root.mainloop()
